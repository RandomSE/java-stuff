public class Main {
    private String name;
    private int age;

    // Setter methods return the object itself to enable chaining
    public Main setName(String name) {
        this.name = name;
        return this;
    }

    public Main setAge(int age) {
        this.age = age;
        return this;
    }

    // Method to display the object's state
    public void displayInfo() {
        System.out.println("Name: " + name + ", Age: " + age);
    }

    public static void main(String[] args) {
        // Create an instance and use method chaining to set properties
        Main example = new Main()
                .setName("John")
                .setAge(30);

        // Display the object's state
        example.displayInfo();
    }
}