import java.io.*;
public class Main { 
	
	public static void main(String args[] ) throws IOException, ClassNotFoundException {
		
		
		 
		   //Deserialization = 	The reverse process of converting a byte stream into an object.
		   //					(Think of this as if you're loading a saved file)
		   
		   //					Steps to Deserialize
		   //					---------------------------------------------------------------
		   //					1. Your class should implement Serializable interface
		   //					2. add import java.io.Serializable;
		   //					3. FileInputStream fileIn = new FileInputStream(file path);
		   //					4. ObjectInputStream in = new ObjectInputStream(fileIn);
		   //					5. objectName = (Class) in.readObject();
		   //					6. in.close(); fileIn.close();
		   //					---------------------------------------------------------------
		
		User user = null;
		try {
			FileInputStream fileIn = new FileInputStream("C:\\Users\\the11\\OneDrive\\Desktop\\java\\learning\\71-80\\76_Serialization\\UserInfo.ser");
			ObjectInputStream in = new ObjectInputStream(fileIn);
			user = (User) in.readObject();
			in.close();
			fileIn.close();
			
			System.out.println(user.name + " " + user.password); // the shared classes need to be exactly the same.
			user.greeting();
			
			
			
			 // important notes	1. children classes of a parent class that implements Serializable will do so as well
			   //					2. static fields are not serialized (they belong to the class, not an individual object)
			   //					3. Fields declared as "transient" aren't serialized, they're ignored
			   //					4. the class's definition ("class file") itself is not recorded, cast it as the object type
			   //					5. serialVersionUID is a unique version ID 
			
			
			
			
			
			 //SerialVersionUID =	serialVersionUID is a unique ID that functions like a version #
			   //					verifies that the sender and receiver of a serialized object,
			   //					have loaded classes for that object that are compatible
			   //					Ensures object will be compatible between machines
			   //					Number must match. otherwise this will cause a InvalidClassException
			   //					A SerialVersionUID will be calculated based on class properties, members, etc.
			   //					A serializable class can declare its own serialVersionUID explicitly (recommended)
			 long serialVersionUID = ObjectStreamClass.lookup(user.getClass()).getSerialVersionUID();
		     System.out.println("serialVersionUID: "+serialVersionUID);
		} catch(FileNotFoundException e) {
			// If the file is not found, recreate the file and initialize a new User object
		    user = new User(); // Create a new User object
		    user.name = "Jenne"; // Set default values
		    user.password = "password1234";

		    // Serialize the new User object to create the file
		    try {
		        FileOutputStream fileOut = new FileOutputStream("C:\\Users\\the11\\OneDrive\\Desktop\\java\\learning\\71-80\\76_Serialization\\UserInfo.ser");
		        ObjectOutputStream out = new ObjectOutputStream(fileOut);
		        out.writeObject(user);
		        out.close();
		        fileOut.close();
		        System.out.println("New file created with default user data.");
		    } catch (IOException ex) {
		        // Handle exception if unable to create the file
		        ex.printStackTrace();
		        System.out.println("Error creating new file.");
		    }

		    // Print a message indicating that default user data is being used
		    System.out.println("Default user data loaded: " + user.name + " " + user.password);
		} catch (IOException ex) {
		    // Handle other IOExceptions
		    ex.printStackTrace();
		}
		
		
	}

}
