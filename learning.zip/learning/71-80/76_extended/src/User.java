import java.io.Serializable;

public class User implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// username and password
	String name;
	String password;
	//transient String word = "mmm";
	
	public void greeting() {
		System.out.println("Hello " + name);
	}
	
	

}
