import javax.swing.*;
public class MyFrame extends JFrame {
	MyPanel panel;
	
	MyFrame(){
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		panel = new MyPanel(); // this is necessary.
		add(panel);
		pack();
		setLocationRelativeTo(null);
		setVisible(true);
	}

}
