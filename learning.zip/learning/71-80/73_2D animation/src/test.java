import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class test extends JPanel implements ActionListener {
    private int x = 0;
    private int y = 0;
    private int xVelocity = 1;
    private int yVelocity = 1;

    public test() {
        Timer timer = new Timer(10, this);
        timer.start();
    }

    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.setColor(Color.BLUE);
        g.fillOval(x, y, 50, 50); // Draw a blue circle
    }

    public void actionPerformed(ActionEvent e) {
        x += xVelocity; // Update the x position
        y += yVelocity; // Update the y position

        // Reverse direction if the circle reaches the edge of the panel
        if (x >= getWidth() - 50 || x <= 0) {
            xVelocity = -xVelocity;
        }
        if (y >= getHeight() - 50 || y <= 0) {
            yVelocity = -yVelocity;
        }

        repaint(); // Request repaint to update the animation
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Simple Animation");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 400);

        test animation = new test();
        frame.add(animation);
        frame.setVisible(true);
    }
}