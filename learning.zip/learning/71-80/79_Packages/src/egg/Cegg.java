package egg;

public class Cegg {

}
