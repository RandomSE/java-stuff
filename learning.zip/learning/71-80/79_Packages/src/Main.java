import egg.Cegg;

public class Main {

	public static void main(String[] args) {
		Cegg egg = new Cegg();

	}

}
