import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
    	
    	
    	//bounded types = 	you can create the objects of a generic class to have data  of specific derived types ex.Number			
    	
        // Creating a box for a rectangle
        Box<Rectangle> rectangleBox = new Box<>(new Rectangle(5, 3));
        Rectangle rectangle = rectangleBox.getItem();
        System.out.println("Area of Rectangle: " + rectangle.area());

        // Creating a box for a circle
        Box<Circle> circleBox = new Box<>(new Circle(4));
        Circle circle = circleBox.getItem();
        System.out.println("Area of Circle: " + circle.area());

        // Creating a list of shapes
        List<Shape> shapeList = new ArrayList<>();
        shapeList.add(new Rectangle(4, 6));
        shapeList.add(new Circle(3));

        // Calculating and printing the total area of all shapes
        double totalArea = getTotalArea(shapeList);
        System.out.println("Total area of all shapes: " + totalArea);
    }

    // A method that calculates the total area of a list of shapes
    public static double getTotalArea(List<? extends Shape> shapes) {
        double totalArea = 0;
        for (Shape shape : shapes) {
            totalArea += shape.area();
        }
        return totalArea;
    }
}