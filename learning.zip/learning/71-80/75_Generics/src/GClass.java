

// Defining a generic class called Box
class Box<T> { // T is unspecified type; Implies it can work with ANY data type.
    private T item;

    // Constructor to initialize the item in the box
    public Box(T item) {
        this.item = item;
    }

    // Method to get the item from the box
    public T getItem() {
        return item;
    }

    // Method to set a new item in the box
    public void setItem(T item) {
        this.item = item;
    }
}

// A generic interface for any shape
interface Shape {
    double area();
}

// A generic class representing a rectangle
class Rectangle implements Shape {
    private double length;
    private double width;

    // Constructor
    public Rectangle(double length, double width) {
        this.length = length;
        this.width = width;
    }

    // Method to calculate the area of the rectangle
    @Override
    public double area() {
        return length * width;
    }
}

// A generic class representing a circle
class Circle implements Shape {
    private double radius;

    // Constructor
    public Circle(double radius) {
        this.radius = radius;
    }

    // Method to calculate the area of the circle
    @Override
    public double area() {
        return Math.PI * radius * radius;
    }
}
