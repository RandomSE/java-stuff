import javax.swing.JFrame;

class MyFrame extends JFrame {
    private MyPanel panel;

    MyFrame() {
        setTitle("Advanced Graphics Demo");
        panel = new MyPanel();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        add(panel);
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }
}