import java.awt.*;
import javax.swing.JPanel;

class MyPanel extends JPanel {
    MyPanel() {
        setPreferredSize(new Dimension(600, 600));
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        Graphics2D g2D = (Graphics2D) g; // to make it 2d 

        // Set anti-aliasing for smoother graphics
        g2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Draw gradient background
        drawGradientBackground(g2D);

        // Draw complex shapes
        drawComplexShapes(g2D);
    }

    private void drawGradientBackground(Graphics2D g2D) {
        // Create a gradient paint for background
        GradientPaint gradient = new GradientPaint(0, 0, Color.BLUE, getWidth(), getHeight(), Color.CYAN);
        g2D.setPaint(gradient);
        g2D.fillRect(0, 0, getWidth(), getHeight());
    }

    private void drawComplexShapes(Graphics2D g2D) {
        // Draw a star
        int[] xPoints = {300, 325, 400, 350, 375, 300, 225, 250, 200, 275};
        int[] yPoints = {150, 225, 250, 325, 400, 350, 400, 325, 250, 225};
        g2D.setColor(Color.YELLOW);
        g2D.fillPolygon(xPoints, yPoints, 10);

        // Draw a rotated rectangle
        g2D.setColor(Color.GREEN);
        g2D.rotate(Math.toRadians(45), 400, 400); // Rotate around the center of the rectangle
        g2D.fillRect(350, 350, 100, 50);
        g2D.rotate(-Math.toRadians(45), 400, 400); // Reset rotation

        // Draw a transparent circle
        g2D.setColor(new Color(255, 0, 0, 128)); // Red with 50% transparency
        g2D.fillOval(150, 200, 200, 200);
        
        g2D.setFont(new Font("Comic Sans", 500, 25)); // first int doesn't change much.
        g2D.drawString("2d stuff", 100,100);
    }
}