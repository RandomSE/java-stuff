import java.util.Calendar;
import java.util.Timer;
import java.util.TimerTask;

public class Main {

	public static void main(String[] args) {
		// Timer: facility for threads to schedule tasks.
		
		// Timer task: task, scheduled for a execution by a timer.
		Timer timer = new Timer();
		TimerTask task = new TimerTask() { // abstract, has to use run.

			int counter = 10;
			@Override
			public void run() {
				if(counter>0) {
					System.out.println(counter+" seconds");
					counter--;
				}
				else {
					System.out.println("And... done.");
					timer.cancel(); // because closing console window does nothing.
				}
				
				
			}
			
		};
		
		//timer.schedule(task, 1000);
		Calendar date = Calendar.getInstance();
		date.set(Calendar.YEAR,2024);
		date.set(Calendar.MONTH,Calendar.APRIL);
		date.set(Calendar.DAY_OF_MONTH,5);
		date.set(Calendar.HOUR_OF_DAY,11);
		date.set(Calendar.MINUTE,6);
		date.set(Calendar.SECOND,2);
		date.set(Calendar.MILLISECOND, 345);
		
		
		System.out.println("Waiting.");
		
		
		//timer.schedule(task, date.getTime());
		//timer.scheduleAtFixedRate(task, 0, 10000);
		timer.scheduleAtFixedRate(task, date.getTime(), 1000);

	}

}
