public class Main {
	// Threads: The smallest unit of execution in a process. Does one task at a time.
	// Threads will run until they die, or the exit method for the class has been called. Threads can be assigned priority.
	// You can name Threads, with Thread.currentThread().setName()"name";
	
	// Daemon threads run in the background to perform tasks; low priority.
	// Multi Threading: Using multiple threads to perform one task.

    public static void main(String[] args) {
        // Number of threads to create
        int numThreads = 15;

        // Create and start multiple threads
        for (int i = 0; i < numThreads; i++) {
            Thread thread = new Thread(new WorkerThread("Thread-" + (i + 1)));
            thread.start();
        }
    }

    // WorkerThread class implements Runnable for executing tasks
    static class WorkerThread implements Runnable {// could also make a seperate class and then instantiate here.
        private static volatile int activeThreadCount = 0;
        private String name;

        public WorkerThread(String name) {
            this.name = name;
        }

        @Override
        public void run() {
            try {
                System.out.println(name + " starting...");
                incrementActiveThreadCount();

                // Simulate some work
                Thread.sleep(2000); // Sleep for 2 seconds

            } catch (InterruptedException e) {
                e.printStackTrace();
            } finally {
                decrementActiveThreadCount();
                System.out.println(name + " finishing...");
            }
        }

        private synchronized void incrementActiveThreadCount() {
            activeThreadCount++;
            System.out.println("Active threads: " + activeThreadCount);
        }

        private synchronized void decrementActiveThreadCount() {
            activeThreadCount--;
            System.out.println("Active threads: " + activeThreadCount);
        }
    }
}
