import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class Game {
    JFrame frame;
    JLabel label;
    Action upAction;
    Action downAction;
    Action leftAction;
    Action rightAction;

    Game() {
        // Create the frame
        frame = new JFrame("KeyBinding Demo");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1080, 720);
        frame.getContentPane().setBackground(Color.BLACK);
        frame.setLayout(null);

        // Create the label
        label = new JLabel();
        label.setBackground(Color.GREEN);
        label.setBounds(720, 480, 150, 150);
        label.setOpaque(true);

        // Create key actions
        upAction = new UpAction();
        downAction = new DownAction();
        leftAction = new LeftAction();
        rightAction = new RightAction();

        // Bind keys
        bindKey(label, "W", "upAction");
        bindKey(label, "S", "downAction");
        bindKey(label, "A", "leftAction");
        bindKey(label, "D", "rightAction");
        bindKey(label, KeyEvent.VK_UP, "upAction");
        bindKey(label, KeyEvent.VK_DOWN, "downAction");
        bindKey(label, KeyEvent.VK_LEFT, "leftAction");
        bindKey(label, KeyEvent.VK_RIGHT, "rightAction");

        // Add components to the frame
        frame.add(label);
        frame.setVisible(true);
    }

    // Method to bind a key
    private void bindKey(JComponent component, String keyStroke, String actionMapKey) {
        component.getInputMap().put(KeyStroke.getKeyStroke(keyStroke), actionMapKey);
        component.getActionMap().put(actionMapKey, getActionForKey(actionMapKey));
    }

    // Overloaded method to bind arrow keys
    private void bindKey(JComponent component, int keyCode, String actionMapKey) {
        component.getInputMap().put(KeyStroke.getKeyStroke(keyCode, 0), actionMapKey);
        component.getActionMap().put(actionMapKey, getActionForKey(actionMapKey));
    }

    // Method to get the appropriate action for a key
    private Action getActionForKey(String actionMapKey) {
        switch (actionMapKey) {
            case "upAction":
                return upAction;
            case "downAction":
                return downAction;
            case "leftAction":
                return leftAction;
            case "rightAction":
                return rightAction;
            default:
                return null;
        }
    }

    // Nested classes for key actions
    public class UpAction extends AbstractAction {
        @Override
        public void actionPerformed(ActionEvent e) {
            label.setLocation(label.getX(), label.getY() - 20);
        }
    }

    public class DownAction extends AbstractAction {
        @Override
        public void actionPerformed(ActionEvent e) {
            label.setLocation(label.getX(), label.getY() + 20);
        }
    }

    public class LeftAction extends AbstractAction {
        @Override
        public void actionPerformed(ActionEvent e) {
            label.setLocation(label.getX() - 20, label.getY());
        }
    }

    public class RightAction extends AbstractAction {
        @Override
        public void actionPerformed(ActionEvent e) {
            label.setLocation(label.getX() + 20, label.getY());
        }
    }
}