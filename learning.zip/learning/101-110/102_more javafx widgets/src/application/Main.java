package application;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        // Create layout
        VBox root = new VBox(10);
        root.setPadding(new Insets(20));

        // Checkbox
        CheckBox checkBox = new CheckBox("Enable Feature");
        checkBox.setSelected(true);
        root.getChildren().add(checkBox);

        // RadioButtons
        ToggleGroup radioButtonGroup = new ToggleGroup();

        RadioButton radioButton1 = new RadioButton("Option 1");
        radioButton1.setToggleGroup(radioButtonGroup);
        radioButton1.setSelected(true);

        RadioButton radioButton2 = new RadioButton("Option 2");
        radioButton2.setToggleGroup(radioButtonGroup);

        root.getChildren().addAll(radioButton1, radioButton2);

        // DatePicker
        DatePicker datePicker = new DatePicker();
        root.getChildren().add(datePicker);

        // ColorPicker
        ColorPicker colorPicker = new ColorPicker(Color.BLACK);
        root.getChildren().add(colorPicker);

        // Event handling for ColorPicker
        colorPicker.setOnAction(e -> {
            Color chosenColor = colorPicker.getValue();
            System.out.println("Selected Color: " + chosenColor.toString());
        });

        // Set up scene and show stage
        Scene scene = new Scene(root, 300, 250);
        primaryStage.setTitle("Simple JavaFX App");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
