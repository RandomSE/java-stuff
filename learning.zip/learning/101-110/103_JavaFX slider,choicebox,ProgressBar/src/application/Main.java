package application;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.Slider;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) {
        // Create ChoiceBox with options
        ChoiceBox<String> choiceBox = new ChoiceBox<>();
        choiceBox.getItems().addAll("Lasagne", "Vegetarian burger", "Chicken salad");
        choiceBox.setValue("Lasagne"); // Default selection

        // Create Slider
        Slider slider = new Slider(0, 100, 0);
        slider.setShowTickLabels(true);
        slider.setShowTickMarks(true);

        // Create ProgressBar
        ProgressBar progressBar = new ProgressBar(0);

        // Bind ProgressBar to Slider value
        progressBar.progressProperty().bind(slider.valueProperty().divide(100));

        // Listen for changes in ProgressBar progress
        progressBar.progressProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue.doubleValue() >= 1.0) { // only when it is full
                showOrderReceivedMessage();
            }
        });

        // Layout setup
        VBox root = new VBox(10);
        root.setPadding(new Insets(20));
        root.getChildren().addAll(choiceBox, slider, progressBar);

        // Create scene and set stage
        Scene scene = new Scene(root, 1080, 720);
        primaryStage.setTitle("Yes the progress bar can go backwards");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void showOrderReceivedMessage() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Order Received");
        alert.setHeaderText(null);
        alert.setContentText("Your order has been received!");
        alert.showAndWait();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
