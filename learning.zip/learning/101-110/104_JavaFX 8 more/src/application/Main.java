package application;
import javafx.animation.TranslateTransition;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.util.Duration;

public class Main extends Application {

    private Scene animationScene; // Declare animationScene at the class level

    @Override
    public void start(Stage primaryStage) {
        // Create a Spinner
        Spinner<Integer> spinner = new Spinner<>(1, 10, 1);

        // Create a ListView
        ListView<String> listView = new ListView<>();
        listView.getItems().addAll("Pasta", "Rice", "other grains");

        // Create a TreeView
        TreeItem<String> rootItem = new TreeItem<>("Root");
        TreeView<String> treeView = new TreeView<>(rootItem);
        rootItem.getChildren().addAll(new TreeItem<>("C"), new TreeItem<>("Java"));

        // Create a MenuBar
        Menu menu = new Menu("File");
        MenuItem exitMenuItem = new MenuItem("Exit");
        exitMenuItem.setOnAction(event -> {
            primaryStage.close(); // Close the application
        });
        menu.getItems().add(exitMenuItem);
        MenuBar menuBar = new MenuBar(menu);

        // Create a FlowPane with buttons
        Button button1 = new Button("Animation");
        button1.setOnAction(event -> {
            System.out.println("Button 1 clicked!");
            primaryStage.setScene(animationScene); // Switch to the animated scene
        });

        Button button2 = new Button("Button 2");
        button2.setOnAction(event -> {
            System.out.println("Button 2 clicked! (doesn't do anything)");
        });

        FlowPane flowPane = new FlowPane(button1, button2);

        // Create a GridPane
        GridPane gridPane = new GridPane();
        gridPane.add(new Label("Name:"), 0, 0);
        gridPane.add(new TextField(), 1, 0);

        // Create an animation (e.g., rectangle moving animation)
        Rectangle rect = new Rectangle(50, 50, Color.BLUE);
        Pane animationPane = new Pane(rect);
        animationScene = new Scene(animationPane, 300, 200); // Initialize animationScene

        TranslateTransition transition = new TranslateTransition(Duration.seconds(2), rect);
        transition.setByX(200);
        transition.setCycleCount(TranslateTransition.INDEFINITE);
        transition.setAutoReverse(true);
        transition.play();

        // Set the main scene
        VBox mainLayout = new VBox(menuBar, spinner, listView, treeView, flowPane, gridPane);
        Scene mainScene = new Scene(mainLayout, 600, 400);

        primaryStage.setTitle("JavaFX Program");
        primaryStage.setScene(mainScene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
