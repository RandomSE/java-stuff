import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class Main {
    private Queue<String> documentQueue;

    public Main() {
        documentQueue = new LinkedList<>();
    }

    public void addDocument(String document) {
        documentQueue.offer(document); // Adds document to the end of the queue
        System.out.println("Document added to the printing queue: " + document);
    }

    public void printNextDocument() {
        if (!documentQueue.isEmpty()) {
            String nextDocument = documentQueue.poll(); // Retrieves and removes the head of the queue
            System.out.println("Printing: " + nextDocument);
        } else {
            System.out.println("Printing queue is empty. No documents to print.");
        }
    }

    public static void main(String[] args) {
        Main printer = new Main();
        Scanner scanner = new Scanner(System.in);

        System.out.println("Printing Queue Simulation (Type 'add <document>' to add document, 'print' to print next):");

        while (true) {
            System.out.print("> ");
            String input = scanner.nextLine().trim();

            if (input.startsWith("add ")) {
                String document = input.substring(4);
                printer.addDocument(document);
            } else if (input.equals("print")) {
                printer.printNextDocument();
            } else {
                System.out.println("Invalid command. Try again.");
            }
        }
    }
}
