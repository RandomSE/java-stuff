import java.util.LinkedList;

public class Main {
    public static void main(String[] args) {
        // Create a LinkedList of integers
        LinkedList<Integer> linkedList = new LinkedList<>();

        // Add elements to the LinkedList
        linkedList.add(10);
        linkedList.add(20);
        linkedList.add(30);
        linkedList.add(40);

        // Print the LinkedList
        System.out.println("Initial LinkedList: " + linkedList);

        // Add an element at a specific index
        linkedList.add(2, 25);
        System.out.println("After adding 25 at index 2: " + linkedList);

        // Remove an element from the LinkedList
        linkedList.remove(3);
        System.out.println("After removing element at index 3: " + linkedList);

        // Get and modify an element in the LinkedList
        int oldValue = linkedList.get(1); // Get element at index 1 (20)
        linkedList.set(1, oldValue * 2); // Multiply by 2 and update
        System.out.println("After modifying element at index 1: " + linkedList);

        // Check if LinkedList contains a specific element
        boolean contains30 = linkedList.contains(30);
        System.out.println("LinkedList contains 30: " + contains30);

        // Get the size of the LinkedList
        int size = linkedList.size();
        System.out.println("Size of LinkedList: " + size);

        // Iterate over the LinkedList using enhanced for loop
        System.out.print("LinkedList elements (using for loop): ");
        for (Integer num : linkedList) {
            System.out.print(num + " ");
        }
        System.out.println(); // Move to next line

        // Clear the LinkedList
        linkedList.clear();
        System.out.println("LinkedList after clearing: " + linkedList);
    }
}
