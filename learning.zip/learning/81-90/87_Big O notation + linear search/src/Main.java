import java.util.Arrays;

public class Main {

    public static void main(String[] args) {
        // Array sizes for testing
        int[] arraySizes = {1000, 5000, 10000, 20000};

        // Test sorting algorithms and linear search on arrays of different sizes
        for (int size : arraySizes) {
            int[] array = generateRandomArray(size);

            // Measure time taken by Bubble Sort
            long startTimeBubbleSort = System.nanoTime();
            bubbleSort(array.clone()); // clone to avoid modifying original array
            long endTimeBubbleSort = System.nanoTime();
            long bubbleSortTime = endTimeBubbleSort - startTimeBubbleSort;

            // Measure time taken by Merge Sort
            long startTimeMergeSort = System.nanoTime();
            mergeSort(array.clone()); // clone to avoid modifying original array
            long endTimeMergeSort = System.nanoTime();
            long mergeSortTime = endTimeMergeSort - startTimeMergeSort;

            // Measure time taken by Linear Search
            int searchKey = array[size - 1]; // Search for the last element in the array
            long startTimeLinearSearch = System.nanoTime();
            int linearSearchIndex = linearSearch(array, searchKey);
            long endTimeLinearSearch = System.nanoTime();
            long linearSearchTime = endTimeLinearSearch - startTimeLinearSearch;

            // Output results
            System.out.println("Array Size: " + size);
            System.out.println("Bubble Sort Time: " + bubbleSortTime + " nanoseconds");
            System.out.println("Merge Sort Time: " + mergeSortTime + " nanoseconds");
            System.out.println("Linear Search Time: " + linearSearchTime + " nanoseconds");
            System.out.println("Linear Search Index: " + linearSearchIndex);
            System.out.println();
        }
    }

    // Helper method to generate a random integer array of given size
    private static int[] generateRandomArray(int size) {
        int[] array = new int[size];
        for (int i = 0; i < size; i++) {
            array[i] = (int) (Math.random() * 1000); // random values between 0 and 999
        }
        return array;
    }

    // Bubble Sort implementation
    private static void bubbleSort(int[] array) {
        int n = array.length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (array[j] > array[j + 1]) {
                    // Swap elements
                    int temp = array[j];
                    array[j] = array[j + 1];
                    array[j + 1] = temp;
                }
            }
        }
    }

    // Merge Sort implementation
    private static void mergeSort(int[] array) {
        if (array.length > 1) {
            int mid = array.length / 2;
            int[] left = Arrays.copyOfRange(array, 0, mid);
            int[] right = Arrays.copyOfRange(array, mid, array.length);

            mergeSort(left);
            mergeSort(right);

            merge(array, left, right);
        }
    }

    private static void merge(int[] array, int[] left, int[] right) {
        int i = 0, j = 0, k = 0;
        while (i < left.length && j < right.length) {
            if (left[i] <= right[j]) {
                array[k++] = left[i++];
            } else {
                array[k++] = right[j++];
            }
        }
        while (i < left.length) {
            array[k++] = left[i++];
        }
        while (j < right.length) {
            array[k++] = right[j++];
        }
    }

    // Linear Search implementation
    private static int linearSearch(int[] array, int key) {
        for (int i = 0; i < array.length; i++) {
            if (array[i] == key) {
                return i; // Return index of the key if found
            }
        }
        return -1; // Key not found
    }
}
