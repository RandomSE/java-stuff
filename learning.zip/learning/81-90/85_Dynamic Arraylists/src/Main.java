import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class Main extends JFrame {
	// Dynamic because it is not static; The size can be changed after run time.

    private ArrayList<String> itemList;
    private DefaultListModel<String> listModel;
    private JList<String> itemListView;

    public Main() {
        itemList = new ArrayList<>();
        listModel = new DefaultListModel<>();

        // Create and configure the GUI components
        setTitle("Dynamic ArrayList GUI");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Create list view to display items
        itemListView = new JList<>(listModel);
        JScrollPane scrollPane = new JScrollPane(itemListView);
        add(scrollPane, BorderLayout.CENTER);

        // Panel for buttons
        JPanel buttonPanel = new JPanel(new FlowLayout());

        // Button to add an item
        JButton addButton = new JButton("Add Item");
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String newItem = JOptionPane.showInputDialog("Enter item:");
                if (newItem != null && !newItem.isEmpty()) {
                    itemList.add(newItem);
                    updateItemList();
                }
            }
        });

        // Button to remove selected item
        JButton removeButton = new JButton("Remove Selected");
        removeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedIndex = itemListView.getSelectedIndex();
                if (selectedIndex != -1) {
                    itemList.remove(selectedIndex);
                    updateItemList();
                }
            }
        });

        buttonPanel.add(addButton);
        buttonPanel.add(removeButton);

        add(buttonPanel, BorderLayout.SOUTH);

        // Set initial size and visibility
        setSize(720, 480);
        setLocationRelativeTo(null); // Center the window
        setVisible(true);
    }

    // Update the list view with current itemList
    private void updateItemList() {
        listModel.clear();
        for (String item : itemList) {
            listModel.addElement(item);
        }
    }

    public static void main(String[] args) {
        // Use Event Dispatch Thread to ensure thread safety with Swing components
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Main();
            }
        });
    }
}
