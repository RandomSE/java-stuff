import java.util.Stack;
import java.util.Scanner;

public class Main {
    private StringBuilder currentText;
    private Stack<String> undoStack;

    public Main() {
        currentText = new StringBuilder();
        undoStack = new Stack<>();
    }

    public void appendText(String text) {
        currentText.append(text);
        undoStack.push("append " + text);
        System.out.println("Current Text: " + currentText.toString());
    }

    public void undo() {
        if (!undoStack.isEmpty()) {
            String lastAction = undoStack.pop();
            if (lastAction.startsWith("append")) {
                String appendedText = lastAction.substring(7);
                currentText.delete(currentText.length() - appendedText.length(), currentText.length());
            }
            System.out.println("Undo performed. Current Text: " + currentText.toString());
        } else {
            System.out.println("Nothing to undo.");
        }
    }

    public static void main(String[] args) {
        Main editor = new Main();
        Scanner scanner = new Scanner(System.in);

        System.out.println("Simple Text Editor (Type 'append <text>' to add text, 'undo' to undo):");

        while (true) {
            System.out.print("> ");
            String input = scanner.nextLine().trim();

            if (input.startsWith("append ")) {
                String text = input.substring(7);
                editor.appendText(text);
            } else if (input.equals("undo")) {
                editor.undo();
            } else {
                System.out.println("Invalid command. Try again.");
            }
        }
    }
}
