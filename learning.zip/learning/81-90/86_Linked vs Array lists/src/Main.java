import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class Main {

    public static void main(String[] args) {
        // Create an ArrayList and a LinkedList of integers
        List<Integer> arrayList = new ArrayList<>();
        List<Integer> linkedList = new LinkedList<>();

        // Add elements to the ArrayList
        long arrayListAddTime = addElementsToList(arrayList, 100000);
        System.out.println("ArrayList add time: " + arrayListAddTime + " ms");

        // Add elements to the LinkedList
        long linkedListAddTime = addElementsToList(linkedList, 100000);
        System.out.println("LinkedList add time: " + linkedListAddTime + " ms");

        // Access elements in the ArrayList
        long arrayListAccessTime = accessElementsInList(arrayList, 10000);
        System.out.println("ArrayList access time: " + arrayListAccessTime + " ms");

        // Access elements in the LinkedList
        long linkedListAccessTime = accessElementsInList(linkedList, 10000);
        System.out.println("LinkedList access time: " + linkedListAccessTime + " ms");
    }

    // Helper method to add elements to a list and measure time
    private static long addElementsToList(List<Integer> list, int count) {
        long startTime = System.currentTimeMillis();

        for (int i = 0; i < count; i++) {
            list.add(i);
        }

        long endTime = System.currentTimeMillis();
        return endTime - startTime;
    }

    // Helper method to access elements in a list and measure time
    private static long accessElementsInList(List<Integer> list, int count) {
        long startTime = System.currentTimeMillis();

        int size = list.size();
        for (int i = 0; i < count; i++) {
            int index = i % size; // Ensure index stays within bounds
            list.get(index);
        }

        long endTime = System.currentTimeMillis();
        return endTime - startTime;
    }
}
