import java.util.*;

public class Main {
    public static void main(String[] args) {
        // Custom comparator for numeric ordering of strings
        Comparator<String> numericComparator = new Comparator<String>() {
            @Override
            public int compare(String s1, String s2) {
                // Convert strings to integers for comparison
                int num1 = Integer.parseInt(s1);
                int num2 = Integer.parseInt(s2);
                return Integer.compare(num1, num2); // Compare integers
            }
        };
        
        // Priority Queue with custom comparator for numerical ordering
        Queue<String> queue = new PriorityQueue<>(numericComparator);
        
        // Add strings to the queue
        queue.offer("17");
        queue.offer("6");
        queue.offer("233");
        queue.offer("12");
        queue.offer("1");
        queue.offer("10343");
        
        // Poll elements from the queue (should be ordered numerically)
        while (!queue.isEmpty()) {
            System.out.println(queue.poll());
        }
    }
}