import java.util.Scanner;

public class Main {
    
    // Interpolation search function to find if target exists in the array
    public static boolean interpolationSearch(int[] array, int target) {
        int low = 0;
        int high = array.length - 1;
        
        while (low <= high && target >= array[low] && target <= array[high]) {
            // Calculate the position using interpolation formula
            int pos = low + ((target - array[low]) * (high - low)) / (array[high] - array[low]);
            
            if (array[pos] == target) {
                return true; // Target found
            } else if (array[pos] < target) {
                low = pos + 1; // Discard the left part
            } else {
                high = pos - 1; // Discard the right part
            }
        }
        
        return false; // Target not found
    }
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Sorted array for interpolation search (example)
        int[] sortedArray = {10, 20, 30, 40, 50, 60, 70, 80, 90, 100};
        
        System.out.println("Enter a number to search:");
        int target = scanner.nextInt();
        
        boolean found = interpolationSearch(sortedArray, target);
        
        if (found) {
            System.out.println("The number " + target + " is present in the array.");
        } else {
            System.out.println("The number " + target + " is not present in the array.");
        }
        
        scanner.close();
    }
}
