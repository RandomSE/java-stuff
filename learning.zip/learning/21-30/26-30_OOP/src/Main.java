
public class Main {
	
	static String test() {
		// variable scope: local vs global
				// Local: declared within a method, visible only to that method.
				// Global: declared outside a method but in a class. visible anywhere in the class.
        String s1 = "AHH";
        return s1;
    }
	

	public static void main(String[] args) {
		// object : an instance of a class, contains attributes and methods.
		Car car1 = new Car("Toyota", "Camry", 2017, "Gray", 120000, 200, 20, 20); // updated with constructor
		Car car2 = new Car("Tesla", "Cyberfailure", 2022, "Gray", 750000, 250, 30, 30);
		
		car1.do_nothing();
		car2.do_nothing();
		
		
		
		
		/*  // interestingly you can comment before comment blocks to nullify them
		
		//System.out.println(car1.toString());
		car1.start_engine(); // should add a button or clickable widget to do this, or some form of GUI.
		car1.accelerate();
		
		
		//System.out.println(car2.toString());
		car2.start_engine();
		car2.accelerate(); car2.accelerate();
		car1.accelerate();
		
		*/
		
		
		
		
		

		 String test1 = test();
	    // System.out.println(s1); // does not work because local
	     System.out.println(test1); // works because global

			
		
		
		
		
		
	
		
		
		// object passing
		Garage garage = new Garage();
		Car mini_car = new Car("Tesla");
		garage.park(mini_car);
		

		
		
	    //inheritance
			Car bicycle = new Car("Harley", 20, true );
			bicycle.setName("Rude guest");
			Inheritance.Bicycle bicycle1 = new Inheritance.Bicycle();
			
			bicycle.start_engine();
			garage.park(bicycle);
			
			
			
			
		bicycle1.speak(); // does not need to be overridden
		
		
		
		// Abstract methods: dont need to name it Abstract, but eh it works.
		Abstract.Cat cat1 = new Abstract.Cat();
		cat1.eat();
		//Abstract animal = new Abstract(); // does not work; because its abstract.
		
		// copying
		Car car3 = new Car("random car");
		car3.copy(car2);
		//System.out.println(car3.toString());
		car3.do_nothing();
		
		
		
		
		
		// polymorphism: the ability of an object to identify as more than one type.
		/*
		 
		Train train1 = new Train();
		Garage [] speakers = {car1, train1, cat1, garage, bicycle1}; // Car, Train and Abstract extend to garage.
		
		for (Garage x : speakers) {
			x.speak(); // the objects will use the Garage.speak method if one is not made for them.
			
			
		}
		
		*/
		
		
		// dynamic polymorphism: polymorphism after runtime
		
		/*
		Encapsulation newEncap = new Encapsulation();
		String animalName = newEncap.checkAnimal();
		
		if (animalName.equals("smolcat")) {
			System.out.println("You chose: "  + animalName);
			Abstract.Cat smolcat = new Abstract.Cat();
			smolcat.exist();
			
		}
		else if (animalName.equals("newcat")) {
			System.out.println("You chose: "  + animalName);
			Abstract.Cat newcat = new Abstract.Cat();
			newcat.exist();
			
		}
		else if (animalName.equals("newlizard")) {
			System.out.println("You chose: "  + animalName);
			Abstract.Lizard newlizard = new Abstract.Lizard();
			newlizard.exist();
			
		}
		
		*/ // to simplify, I could put cat and lizard in the same subclass under different names. hmm. this would means I could use less lines of code.
		
		
		
		
		
		
		
		
		
		
	    
	}
	
	  
	




	
		
		
		
		
		// constructors: special method called when object is instantiated.
	
		
	
	
	//Food plain_pizza = new Food("Margherita Pizza", false, false, true, 5.26, 9.63, 46.26 , 0.67 , 275); // one
	//Food zucchini_bread = new Food("The zucc", true, true, true); // two
	
	
	
	
	
	
}
