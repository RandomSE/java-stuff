
public class Food {
  
	
	
	
    String name; // nutritional info is per 100g
    boolean hypoallergenic;
    boolean gluten_free;
    boolean halal;
    double fat_content;
    double protein_content;
    double carb_content;
    double sugar_content;
    int calories;

	// overloaded constructors: multiple constructors but with different parameters.
    // this one is nutritional info + checks
	public Food(String name, boolean hypoallergenic, boolean gluten_free, boolean halal, double fat_content, double protein_content, double carb_content, double sugar_content, int calories ) {
	this.name = name;
	this.hypoallergenic = hypoallergenic ;
	this.gluten_free = gluten_free ;
	this.halal = halal ;
	this.fat_content = fat_content ;
	this.protein_content = protein_content;
	this.carb_content = carb_content ;
	this.sugar_content = sugar_content;
	this.calories = calories ;
	System.out.println("One");
	}

	
	public Food(String name, boolean hypoallergenic, boolean gluten_free, boolean halal) {
		// just checks
		this.name = name;
		this.hypoallergenic = hypoallergenic;
		this.gluten_free = gluten_free;
		this.halal = halal;
		System.out.println("Two");
		
	}
	
	// abstract: abstract classes cannot be instantiated, but they can have a subclass. they are declared without an implementation.
		
		
		
	
}
