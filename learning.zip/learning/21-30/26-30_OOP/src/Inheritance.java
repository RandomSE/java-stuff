
public class Inheritance extends Garage{// extends Garage does not work in this context

	// inheritance: process where one class inherits the methods and attributes of another class.
	public static class Bicycle extends Car{
		Bicycle(){
			// super: refers to the superclass of an object. similar to the "this" keyword.
			super("");// also super for some overriding
			
			
			if (wheels != 2  || has_roof == true) {
				System.out.println("What kind of a bicycle does not have 2 wheels, or has a roof...?");
				wheels = 2;
				has_roof = false;
				
				
				
				
			}
			if (getName().isEmpty()) {
			System.out.println("The bicycle has wheels. Wheels: " + wheels + "  contains a roof: " + has_roof);
				
			}
			else {
			System.out.println(getName() + ".   Wheels: " + wheels + "  contains a roof: " + has_roof ); // name value is null for some reason
			
			}
			
		}
		// override also used for things like toString
		// @Override // actually not needed
		void speak() {
			System.out.println("It's a bicycle. it does not speak.");
			
		}
		
		
		
	}
}
