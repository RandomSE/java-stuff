
public class Garage {
 
	  void park(Car car) {
		  if (car.getName() !=null) { 
		  System.out.println("The " +car.getName() +" has been parked by the valet.");
		  //car.speak();
		  }
		  else {
			  System.out.println("The car you chose does not have a name variable.");
		  }
		  if (car.getRunning()) {
			  
		  }
	  }
	  void speak() {
		  System.out.println("It's a non-talking garage.");
	  }
	  
}
