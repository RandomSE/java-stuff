
public abstract class  Abstract extends Garage{ // all subclasses in Abstract can extend to Garage as well.

	
	// abstract: abstract classes cannot be instantiated, but they can have a subclass. they are declared without an implementation.
	// good for security: an example is animal vs specific type of animal. animal is vague.
	
	abstract void eat() ;
	
	
	
	// subclass
	public static class Cat extends Abstract{ // needs to have static and the inheritance.
		void eat() {
			System.out.println("The cat consumes food for nourishment.");
		}
		void speak() {
			System.out.println("The cat meows"); // without this method, cat.speak will revert to garage.speak ;
		}
		void exist() {
			// nothing
		}
		
	}
	
	public static class Lizard extends Abstract{
		void eat() {
			System.out.println("The lizard eats.");
		}
		
		void speak() {
			System.out.println("The lizard hisses.");
		}
		void exist() {
			// nothing
		}
	}
}
