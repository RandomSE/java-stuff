import java.util.Scanner;
import java.util.InputMismatchException;
public class Encapsulation {
 //encapsulation: attributes of a class will be made private/hidden, meaning they can only be accessed via methods(such as setters and getters.
	// It is common practice to make attributes private if there is no reason for them to be public, as it is more secure, which is a selling point of Java.
	
	
	// updated the Car, Garage and Inheritance classes 
	
	
	// as its currently unused, using this class for dynamic polymorphism
	
	public String checkAnimal() {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Choose an animal: 1 = Cat,   2 = Lizard.    put only the number 1 or the number 2.");
		
		String sAnimal = "smolcat"; // in case incorrect input 
		try {
		int iAsk = scanner.nextInt();
		scanner.nextLine();
		String sAsk = Integer.toString(iAsk);		
		
		
		if (sAsk.equals("1")){
		sAnimal = "newcat";	
		}
		else if (sAsk .equals("2")) {
		sAnimal = "newlizard"	;
		}
		else {
			System.out.println("You did not input 1 or 2, but you did input an integer.");
		}
		} catch (InputMismatchException e) {
			System.out.println("You did not input 1 or 2."); // e.getMessage() is not helpful here.
		   // e.printStackTrace();
			
		
		
		}finally{
			scanner.close();
				
			
		}
		return sAnimal;
		
		
		
		
		
		
		
	}
	
}
