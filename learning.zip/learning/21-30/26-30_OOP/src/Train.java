
public class Train extends Garage {
	@Override
	void speak() {
		System.out.println("Choo Choo");
	}

}
