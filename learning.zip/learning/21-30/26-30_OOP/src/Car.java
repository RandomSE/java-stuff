
public class Car extends Garage{ // reasons. java does not support multiple inheritance.

	// dont need static void main.
	
	private String make = "Toyota"; // can be private as is only used here
	private String model = "Camry";
	private int year = 2017;
	private String colour = "Gray";
	private int price = 120000 ;
	private int max_velocity = 200;
	private int accel = 20; // how much the car accelerates per use of accelerate
	private int decel = 20; // how much the car decelerates per use of brake
	
	
    private boolean running = false;  // along with wheels, has_roof and name cannot be private (used outside class) // until getters/setters are used.
	private int velocity = 0; 
	
	// for object passing:
	private String name;
	
	// for inheritance:
	int wheels = 4;
	Boolean has_roof = true;
	

	
	
	public Car(String make, String model, int year, String colour, int price, int max_velocity, int accel, int decel){
		this.setMake(make);
		this.setModel(model);
		this.setYear(year)  ;
		this.setColour(colour)  ;
		this.setPrice(price)  ;
		this.setMax_velocity(max_velocity)  ;
		this.setAccel(accel)  ;
		this.setDecel(decel)  ;
		this.setRunning() ;
		this.setVelocity() ;
		// replaced with set methods
		
	}
	
	public Car(String name) {
		this.name = name;
	}
	
	public Car(String name, int wheels, Boolean has_roof) {
		this.name = name;
		this.wheels = wheels;
		this.has_roof = has_roof;
		
	}
	
    void drive() {
    	
    	
        if (running){
    	System.out.println("You are driving.");
        }
        else if(!running) {
        	System.out.println("You need to start the engine to drive.");
        }
    }
    
    void start_engine() {
    	if (!running) {
    		running = true;
    		System.out.println("You start the engine for the " + make + " " + model);
    	}
    	else if(running) {
    		System.out.println("The engine is already running for the ."  + make + " " + model);
    	}
    }
    
    void stop_engine() {
        if (running) {
        	running = false;
        	System.out.println("You turn off the car engine for the ."  + make + " " + model);
    		
    	}
    	
    	else if(!running) {
    		System.out.println("The car engine is already off for the ."  + make + " " + model);
    		
    	}
    }
    
    void accelerate() {
    	
    	
    	if (running) {
    		if (velocity < max_velocity - accel) { // to prevent it going over max
    			velocity = velocity + accel;
    			System.out.println("You accelerate. the "  + make + " " + model +" current speed: " +velocity + "  kph");
    			
    		}
    		else {
    			velocity = max_velocity; // in case max_velocity is not a multiple of accel.
    			System.out.println("You are already at max speed of: " + max_velocity  + " kph");
    		}
    		
    	}
    	
    	else if(!running) {
    		System.out.println("The car is not running.");
    	}
    	
    }
    
    void brake() {
    	
        if (running) {
        	
        	if (velocity >= decel) {
        		velocity = velocity - decel;
        		System.out.println("you slow down.");
        	}
        	else if (velocity <decel && velocity > 0) {
        		velocity = 0;
        		System.out.println("You are not moving anymore.");
        		
        	}
        	else if (velocity <0) {
        		System.out.println("An error has occurred."); // should not happen.
        		velocity = 0;
        		
        	}
    		
    	}
    	
    	else if(!running) {
    		System.out.println("The car is not running.");
    		
    	}
    }
    
    
    // toString:
    public String toString() {
		return "Info: \n" 
				+ "Make: " +make +"\n" +
				"Model: " + year + " " + model + "\n" + 
				"Colour: " + colour + "\n" +
				"Price: " + price + "\n" +
				"Max velocity: " + max_velocity + "\n" +
				"Acceleration: " + accel + "KPH Per second" + "\n" +
				"Deceleration: " + decel + "KPH Per second";
    	
    }
    
    void speak() {
    	System.out.println("It's a car. it does not speak.");
    }
    public boolean getRunning() {
    	return running;
    }
    
    public int getVelocity() {
    	return velocity;
    }
    
    public String getName() {
    	return name;
    }
    
    public int getWheels() {
    	return wheels;
    }
    
    public boolean getHas_roof() {
    	return has_roof;
    }
    
    void do_nothing() {
    	// to get rid of yellow warnings
    }
    public void  setName(String newName) {
    	name = newName;
    }
    
    public void setMake(String make) {
    	this.make = make;
    }
    
    public void setModel(String model) {
    	this.model = model;
    }
    
    public void setYear(int year) {
    	this.year = year ;
    }

    public void setColour(String colour) {
    	this.colour = colour ;
    }

    public void setPrice(int price) {
    	this.price = price ;
    }

    public void setMax_velocity(int max_velocity) {
    	this.max_velocity = max_velocity ;
    }

    public void setAccel(int accel) {
    	this.accel = accel ;
    }

    public void setDecel(int decel) {
    	this.decel = decel ;
    }

    public void setRunning() {
    	this.running = false ;
    }

    public void setVelocity() {
    	this.velocity = 0 ;
    }
    // copy
    
    public void copy(Car used) {
    	this.setMake(used.make);
		this.setModel(used.model);
		this.setYear(used.year)  ;
		this.setColour(used.colour)  ;
		this.setPrice(used.price)  ;
		this.setMax_velocity(used.max_velocity)  ;
		this.setAccel(used.accel)  ;
		this.setDecel(used.decel)  ;
		this.setRunning() ;
		this.setVelocity() ;
    	
    	
    }
    
    
}
