
public class Main {

	public static void main(String[] args) {
		// overloaded methods: methods that share same name but different parameters. method name + method parameters = method signature
		String name = "Jer";
		int age = Integer.MAX_VALUE / 2;
		//String sMessage = message(name, age);
		String sMessage = message(name, age, false);
		String check = message("Ethan", (Integer.MAX_VALUE/3)-2, "Endings can also be new beginnings."); // overloaded checks both number and data type of the arguments
		System.out.println(sMessage);
		System.out.println(check);

	}
	
	static String message(String name, int age) {
		return "Your message has been sent to: " + name +", aged " + age + " seconds";
		
	}
	
	/* static String message(String many, int num) {
		return "Your message has been sent to: " + name +", aged " + age + " seconds";
		
	}
	*/  // appears it's not the name that matters, but the data types. curious.
	
	static String message(String name, int age, String why) {
		return "Your message has been sent to: " + name +", aged " + age + " seconds. You are receiving this message because " + why;
		
	}
	
	static String message(String name, int age, Boolean reply) {
		
		String notice = null;
		
		if (reply) {
		notice = "Your message has been sent to: " + name +", aged " + age + " seconds. If you would like to stop receiving these messages, prove the Riemann hypothesis.";
		}
		else {
		notice = "Your message has been sent to: " + name +", aged " + age + " seconds. Please do not reply to this message."	;
		}
		
		return notice;
		
	}
	
	
	

}
