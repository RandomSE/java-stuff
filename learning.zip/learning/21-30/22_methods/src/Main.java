
public class Main {

	
	public static void main(String[] args) {
		// method: block of code that runs when it is called upon. Very useful if you don't want thousands of lines of repetitive code.
		String name = "AHHHHHHHH";
		int num = 77;
		String greetings = greeting(name, num);// the inside brackets are for args, typically used in the methods
		System.out.println(greetings);

	}
	
	static String greeting(String name, int num) { // main is static, so to call a method it needs to be static as well.
		return "wooAAA " +name + " " + num ;
		// java methods are more effort than python methods.
		
	}

}
