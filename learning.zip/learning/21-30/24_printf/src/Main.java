
public class Main {

	public static void main(String[] args) {
		// printf() = 	an optional method to control, format, and display text to the console window
				//				two arguments = format string + (object/variable/value)
				//				% [flags] [precision] [width] [conversion-character]
		
		
		/* flags: adds an effect to the output based on flag added to the format:
		- (Minus): Left-justify the argument within the specified width. By default, values are right-justified.

		+ (Plus): Include a sign (+ or -) for numeric values. For positive numbers, a plus sign will be prepended.

		0 (Zero): For numeric values, pad with leading zeros instead of spaces to meet the width specified.

		, (Comma): Include locale-specific grouping separators (like commas in English) in numeric values.
		
		*/
		
		// width: minimum num of chars to be output. e.g: System.out.printf("Hello. have an %3s", word ) ;
		// precision: number of digits after decimal point for floats/doubles: "%.2f" , dub
		
		
		boolean Check = true;
		char th = 'e';
		int num = 107;
		String word = "Egg" ;
		double dub = 3000.14;
		
		System.out.printf("test %d ing %n" , num); // d: where the integer is. cannot be used with doubles.
		// other conversion specifiers: %b, boolean; %c, char; %s, string; %f, double;
		
		
		// example:
		System.out.printf("and the number is: %,.2f%n", dub  ); // , should add ,'s but instead adds a space...?
		// or:
		String formatted = String.format("Number: %-5d, double: %,.2f" , num, dub);
		System.out.println(formatted);
		
		
		
		
		// also adding final keyword here
		final double PI = 3.141592653589793238462643383279502884197169399375105820974944592307816406286 ;
		// cannot change the value after using the final keyword. Common practice to name the var in UPPERCASE.
		
		
		

	}

}
