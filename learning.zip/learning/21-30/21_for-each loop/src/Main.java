
import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {
		// for-each loop: iterating through each element in a list/array. Less steps, more readable but less flexible.
		
		
		
		// nope. 
		ArrayList<String> birds1 = new ArrayList<String>();
		birds1.add("Penguin");
		birds1.add("Ostrich");
		birds1.add("Quail");
		birds1.add("Chicken");
		birds1.add("Dove");
		

		
		for (String i : birds1 ) {
			System.out.println(i); // saves i as the element, instead of getting the elements from collection
		}
	}

}
