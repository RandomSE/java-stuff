public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// program will not run without this method. VERY important.
		// can copy the error message verbatim + add {}
		// seems pretty similar to python so far

		 System.out.print("ah \n");
		 // can be hotkeyed typing sysout  + ctrl + space
		 /*
		     other escape sequences: \t -> adds space  
		  
		      \"  \"  -> shows the quotes.
		      \\ shows one backslash
		   
		  */
		 System.out.println("And so, it begins!");
	}

}
