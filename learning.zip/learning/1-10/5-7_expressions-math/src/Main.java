import javax.swing.JOptionPane;
public class Main {

	public static void main(String[] args) {
		/*
		  
		 /
		// expressions: operators and operands
		// operands: values, variables, numbers and quantities.
		// operators: + * - / %
		
		int acquaintances = 10;
		acquaintances = acquaintances * 2 ;  // for ints, not recommend to divide unless you use round.
		int remainder = (int) Math.floor(acquaintances % (7/2)); // % is MOD, or it gives you the remainder. needs the int cast.
		acquaintances --; // -1, can also do ++ for +1.
		System.out.println(remainder);
		
		*/
		
		
		
		
		/*
		//basic GUI- needs import javax.swing.JOptionPane
		
		String name = JOptionPane.showInputDialog("What is your name?")  ;
		JOptionPane.showMessageDialog(null, "Hello: "+ name);
		
		int age = Integer.parseInt(JOptionPane.showInputDialog("What is your age?")); // parseINT takes the int specifically
		JOptionPane.showMessageDialog(null, "Your age in years: "+ age);  // should probably use a try.. except block 
		
		double height = Double.parseDouble(JOptionPane.showInputDialog("What is your height in CM?")); 
		JOptionPane.showMessageDialog(null, "Your height in CM: "+ height);
		
		*/
		
		// maths stuff
		
		double x = Double.parseDouble(JOptionPane.showInputDialog("Input side A")); 
		double y = Double.parseDouble(JOptionPane.showInputDialog("Input side B.")); 
		double z = Math.max(x, y);   // also sqrt, abs, min, ceil, floor, round,  etc.
		System.out.println("Of " + x +" and " + y + ", " + z + " is the biggest.");
		double hypotenuse = Math.sqrt( (x * x) + (y*y) ); // only works for 90 deg triangles.
		System.out.println(hypotenuse);
				
		

	}

}
