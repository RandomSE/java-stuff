// import java.util.Random;
import java.util.Scanner;
public class Main {

	private static final Scanner SCANNER = new Scanner(System.in); // constant scanner.

	public static void main(String[] args) {
		
		
		/*
		 * 
		// random: requires import java.util.Random;
		Random random = new Random();  // pseudo random
		int x = random.nextInt(20) + 1;
		double ran = random.nextDouble(301);
		// can also do with boolean
		System.out.println(x);
		System.out.println(ran);
		
		*/
		
		// if statements: performs a block of code if the condition/conditions are met.
		
		
		/*
		System.out.println("What is your age?");
		int age = SCANNER.nextInt();
		
		if (age >= 18) {
			
			if (age >=64) {
				System.out.println("Boomer.");
			}
			else {
			System.out.println("adult.");
			}
			
			
		}
		else {
			System.out.println("minor.");
		}
		
		*/
		
		
		
		
		// switches: statement. allows variables to be tested for equal against a list of values.
		
		System.out.println("What day is it today?");
		String day = SCANNER.nextLine();
		day = day.toLowerCase(); // in case capitalised.
		
		switch(day) {
		case "monday":
			System.out.println("it is: " + day);
			break;
			
		case "tuesday":
			System.out.println("it is: " + day);
			break;
			
		case "wednesday":
			System.out.println("it is: " + day);
			break;
			
		case "thursday":
			System.out.println("it is: " + day);
			break;
			
		case "friday":
			System.out.println("it is: " + day);
			break;
			
		case "saturday":
			System.out.println("it is: " + day);
			break;
			
		case "sunday":
			System.out.println("it is: " + day);
			break;
			
		default: 
        System.out.println("You did not put a valid day in. You input: " + day);
		
		
		}
		
		
		
		

	}
	

}
