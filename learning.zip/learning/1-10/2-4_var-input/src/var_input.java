import java.util.Scanner;
public class var_input {

	public static void main(String[] args) {
		
		
		// basic variables
		/*
		// to use  a var, you need to declare, then assign, or initialize which does both.
		int x = 100 ;
		System.out.println("x = " + x);
		
		int max = 2147483647 ;
		System.out.println(max+1);
		// for numbers above/below int limits use long data type. put L at end of value...?
		
		long hh = 9223372036854775807L; // maximum value of long integer . 9.223372036854775807 × 10^18
		System.out.println(hh+1);
		
		double pi2 = 3.14 ; // f needed at the end when using floats. doubles are preferred for precision.
		
		boolean  check = false;
		
		char symbol = 'e'; // single ''
		String copypasta = "According to all known laws of aviation, there is no way a bee should be able to fly.\r\n"
				+ "Its wings are too small to get its fat little body off the ground.\r\n"
				+ "The bee, of course, flies anyway because bees don't care what humans think is impossible." ;
		System.out.println(copypasta);
		*/
		
		
		
		
		
		// swapping: requires 3 vars, one of which being temporary.
		
		/*
		int one = 73;
		int two = 49;
		int temp;
		
		temp = one;
		one = two;
		two = temp;
		
		System.out.println(one + "  " + two);
		
		*/
		
		
		
		// user input:  at top of class use:   import java.util.Scanner;
		
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Name?");
		String name = scanner.nextLine();
		System.out.println("greetings, " + name);
		
		System.out.println("age?");
		int age = scanner.nextInt();
		System.out.println("You are " + age +" years old.");
		scanner.nextLine();
		
		System.out.println("Favourite food?");
		String ffood = scanner.nextLine() ;
		System.out.println("Your favourite food is " + ffood);
		
		scanner.close();
		
		
		
		
		

	}

}
