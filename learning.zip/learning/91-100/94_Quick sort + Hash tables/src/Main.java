import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;

public class Main extends JFrame {

    private JTextArea inputArea;
    private JTextArea outputArea;

    public Main() {
        setTitle("QuickSort & HashTable Example");
        setSize(1080, 720);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());

        JLabel inputLabel = new JLabel("Enter numbers (separated by spaces):");
        inputArea = new JTextArea(5, 30);
        JScrollPane inputScrollPane = new JScrollPane(inputArea);

        JButton sortButton = new JButton("Sort & Count");
        sortButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String inputText = inputArea.getText().trim();
                if (!inputText.isEmpty()) {
                    int[] numbers = parseNumbers(inputText);
                    quickSort(numbers, 0, numbers.length - 1);
                    displaySortedArray(numbers);
                }
            }
        });

        JLabel outputLabel = new JLabel("Sorted numbers with frequency:");
        outputArea = new JTextArea(10, 30);
        outputArea.setEditable(false);
        JScrollPane outputScrollPane = new JScrollPane(outputArea);

        panel.add(inputLabel, BorderLayout.NORTH);
        panel.add(inputScrollPane, BorderLayout.CENTER);
        panel.add(sortButton, BorderLayout.SOUTH);
        panel.add(outputLabel, BorderLayout.WEST);
        panel.add(outputScrollPane, BorderLayout.EAST);

        add(panel);
    }

    private int[] parseNumbers(String input) {
        String[] parts = input.split("\\s+");
        int[] numbers = new int[parts.length];
        for (int i = 0; i < parts.length; i++) {
            numbers[i] = Integer.parseInt(parts[i]);
        }
        return numbers;
    }

    private void quickSort(int[] arr, int low, int high) {
        if (low < high) {
            int pivotIndex = partition(arr, low, high);
            quickSort(arr, low, pivotIndex - 1);
            quickSort(arr, pivotIndex + 1, high);
        }
    }

    private int partition(int[] arr, int low, int high) {
        int pivot = arr[high];
        int i = low - 1;
        for (int j = low; j < high; j++) {
            if (arr[j] <= pivot) {
                i++;
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
        int temp = arr[i + 1];
        arr[i + 1] = arr[high];
        arr[high] = temp;
        return i + 1;
    }

    private void displaySortedArray(int[] sortedArray) {
        Map<Integer, Integer> frequencyMap = new HashMap<>();
        StringBuilder output = new StringBuilder();

        for (int num : sortedArray) {
            output.append(num).append(", ");
            frequencyMap.put(num, frequencyMap.getOrDefault(num, 0) + 1);
        }

        output.delete(output.length() - 2, output.length()); // Remove the last ", "
        output.append("\n\nFrequency:\n");

        for (Map.Entry<Integer, Integer> entry : frequencyMap.entrySet()) {
            output.append(entry.getKey()).append(": ").append(entry.getValue()).append("\n");
        }

        outputArea.setText(output.toString());
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Main().setVisible(true);
            }
        });
    }
}
