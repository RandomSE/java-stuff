import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Main extends JFrame implements ActionListener {

    private JButton dfsButton;
    private JButton bfsButton;
    private JButton showTreeButton;

    public Main() {
        setTitle("Tree Search Application");
        setSize(1080, 720);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Create buttons
        dfsButton = new JButton("Depth First Search");
        bfsButton = new JButton("Breadth First Search");
        showTreeButton = new JButton("Show Tree Data Structures");

        // Add action listeners to buttons
        dfsButton.addActionListener(this);
        bfsButton.addActionListener(this);
        showTreeButton.addActionListener(this);

        // Set layout using BorderLayout
        setLayout(new BorderLayout());

        // Create panel for buttons
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(3, 1));
        buttonPanel.add(dfsButton);
        buttonPanel.add(bfsButton);
        buttonPanel.add(showTreeButton);

        // Add button panel to the center of the frame
        add(buttonPanel, BorderLayout.CENTER);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == dfsButton) {
            // Perform Depth First Search (DFS) action
            DFS.performDFS();
        } else if (e.getSource() == bfsButton) {
            // Perform Breadth First Search (BFS) action
            BFS.performBFS();
        } else if (e.getSource() == showTreeButton) {
            // Show tree data structures action
            BinaryTree.displayTreeDataStructure();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Main app = new Main();
            app.setVisible(true);
        });
    }
}
