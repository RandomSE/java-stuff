class TreeNode {
    int val;
    TreeNode left;
    TreeNode right;

    TreeNode(int x) {
        val = x;
    }
}

public class BinaryTree {

    public static void displayTreeDataStructure() {
        // Create a sample binary tree
        TreeNode root = new TreeNode(1);
        root.left = new TreeNode(2);
        root.right = new TreeNode(3);
        root.left.left = new TreeNode(4);
        root.left.right = new TreeNode(5);

        System.out.println("Binary Tree structure:");
        displayTree(root);
    }

    private static void displayTree(TreeNode root) {
        if (root != null) {
            System.out.println(root.val);
            displayTree(root.left);
            displayTree(root.right);
        }
    }
}