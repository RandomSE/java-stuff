import java.util.*;

public class DFS {

    public static void performDFS() {
        // graph represented as an adjacency list
        Map<Integer, List<Integer>> graph = new HashMap<>();
        graph.put(0, Arrays.asList(1, 2));
        graph.put(1, Arrays.asList(3));
        graph.put(2, Arrays.asList(4));
        graph.put(3, Arrays.asList());
        graph.put(4, Arrays.asList(5));
        graph.put(5, Arrays.asList());

        Set<Integer> visited = new HashSet<>();
        System.out.println("Depth First Search (DFS) traversal:");
        dfsHelper(0, graph, visited);
    }

    private static void dfsHelper(int node, Map<Integer, List<Integer>> graph, Set<Integer> visited) {
        if (!visited.contains(node)) {
            System.out.println(node);
            visited.add(node);
            for (int neighbor : graph.get(node)) {
                dfsHelper(neighbor, graph, visited);
            }
        }
    }
}
