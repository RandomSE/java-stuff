import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;

public class Main {
    
    private static JTextField inputField;
    private static JTextArea outputArea;
    
    // Selection Sort function to sort the array of integers
    public static void selectionSort(int[] array) {
        int n = array.length;
        
        for (int i = 0; i < n - 1; i++) {
            int minIndex = i;
            
            // Find the index of the minimum element in the remaining unsorted array
            for (int j = i + 1; j < n; j++) {
                if (array[j] < array[minIndex]) {
                    minIndex = j;
                }
            }
            
            // Swap the found minimum element with the first element of the unsorted array
            int temp = array[minIndex];
            array[minIndex] = array[i];
            array[i] = temp;
        }
    }
    
    public static void main(String[] args) {
        // Create the main frame for the GUI
        JFrame frame = new JFrame("Selection Sort Application");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1080, 720);
        frame.setLayout(new BorderLayout());
        
        // Panel for input components (text field and button)
        JPanel inputPanel = new JPanel(new FlowLayout());
        JLabel inputLabel = new JLabel("Enter numbers (separated by commas):");
        inputField = new JTextField(20);
        JButton sortButton = new JButton("Sort");
        
        // Add action listener to the sort button
        sortButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Get input text from the text field
                String inputText = inputField.getText().trim();
                
                // Parse input string into an array of integers
                int[] array = Arrays.stream(inputText.split(","))
                                    .map(String::trim)
                                    .mapToInt(Integer::parseInt)
                                    .toArray();
                
                // Perform Selection Sort on the array
                selectionSort(array);
                
                // Display the sorted array in the output text area
                outputArea.setText(Arrays.toString(array));
            }
        });
        
        inputPanel.add(inputLabel);
        inputPanel.add(inputField);
        inputPanel.add(sortButton);
        
        // Panel for output text area
        JPanel outputPanel = new JPanel(new BorderLayout());
        JLabel outputLabel = new JLabel("Sorted Array:");
        outputArea = new JTextArea(10, 30);
        outputArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(outputArea);
        
        outputPanel.add(outputLabel, BorderLayout.NORTH);
        outputPanel.add(scrollPane, BorderLayout.CENTER);
        
        // Add input and output panels to the main frame
        frame.add(inputPanel, BorderLayout.NORTH);
        frame.add(outputPanel, BorderLayout.CENTER);
        
        // Display the main frame
        frame.setVisible(true);
    }
}
