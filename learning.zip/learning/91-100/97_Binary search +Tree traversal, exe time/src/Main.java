

public class Main {

    // Binary search function to search for a key in a sorted array
    public static int binarySearch(int[] arr, int key) {
        int left = 0;
        int right = arr.length - 1;

        while (left <= right) {
            int mid = left + (right - left) / 2;

            if (arr[mid] == key) {
                return mid; // Key found at index 'mid'
            } else if (arr[mid] < key) {
                left = mid + 1; // Search in the right half
            } else {
                right = mid - 1; // Search in the left half
            }
        }

        return -1; // Key not found
    }

    // Node class for Binary Search Tree (BST)
    static class TreeNode {
        int val;
        TreeNode left;
        TreeNode right;

        TreeNode(int val) {
            this.val = val;
            this.left = null;
            this.right = null;
        }
    }

    // Function to perform inorder traversal of a BST
    public static void inorderTraversal(TreeNode root) {
        if (root == null)
            return;

        inorderTraversal(root.left);
        System.out.print(root.val + " ");
        inorderTraversal(root.right);
    }

    // Main method to demonstrate binary search, tree traversal, and execution time calculation
    public static void main(String[] args) {
        // Binary search example
        int[] sortedArray = {1, 3, 5, 7, 9, 11, 13, 15};
        int searchKey = 7;
        long startTime = System.currentTimeMillis();
        int result = binarySearch(sortedArray, searchKey); // Searches for the searchKey inside of the array.
        long endTime = System.currentTimeMillis();

        System.out.println("Binary Search:");
        if (result != -1) {
            System.out.println("Key " + searchKey + " found at index " + result);
        } else {
            System.out.println("Key " + searchKey + " not found");
        }
        System.out.println("Binary Search Execution Time: " + (endTime - startTime) + " milliseconds");

        // Binary Search Tree (BST) example
        TreeNode root = new TreeNode(8);
        root.left = new TreeNode(3);
        root.right = new TreeNode(10);
        root.left.left = new TreeNode(1);
        root.left.right = new TreeNode(6);
        root.right.right = new TreeNode(14);

        System.out.println("\nInorder Traversal of Binary Search Tree:");
        startTime = System.currentTimeMillis();
        inorderTraversal(root);
        endTime = System.currentTimeMillis();
        System.out.println("\nInorder Traversal Execution Time: " + (endTime - startTime) + " milliseconds");
    }
}
