import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class Main extends JFrame {

    private GraphPanel graphPanel;
    private JTextArea adjacencyMatrixArea;
    private JTextArea adjacencyListArea;

    public Main() {
        setTitle("Graph Visualization");
        setSize(1080, 720);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new BorderLayout());

        // Create graph panel for visualization
        graphPanel = new GraphPanel();
        mainPanel.add(graphPanel, BorderLayout.CENTER);

        // Create panel for displaying adjacency matrix and adjacency list
        JPanel infoPanel = new JPanel(new GridLayout(1, 2));

        adjacencyMatrixArea = new JTextArea(20, 20);
        adjacencyMatrixArea.setEditable(false);
        JScrollPane matrixScrollPane = new JScrollPane(adjacencyMatrixArea);
        infoPanel.add(matrixScrollPane);

        adjacencyListArea = new JTextArea(20, 20);
        adjacencyListArea.setEditable(false);
        JScrollPane listScrollPane = new JScrollPane(adjacencyListArea);
        infoPanel.add(listScrollPane);

        mainPanel.add(infoPanel, BorderLayout.EAST);

        add(mainPanel);
    }

    // Method to update the adjacency matrix and adjacency list display
    private void updateInfo(Graph graph) {
        adjacencyMatrixArea.setText(graph.getAdjacencyMatrixString());
        adjacencyListArea.setText(graph.getAdjacencyListString());
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Main frame = new Main();
            frame.setVisible(true);

            // Create a sample graph
            Graph graph = new Graph(6);
            graph.addEdge(0, 1);
            graph.addEdge(0, 2);
            graph.addEdge(1, 2);
            graph.addEdge(1, 3);
            graph.addEdge(2, 4);
            graph.addEdge(3, 4);
            graph.addEdge(4, 5);

            // Update the graph panel and information display
            frame.graphPanel.setGraph(graph);
            frame.updateInfo(graph);
        });
    }
}

class Graph {

    private int[][] adjacencyMatrix;
    private ArrayList<ArrayList<Integer>> adjacencyList;

    public Graph(int numVertices) {
        adjacencyMatrix = new int[numVertices][numVertices];
        adjacencyList = new ArrayList<>(numVertices);
        for (int i = 0; i < numVertices; i++) {
            adjacencyList.add(new ArrayList<>());
        }
    }

    public void addEdge(int u, int v) {
        adjacencyMatrix[u][v] = 1;
        adjacencyMatrix[v][u] = 1;
        adjacencyList.get(u).add(v);
        adjacencyList.get(v).add(u);
    }

    public int[][] getAdjacencyMatrix() {
        return adjacencyMatrix;
    }

    public String getAdjacencyMatrixString() {
        StringBuilder sb = new StringBuilder();
        for (int[] row : adjacencyMatrix) {
            for (int value : row) {
                sb.append(value).append(" ");
            }
            sb.append("\n");
        }
        return sb.toString();
    }

    public String getAdjacencyListString() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < adjacencyList.size(); i++) {
            sb.append(i).append(": ");
            for (int neighbor : adjacencyList.get(i)) {
                sb.append(neighbor).append(" ");
            }
            sb.append("\n");
        }
        return sb.toString();
    }
}

class GraphPanel extends JPanel {

    private Graph graph;

    public GraphPanel() {
        setBackground(Color.WHITE);
    }

    public void setGraph(Graph graph) {
        this.graph = graph;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        if (graph == null) {
            return;
        }

        int numVertices = graph.getAdjacencyMatrix().length;
        int radius = 30;
        int centerX = getWidth() / 2;
        int centerY = getHeight() / 2;
        double angleStep = 2 * Math.PI / numVertices;

        // Draw vertices
        for (int i = 0; i < numVertices; i++) {
            int x = (int) (centerX + 200 * Math.cos(i * angleStep));
            int y = (int) (centerY + 200 * Math.sin(i * angleStep));
            g.setColor(Color.BLUE);
            g.fillOval(x - radius, y - radius, 2 * radius, 2 * radius);
            g.setColor(Color.BLACK);
            g.drawString(String.valueOf(i), x - 5, y + 5);
        }

        // Draw edges based on adjacency matrix
        for (int i = 0; i < numVertices; i++) {
            for (int j = i + 1; j < numVertices; j++) {
                if (graph.getAdjacencyMatrix()[i][j] == 1) {
                    int x1 = (int) (centerX + 200 * Math.cos(i * angleStep));
                    int y1 = (int) (centerY + 200 * Math.sin(i * angleStep));
                    int x2 = (int) (centerX + 200 * Math.cos(j * angleStep));
                    int y2 = (int) (centerY + 200 * Math.sin(j * angleStep));
                    g.setColor(Color.RED);
                    g.drawLine(x1, y1, x2, y2);
                }
            }
        }
    }
}
