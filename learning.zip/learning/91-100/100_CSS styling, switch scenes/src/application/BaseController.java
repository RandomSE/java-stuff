package application;

public class BaseController {

    private Main mainApp;

    public void setMainApp(Main mainApp) {
        this.mainApp = mainApp;
    }

    protected void loadScene(String fxmlFile) {
        mainApp.loadScene(fxmlFile);
    } 
}
