package application;

import javafx.fxml.FXML;

public class MainController extends BaseController {

    @FXML
    private void handleScene1() {
        loadScene("Scene1.fxml");
    }

    @FXML
    private void handleScene2() {
        loadScene("Scene2.fxml");
    }

    @FXML
    private void handleScene3() {
        loadScene("Scene3.fxml");
    }
}
