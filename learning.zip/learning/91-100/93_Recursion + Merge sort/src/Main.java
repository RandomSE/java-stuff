import java.util.Arrays;

public class Main {
    
    // Merge Sort function to sort the array of integers
    public static void mergeSort(int[] array) {
        if (array == null || array.length <= 1) {
            return; // Array with 0 or 1 element is already sorted
        }
        
        // Calculate mid index to divide the array into two halves
        int mid = array.length / 2;
        
        // Create left and right subarrays
        int[] leftArray = Arrays.copyOfRange(array, 0, mid);
        int[] rightArray = Arrays.copyOfRange(array, mid, array.length);
        
        // Recursively sort the left and right subarrays
        mergeSort(leftArray);
        mergeSort(rightArray);
        
        // Merge the sorted left and right subarrays
        merge(array, leftArray, rightArray);
    }
    
    // Merge function to merge two sorted subarrays into a single sorted array
    private static void merge(int[] array, int[] leftArray, int[] rightArray) {
        int i = 0; // Index for left subarray
        int j = 0; // Index for right subarray
        int k = 0; // Index for merged array
        
        // Compare elements from leftArray and rightArray and merge them into array
        while (i < leftArray.length && j < rightArray.length) {
            if (leftArray[i] <= rightArray[j]) {
                array[k++] = leftArray[i++];
            } else {
                array[k++] = rightArray[j++];
            }
        }
        
        // Copy remaining elements of leftArray, if any
        while (i < leftArray.length) {
            array[k++] = leftArray[i++];
        }
        
        // Copy remaining elements of rightArray, if any
        while (j < rightArray.length) {
            array[k++] = rightArray[j++];
        }
    }
    
    public static void main(String[] args) {
        int[] array = {12, 11, 13, 5, 6, 7};
        
        System.out.println("Array before sorting: " + Arrays.toString(array));
        
        // Perform Merge Sort
        mergeSort(array);
        
        System.out.println("Array after sorting: " + Arrays.toString(array));
    }
}
