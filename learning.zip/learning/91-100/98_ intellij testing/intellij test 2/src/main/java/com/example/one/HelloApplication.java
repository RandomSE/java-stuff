package com.example.one;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import java.io.IOException;

public class HelloApplication extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        // Create the primary stage (main window)
        primaryStage.setTitle("Main Stage");

        // Create a button to open a new stage
        Button openButton = new Button("Open New Stage");
        openButton.setOnAction(e -> {
            // When the button is clicked, open a new stage
            openNewStage();
        });

        // Add the button to the primary stage
        StackPane primaryLayout = new StackPane(openButton);
        primaryStage.setScene(new Scene(primaryLayout, 300, 200));
        primaryStage.show();
    }

    // Method to open a new stage
    private void openNewStage() {
        // Create a new stage (secondary window)
        Stage secondaryStage = new Stage();
        secondaryStage.setTitle("Secondary Stage");

        // Create content for the secondary stage
        Button closeButton = new Button("Close");
        closeButton.setOnAction(e -> {
            // When the close button is clicked, close the secondary stage
            secondaryStage.close();
        });

        // Add the close button to the secondary stage
        StackPane secondaryLayout = new StackPane(closeButton);
        secondaryStage.setScene(new Scene(secondaryLayout, 200, 150));
        secondaryStage.show();
    }

    public static void main(String[] args) {
        // Launch the JavaFX application
        launch(args);
    }
}