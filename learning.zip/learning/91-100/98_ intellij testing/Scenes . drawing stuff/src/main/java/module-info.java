module com.example.testthree {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.testthree to javafx.fxml;
    exports com.example.testthree;
}