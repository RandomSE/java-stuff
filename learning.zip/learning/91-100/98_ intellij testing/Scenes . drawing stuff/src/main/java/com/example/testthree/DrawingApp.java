package com.example.testthree;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class DrawingApp extends Application {

    @Override
    public void start(Stage primaryStage) {
        // Create a canvas to draw on
        Canvas canvas = new Canvas(800, 600);
        GraphicsContext gc = canvas.getGraphicsContext2D();

        // Set up mouse event handlers for drawing
        setMouseHandlers(canvas, gc);

        // Create a layout pane and add the canvas to the center
        BorderPane root = new BorderPane();
        root.setCenter(canvas);

        // Create a scene with the layout pane as the root node
        Scene scene = new Scene(root, 800, 600);

        // Set the title of the window and display the scene
        primaryStage.setTitle("Simple Drawing App");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void setMouseHandlers(Canvas canvas, GraphicsContext gc) {
        // Handle mouse press to start drawing
        canvas.setOnMousePressed(event -> {
            gc.setStroke(Color.BLACK); // Set the stroke color
            gc.beginPath(); // Begin a new path
            gc.lineTo(event.getX(), event.getY()); // Move to the mouse click position
        });

        // Handle mouse drag to draw lines
        canvas.setOnMouseDragged(event -> {
            gc.lineTo(event.getX(), event.getY()); // Draw a line to the current mouse position
            gc.stroke(); // Stroke the line on the canvas
        });

        // Handle mouse release to finish drawing
        canvas.setOnMouseReleased(event -> {
            gc.closePath(); // Close the path
        });
    }

    public static void main(String[] args) {
        launch(args); // Launch the JavaFX application
    }
}
