import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;

public class MyFrame extends JFrame {

    private JSlider temperatureSlider;
    private JLabel temperatureLabel;

    public MyFrame() {
        setTitle("Temperature Slider Program");
        setSize(200, 400); // Adjusted size for vertical layout
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        setVisible(true);

        // Adjusted range for integer values, multiplied by 10 for displaying 0.1°C increments
        temperatureSlider = new JSlider(JSlider.VERTICAL, -200, 500, 230); 
        temperatureSlider.setMajorTickSpacing(100);
        temperatureSlider.setMinorTickSpacing(10); // Adjusted to 0.1°C increments
        temperatureSlider.setPaintTicks(true);
        temperatureSlider.setPaintLabels(true);

        temperatureLabel = new JLabel("Temperature: " + temperatureSlider.getValue() / 10.0 + "°C"); // Divide by 10 for displaying 0.1°C increments
        temperatureLabel.setHorizontalAlignment(SwingConstants.CENTER);

        temperatureSlider.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                temperatureLabel.setText("Temperature: " + temperatureSlider.getValue() / 10.0 + "°C"); // Divide by 10 for displaying 0.1°C increments
            }
        });

        add(temperatureSlider, BorderLayout.CENTER);
        add(temperatureLabel, BorderLayout.SOUTH);
    }

}