import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

// Main class to demonstrate the usage of Chooser class
public class Main {
    public static void main(String[] args) {
        // Create an instance of Chooser class
        Chooser chooser = new Chooser();

        // Create and configure the JFrame
        JFrame frame = new JFrame("File Chooser Example");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(720, 480);

        // Create a container panel with BorderLayout
        JPanel containerPanel = new JPanel(new BorderLayout());
        frame.setContentPane(containerPanel);

        // Create a label to instruct the user
        JLabel label = new JLabel("Press Ctrl + O to open the file chooser");
        containerPanel.add(label, BorderLayout.NORTH);

        // Make sure the label doesn't grab focus from the key binding
        label.setFocusable(false);

        frame.setVisible(true);

        // Create an Action for opening the file chooser
        Action openAction = new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Call the chooseFile method to select a file
                chooser.chooseFile();
            }
        };

        // Associate the action with the "Ctrl + O" key combination
        KeyStroke keyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_O, KeyEvent.CTRL_DOWN_MASK);
        frame.getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(keyStroke, "openFileChooser");
        frame.getRootPane().getActionMap().put("openFileChooser", openAction);
    }
}