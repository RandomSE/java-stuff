import javax.swing.*;
import java.io.File;

// Chooser class to encapsulate the file choosing logic
public class Chooser {
    public void chooseFile() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setCurrentDirectory(new File(".")); // sets the directory at the project files.

        // Show open dialog; this method blocks until the user chooses a file or cancels the dialog
        int returnValue = fileChooser.showOpenDialog(null);

        if (returnValue == JFileChooser.APPROVE_OPTION) {
            // Get the selected file
            File selectedFile = fileChooser.getSelectedFile();
            System.out.println("Selected file: " + selectedFile.getAbsolutePath());
        } else {
            // If the user cancels the dialog or closes it, print a message
            System.out.println("No file selected.");
        }
    }
}