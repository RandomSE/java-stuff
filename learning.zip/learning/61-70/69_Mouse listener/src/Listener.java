import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

class Listener extends JPanel implements MouseListener, MouseMotionListener {
    private Image image;
    private int imageX, imageY;
    private int mouseX, mouseY;
    private int dx, dy;

    public Listener() {
        image = new ImageIcon("HamCat.jpg").getImage();
        imageX = 100;
        imageY = 100;
        addMouseListener(this);
        addMouseMotionListener(this);
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(image, imageX, imageY, this);
    }

    public void mousePressed(MouseEvent e) {
        dx = 0;
        dy = 0;
        mouseX = e.getX();
        mouseY = e.getY();
    }

    public void mouseDragged(MouseEvent e) {
        int newMouseX = e.getX();
        int newMouseY = e.getY();
        dx += newMouseX - mouseX;
        dy += newMouseY - mouseY;
        mouseX = newMouseX;
        mouseY = newMouseY;
        repaint();
    }

    public void mouseReleased(MouseEvent e) {
        // Stop movement
        dx = 0;
        dy = 0;
        repaint();
    }

    public void mouseClicked(MouseEvent e) {}
    public void mouseEntered(MouseEvent e) {}
    public void mouseExited(MouseEvent e) {}
    public void mouseMoved(MouseEvent e) {}

    public void moveImage() {
        imageX += dx;
        imageY += dy;
        repaint();
    }
}