import javax.swing.*;
class Main {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Moving hamcat");
        Listener listener = new Listener();
        frame.add(listener);
        frame.setSize(1080, 720);
        frame.setVisible(true);

        while (true) {
            listener.moveImage();
            try {
                Thread.sleep(10); // Adjust speed of movement
            } catch (InterruptedException ex) {
                ex.printStackTrace();
            }
        }
    }
}