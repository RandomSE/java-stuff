import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Colors extends JFrame {
    private JButton colorButton;

    public Colors() {
        setTitle("Color Chooser");
        setSize(720, 480);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Create button
        colorButton = new JButton("Choose Color");

        // Add ActionListener to the button
        colorButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Open color chooser dialog
                Color selectedColor = JColorChooser.showDialog(null, "Choose a color", Color.WHITE); // .white is the default.
                if (selectedColor != null) {
                    // Set background color of the frame
                    getContentPane().setBackground(selectedColor);
                }
            }
        });

        // Add button to the frame
        getContentPane().setLayout(new FlowLayout());
        getContentPane().add(colorButton);
    }

    public static void main(String[] args) {
        // Instantiate the Colors class
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Colors().setVisible(true);
            }
        });
    }
}
