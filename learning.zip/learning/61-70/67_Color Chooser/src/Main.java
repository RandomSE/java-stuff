public class Main {
    public static void main(String[] args) {
        // Instantiate the Colors class
    	// color chooser: self explanatory.
        Colors colors = new Colors();
        colors.setVisible(true);
    }
}
