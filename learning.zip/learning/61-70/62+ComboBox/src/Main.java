public class Main{

 public static void main(String[] args) {
 
  // JComboBox = A  swing component. Combines a button or editable field and a drop-down list.
  
  new MyFrame();

 }
}