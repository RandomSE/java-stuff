import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class MyFrame extends JFrame implements ActionListener {

    JComboBox<String> animalComboBox; // declared globally for actionPerformed

    MyFrame() {
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLayout(new FlowLayout());

        String[] animals = {"Dog", "Cat", "Bird", "Dragonfly"};
        animalComboBox = new JComboBox<>(animals);
        animalComboBox.addActionListener(this); // useful
        // 
 

        this.add(animalComboBox);

        this.pack();
        this.setVisible(true);
        this.setSize(720, 480);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        JComboBox<String> comboBox = (JComboBox<String>) e.getSource();
        String selectedAnimal = (String) comboBox.getSelectedItem();
        System.out.println("Selected animal: " + selectedAnimal);
        // get selected index can also be useful.
        // .setSelectedIndex makes one of the items automatically set.
        
    }

   
}
