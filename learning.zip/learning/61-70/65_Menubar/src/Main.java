import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        // Create an instance of MyFrame
        MyFrame frame = new MyFrame("Menu Bar Example");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(720, 480);
        frame.setVisible(true);
        
        // Open and Save doesn't do anything, the others work though.
    }
}