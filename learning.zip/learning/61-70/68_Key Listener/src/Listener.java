import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

class Listener extends JPanel implements KeyListener {
    private int x = 50;
    private int y = 50;
    private int legLength = 30;
    private int armLength = 20;
    private int moveSpeed = 10; // Pixels to move
    private Timer timer;

    public Listener() {
        setPreferredSize(new Dimension(720, 480));
        setBackground(Color.WHITE);
        setFocusable(true);
        addKeyListener(this);

        // Create a timer to continuously move the character
        timer = new Timer(100, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                moveCharacter();
            }
        });
        timer.setInitialDelay(0); // Start moving immediately
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        // Draw body (blue box)
        g.setColor(Color.BLUE);
        g.fillRect(x, y, 20, 20);

        // Draw legs
        g.setColor(Color.BLACK);
        g.drawLine(x + 10, y + 20, x + 10, y + 20 + legLength); // Left leg
        g.drawLine(x + 10, y + 20, x + 5, y + 20 + legLength); // Left foot
        g.drawLine(x + 10, y + 20, x + 15, y + 20 + legLength); // Right foot
        g.drawLine(x + 10, y + 20, x + 10, y + 20 + legLength); // Right leg

        // Draw arms
        g.drawLine(x, y + 10, x - armLength, y + 10); // Left arm
        g.drawLine(x + 20, y + 10, x + 20 + armLength, y + 10); // Right arm
    }

    private void moveCharacter() {
        repaint(); // Redraw the panel to update the character's position
    }

    @Override
    public void keyPressed(KeyEvent e) {
        int keyCode = e.getKeyCode();
        switch (keyCode) {
            case KeyEvent.VK_W:
                y -= moveSpeed;
                break;
            case KeyEvent.VK_A:
                x -= moveSpeed;
                break;
            case KeyEvent.VK_S:
                y += moveSpeed;
                break;
            case KeyEvent.VK_D:
                x += moveSpeed;
                break;
        }
        // Start the timer when a movement key is pressed
        timer.start();
    }

    @Override
    public void keyReleased(KeyEvent e) {
        // Stop the timer when the movement key is released
        timer.stop();
    }

    @Override
    public void keyTyped(KeyEvent e) {
        // Not used
    }
}
