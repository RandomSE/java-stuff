import javax.swing.JFrame;
public class MyFrame extends JFrame {
	
	DragPanel dragpanel = new DragPanel();
	
	
	MyFrame(){
		// no need for this.function here as ambiguity is not an issue and local vars do not share names with global vars.
		setTitle("cat.");
		setSize(1920,1080);
		setDefaultCloseOperation(3); // exit on close
		setVisible(true);
		
		add(dragpanel);
		
	}

}
