
public class Main {
	
	public static void main(String[]args) {
		
		MyFrame myframe = new MyFrame();
	}

}
