import javax.swing.*;
import java.awt.*;

public class HPProgressBar extends JFrame {
    private JProgressBar hpBar;
    private int currentHP;
    private int maxHP;

    public HPProgressBar(int maxHP) {
        super("HP Progress Bar");
        this.maxHP = maxHP;
        this.currentHP = maxHP;

        // Create progress bar
        hpBar = new JProgressBar(0, maxHP);
        hpBar.setStringPainted(true); // to help update
        updateHPBar();

        // Add progress bar to frame
        setLayout(new FlowLayout());
        add(hpBar);

        setSize(300, 100);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    // Method to update the HP progress bar
    public void updateHPBar() {
        hpBar.setValue(currentHP);
        hpBar.setString("HP: " + currentHP + "/" + maxHP);
    }

    // Method to decrease HP
    public void decreaseHP(int amount) {
        currentHP -= amount;
        if (currentHP < 0) {
            currentHP = 0;
        }
        updateHPBar();
    }

    // Method to increase HP
    public void increaseHP(int amount) {
        currentHP += amount;
        if (currentHP > maxHP) {
            currentHP = maxHP;
        }
        updateHPBar();
    }

	public int getCurrentHP() {
		// TODO Auto-generated method stub
		return currentHP;
	}
}
