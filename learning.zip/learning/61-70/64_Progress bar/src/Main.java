import javax.swing.JOptionPane;
public class Main {
    public static void main(String[] args) {
        // Create HPProgressBar object with maximum HP of 100 -> progress bar is self explanatory.
        HPProgressBar hpProgressBar = new HPProgressBar(100);

        // Decrease HP continuously while it's above 0
        while (hpProgressBar.getCurrentHP() > 0) {
            hpProgressBar.decreaseHP(1);
            try {
                Thread.sleep(100); // Sleep for 0.1 seconds (100 milliseconds)
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            
        }
        JOptionPane.showMessageDialog(null, "You died.", "Game over.", JOptionPane.WARNING_MESSAGE);
        
       
    }
}