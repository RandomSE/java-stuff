import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;

public class Main{

	public static void main(String[] args) {

		// Layout Manager = Defines the natural layout for components within a container
		
		// GridLayout = 	places components in a grid of cells. 
		//					Each component takes all the available space within its cell, 
		//					and each cell is the same size. 

		JFrame frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(1080, 720);
		frame.setLayout(new GridLayout(3,3,0,0)); // 3 rows of 3, horizontal spacing / vertical spacing between components.  // gridlayout is useful for calculator
		
		
		for(int i = 1; i<=9 ; i++) {
			String sNum =String.valueOf(i);
			frame.add(new JButton("Button " + sNum));
		}
		
		
		frame.setVisible(true);
		

	}
}