import javax.swing.*;
import java.awt.*;
import java.util.Random; // Importing Random class

public class Main {
	
  public static void main(String[] args) {
	  
	  // JLayeredPane = Swing container that provides a third dimension for placing components. such as depth, or z axis.
	  
	  JLayeredPane layeredPane = new JLayeredPane();
	  layeredPane.setBounds(0,0,1280,720); // Adjusted the size to 1280x720
	  
	  // Set background color for the layered pane
	  layeredPane.setOpaque(true); // Set opaque to true to make the background color visible
	  layeredPane.setBackground(Color.DARK_GRAY);
	  
	  int panelCount = 7;
	  int panelSize = 150; // Adjusted panel size to fit neatly on 1280x720 window
	  int initialX = 50;
	  int initialY = 50;
	  
	  // Adding the first set of panels
	  for (int i = 0; i < panelCount; i++) {
		  JPanel panel = new JPanel();
		  panel.setBackground(getRandomColor());
		  panel.setBounds(initialX + i * panelSize/2, initialY + i * panelSize/2, panelSize, panelSize);
		  layeredPane.add(panel, Integer.valueOf(i));
	  }
	  
	  // Adding the second set of panels positioned 300 pixels to the right
	  for (int i = 0; i < panelCount; i++) {
		  JPanel panel = new JPanel();
		  panel.setBackground(getRandomColor());
		  panel.setBounds(initialX + 580 + i * panelSize/2, initialY + i * panelSize/2, panelSize, panelSize); // Adjusted x-coordinate
		  layeredPane.add(panel, Integer.valueOf(i + panelCount)); // Using offset for z-order
	  }
	   
      JFrame frame = new JFrame("JLayeredPane with 14 Panels");
      frame.add(layeredPane);
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.setSize(new Dimension(1280, 720)); // Adjusted window size
      frame.setLayout(null);
      frame.setVisible(true);
  }
  
  // Method to generate random colors
  private static Color getRandomColor() {
      Random rand = new Random();
      return new Color(rand.nextInt(256), rand.nextInt(256), rand.nextInt(256));
  }
}
