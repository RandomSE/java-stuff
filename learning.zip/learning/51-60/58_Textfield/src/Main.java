import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Main {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Textfield with a cat ");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 150);
        frame.setLayout(new FlowLayout());
        ImageIcon path = new ImageIcon("HamCat.jpg");
        Image cat = path.getImage();
        frame.setIconImage(cat);

        // Create a label
        JLabel nameLabel = new JLabel("Name:");

        // Create a text field
        JTextField nameField = new JTextField(20);

        // Create a button
        JButton submitButton = new JButton("Submit");

        // Add components to the frame
        frame.add(nameLabel);
        frame.add(nameField);
        frame.add(submitButton);

        // Action listener for the button // could also just use a lamda though
        submitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String name = nameField.getText();
                if (name.isEmpty()) {
                    JOptionPane.showMessageDialog(frame, "Please enter your name.", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(frame, "Hello, " + name + "!", "Welcome", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });

        // Display the frame
        frame.setVisible(true);
    }
}
