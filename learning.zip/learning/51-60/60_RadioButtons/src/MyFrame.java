import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class MyFrame extends JFrame {
    MyFrame() {
        setTitle("Main Course");
        setSize(1080, 720);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Create a panel to hold the radio buttons
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(5, 1)); // 5 rows, 1 column

        // Array of food options
        String[] foodOptions = {"Lasagne", "Mac n Cheese", "Pizza", "Salad", "Sushi"};
        JRadioButton[] buttons = new JRadioButton[foodOptions.length];

        // Create radio buttons for each food option using a loop
        for (int i = 0; i < foodOptions.length; i++) {
            buttons[i] = new JRadioButton(foodOptions[i]);
            panel.add(buttons[i]);
        }

        // Add radio buttons to a button group
        ButtonGroup foodGroup = new ButtonGroup();
        for (JRadioButton button : buttons) {
            foodGroup.add(button);
        }

        // Create a button to submit selection
        JButton submitButton = new JButton("Submit");

        // Action listener for the submit button
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	  for (JRadioButton button : buttons) {
                      if (button.isSelected()) {
                          if (button.getText().equals("Lasagne")) {
                        	  JOptionPane.showMessageDialog(null, "You selected " + button.getText() + "!");
                              JOptionPane.showMessageDialog(null, "Correct choice");
                          } else {
                              JOptionPane.showMessageDialog(null, "You selected " + button.getText() + "!");
                          }
                          return;
                      }
                  }
                  JOptionPane.showMessageDialog(null, "Please select an option!"); // if they don't choose an option.
              }
          });

        // Add the panel and button to the frame
        add(panel, BorderLayout.CENTER);
        add(submitButton, BorderLayout.SOUTH);

        setVisible(true);
    }
}
