import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Main extends JFrame {

    public Main() {
        // Set up the main frame
        setTitle("Main Window");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Create a button
        JButton button = new JButton("Open New Window");

        // Add action listener to the button
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openNewWindow();
            }
        });

        // Add the button to the main frame
        getContentPane().setLayout(new FlowLayout());
        getContentPane().add(button);

        // Set the frame visible
        setVisible(true);
    }

    private void openNewWindow() {
        // Create a new window
        JFrame newWindow = new JFrame();
        newWindow.setTitle("New Window");
        newWindow.setSize(200, 150);

        // Create a button for opening the third window
        JButton openThirdButton = new JButton("Open Third Window");

        // Add action listener to the button
        openThirdButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openThirdWindow();
            }
        });

        // Add the button to the new window
        newWindow.getContentPane().setLayout(new FlowLayout());
        newWindow.getContentPane().add(openThirdButton);

        // Set the new window visible
        newWindow.setVisible(true);
    }

    private void openThirdWindow() {
        // Create a third window
        JFrame thirdWindow = new JFrame();
        thirdWindow.setTitle("Third Window");
        thirdWindow.setSize(200, 150);

        // Create a label to display in the third window
        JLabel label = new JLabel("aHHH");

        // Add the label to the third window
        thirdWindow.getContentPane().setLayout(new FlowLayout());
        thirdWindow.getContentPane().add(label);

        // Set the third window visible
        thirdWindow.setVisible(true);
    }

    public static void main(String[] args) {
        // Create an instance of the GUIExample class
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new Main();
            }
        });
    }
}
