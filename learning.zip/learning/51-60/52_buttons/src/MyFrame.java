import java.awt.*;

import javax.swing.*;




public class MyFrame extends JFrame{
	

	
	JButton button;
	JLabel label;
	private int num = 0; 
	private int changedHeight;
	private int changedWidth;

	
	MyFrame(){
		
		
		Toolkit toolkit = Toolkit.getDefaultToolkit();
		int screenWidth = toolkit.getScreenSize().width;
	    int screenHeight = toolkit.getScreenSize().height;
	    
	    changedHeight = screenHeight;
	    changedWidth = screenWidth;
	    
	        
        
        System.out.println("Your pc's width: " +screenWidth + "  Your pc's height: " + screenHeight);
		
		
		ImageIcon icon = new ImageIcon("ButterCat.jpg");
		ImageIcon icon2 = new ImageIcon("frustration.jpg");
		
		label = new JLabel();
		
		
		button = new JButton();
		button.setBounds(0, 0, 500, 500);
		button.addActionListener( e -> { // lamda function: the ) must be after the }. // can be used instead of the listen action thing
            num ++;
			
			System.out.println("attempt " + num);
			// button.setEnabled(false); // hey if people want to pet the cat button they are allowed to. until they are not.
			
			changedHeight = (int) (changedHeight * 0.9);
			changedWidth = (int) (changedWidth * 0.9);
			this.setSize(changedWidth, changedHeight); // yes
			
			if (changedWidth <= 0.5* screenWidth) {
				button.setEnabled(false); // no more cat clicking.
				button.setVisible(false) ;
				this.add(label);
				label.setIcon(icon2);
				label.setBounds(0, 0, changedWidth, changedHeight);
				label.setVisible(true);
				//this.setBackground(Color.BLACK);
				//this.setOpacity(1.0f); 
				System.out.println("And where did the cat lead you? right back to where you began.");
				
			}
	        
			
			
			
		});
		button.setText("Pat the cat"); // cat
		button.setFocusable(true);
		button.setIcon(icon); // cat :D
		button.setHorizontalTextPosition(JButton.CENTER);
		button.setVerticalTextPosition(JButton.BOTTOM);
		button.setFont(new Font("Comic Sans",Font.BOLD,25));
		button.setIconTextGap(-50); // so the text is actually shown
		button.setForeground(Color.cyan);
		button.setBackground(Color.lightGray);
		button.setBorder(BorderFactory.createEtchedBorder());
		
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLayout(null);
		this.setSize(screenWidth, screenHeight); // so it fits to the size of the screen
		this.setVisible(true);
		this.add(button);
		this.setResizable(false); // does not really change much
		
		
		
		
		
	}
	
	
	
}