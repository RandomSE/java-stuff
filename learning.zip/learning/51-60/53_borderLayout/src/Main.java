import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import javax.swing.JPanel;
import javax.swing.JFrame;

public class Main {

    public static void main(String[] args) {
    	
    	// Layout Manager = Defines the natural layout for components within a container
		
    			// 3 common managers
    			
    			// BorderLayout = 	A BorderLayout places components in five areas: NORTH,SOUTH,WEST,EAST,CENTER. 
    			//					All extra space is placed in the center area.

        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1080, 720);
        frame.setLayout(new BorderLayout(10, 10));
        frame.setVisible(true);

        JPanel[] panels = new JPanel[11]; // Array to hold all panels

        // Create and configure main panels
        Color[] mainColors = {Color.RED, Color.GREEN, Color.YELLOW, Color.MAGENTA, Color.BLUE};
        Dimension[] mainDimensions = {new Dimension(100, 100), new Dimension(150, 100),
                                      new Dimension(150, 100), new Dimension(100, 100),
                                      new Dimension(100, 100)};
        char[] directions = {'N', 'W', 'E', 'S', 'C'};

        for (int i = 0; i < 5; i++) {
            panels[i] = new JPanel();
            panels[i].setBackground(mainColors[i]);
            panels[i].setPreferredSize(mainDimensions[i]);
            frame.add(panels[i], getBorderLayoutDirection(directions[i]));
        }

        // Create and configure sub panels
        Color[] subPanelColors = {Color.BLACK, Color.DARK_GRAY, Color.GRAY, Color.LIGHT_GRAY, Color.WHITE};
        Dimension subPanelDimension = new Dimension(50, 50);

        for (int i = 5; i < 10; i++) {
            panels[i] = new JPanel();
            panels[i].setBackground(subPanelColors[i - 5]);
            panels[i].setPreferredSize(subPanelDimension);
            panels[4].add(panels[i], getBorderLayoutDirection(directions[i - 5]));
        }
    }

    // Helper method to get BorderLayout direction string from char
    private static String getBorderLayoutDirection(char direction) {
        switch (direction) {
            case 'N':
                return BorderLayout.NORTH;
            case 'S':
                return BorderLayout.SOUTH;
            case 'W':
                return BorderLayout.WEST;
            case 'E':
                return BorderLayout.EAST;
            case 'C':
                return BorderLayout.CENTER;
            default:
                return BorderLayout.CENTER;
        }
    }
}