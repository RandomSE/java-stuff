import javax.swing.SwingUtilities;

public class Main {
	// CheckBox: gui component, can be selected and deselected.
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() { // Swing is single threaded, this makes sure it runs correctly.
            public void run() {
                new MyFrame();
            }
        });
    }
}