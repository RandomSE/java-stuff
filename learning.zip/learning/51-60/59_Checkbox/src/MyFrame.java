import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

class MyFrame extends JFrame {
    private JPanel panel;
    private JCheckBox javaCheckBox;
    private JCheckBox pythonCheckBox;
    private JCheckBox cSharpCheckBox;
    private JButton showSelectedButton;

    public MyFrame() {
        setTitle("Programming Languages");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        panel = new JPanel();
        panel.setLayout(new FlowLayout());

        // could also use image icons instead of text. 
        // would then use SetIcon (for unselected) and SetSelectedIcon
        javaCheckBox = new JCheckBox("Java");
        pythonCheckBox = new JCheckBox("Python");
        cSharpCheckBox = new JCheckBox("C#");

        showSelectedButton = new JButton("Show Selected Languages");
        showSelectedButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String selectedLanguages = "Selected Languages:\n";
                if (javaCheckBox.isSelected()) {
                    selectedLanguages += "Java\n"; // you can add to strings by using += change 
                }
                if (pythonCheckBox.isSelected()) {
                    selectedLanguages += "Python\n";
                }
                if (cSharpCheckBox.isSelected()) {
                    selectedLanguages += "C#\n";
                }
                JOptionPane.showMessageDialog(MyFrame.this, selectedLanguages);
            }
        });

        panel.add(javaCheckBox);
        panel.add(pythonCheckBox);
        panel.add(cSharpCheckBox);
        panel.add(showSelectedButton);

        add(panel); // don't need to use this. as only planning on using 1 instance.
        pack();
        setVisible(true);
    }
}