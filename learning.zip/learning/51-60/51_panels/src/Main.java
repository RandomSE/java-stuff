import java.awt.Color;
import java.awt.GridLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Main {

    public static void main(String[] args) {
        // panels
        JFrame frame = new JFrame("Panel Example");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1080, 720); 

        // Create a GridLayout with 3 rows and 3 columns
        GridLayout gridLayout = new GridLayout(3, 3);
        frame.setLayout(gridLayout);

        // Array to store panels
        JPanel[] panels = new JPanel[9]; // colour also do a 2d array, but unneeded here.

        // Create panels, set backgrounds, add labels, and add them to the frame
        for (int i = 0; i < panels.length; i++) {
            panels[i] = new JPanel();
            panels[i].setBackground(getPanelColor(i));
            JLabel label = new JLabel("panel " + Integer.toString(i + 1) );
            panels[i].add(label);
            frame.getContentPane().add(panels[i]);
        }

        frame.setVisible(true);
    }

    // Method to get background color for each panel
    private static Color getPanelColor(int panelNumber) {
        switch (panelNumber % 3) { // MOD operator; 
            case 0:
                return Color.RED; // 1, 4, 7
            case 1:
                return Color.BLUE; // 2, 5, 8
            case 2:
                return Color.GREEN; // 3, 6, 9
            default:
                return Color.WHITE;
        }
    }
}
