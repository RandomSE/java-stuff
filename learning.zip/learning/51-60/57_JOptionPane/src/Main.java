import javax.swing.JOptionPane;

public class Main {
    public static void main(String[] args) {
    	
    	// JOption panes: standard dialog box. informs/ accepts input. the null centers the boxes.
        // Display a message dialog
        JOptionPane.showMessageDialog(null, "Welcome to a world", "Message", JOptionPane.INFORMATION_MESSAGE);
        
        // Input dialog to get user's name
        String name = JOptionPane.showInputDialog(null, "Please enter your name:", "Name", JOptionPane.QUESTION_MESSAGE);
        
        // Check if user clicked cancel or closed the dialog
        if (name == null) {
            JOptionPane.showMessageDialog(null, "No name entered. Exiting program.", "Error", JOptionPane.ERROR_MESSAGE);
            System.exit(0); // useful
        }
        
        while(name.trim().isEmpty()) {
        	JOptionPane.showMessageDialog(null, "You did not input anything.", "ERROR", JOptionPane.ERROR_MESSAGE);
        	name = JOptionPane.showInputDialog(null, "Please enter your name:", "Name", JOptionPane.QUESTION_MESSAGE);
        }
        
        // Confirmation dialog -> the choice is yes/no because binary.
        int choice = JOptionPane.showConfirmDialog(null, "Hello, " + name + "! Would you like to continue?", "Confirmation", JOptionPane.YES_NO_OPTION);
        
        // Check user's choice
        if (choice == JOptionPane.YES_OPTION) {
            JOptionPane.showMessageDialog(null, "Great! Let's continue.", "Message", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Okay, goodbye " + name + "!", "Message", JOptionPane.INFORMATION_MESSAGE);
            System.exit(0);
        }
        JOptionPane.showMessageDialog(null, "and so it is done."); // 
    }
}