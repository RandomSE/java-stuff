import javax.swing.ImageIcon;
import javax.swing.JFrame;
import java.awt.Color;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
public class Main {
	
	protected static int annoy = 0; // gotta declare it before the static void main
	
	protected static void no() {
		// gotta declare it outside the static void.
		annoy ++;
		System.out.println(annoy + " not yet.");
		
		if(annoy >2) {
			System.out.println("Once more.");
		}
		
	}

	public static void main(String[] args) {
		// JFrame: GUI window that can have components added to. pretty similar to python TKinter stuff
		
		
		JFrame frame = new JFrame(); // instance
		frame.setTitle("The beginning");
		frame.setSize(1080,720);
		frame.setVisible(true);
		ImageIcon  cat = new ImageIcon("ButterCat.jpg");
		frame.setIconImage(cat.getImage());
		
		frame.getContentPane().setBackground(new Color(0x006400)); // green background
		
		
		 frame.addWindowListener(new WindowAdapter() {
	            @Override
	            public void windowClosing(WindowEvent e) {
	                if (annoy > 2) {
	                    // Close the window if annoy is greater than 2
	                    frame.dispose();
	                } else {
	                    // Increment annoy if it's not greater than 2
	                	frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
	                    no();
	                }
	            }
	        });
		
		
		
		
		
		
		
		
		

	}

	

}
