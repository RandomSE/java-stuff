import java.io.File;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.FileNotFoundException;
import java.io.IOException;

public class Main {

    public static void main(String[] args) {
        // files: abstract representation of directory and path
        File file = new File("testing1.txt"); // should be copied directly to the file, not the src or package.

        if (file.exists()) {
            System.out.println("Found.");
            System.out.println(file.getAbsolutePath());
            System.out.println(file.getPath());
            // file.delete(); // can delete files as well.
        } else {
            System.out.println("File not found.");
        }

        
        
        
        
        
        
        // File writer (writing to a file)
        String fileName = "newPoem.txt"; // outside the try block so it can be used with the fileReader
        File fPoem = new File(fileName);
        if (!fPoem.exists()) {
        try {
            FileWriter fileWriter = new FileWriter(fileName);
            System.out.println("File created. name: " + fileName);
            String sPoem = "In the heart of Java, where code meets the light,\n" +
                    "A language dances, elegant and bright.\n" +
                    "Strings of characters, woven with care,\n" +
                    "Crafting solutions, beyond compare.\n\n" +
                    "In loops and functions, logic takes flight,\n" +
                    "As if in a dream, through the bytes of the night.\n" +
                    "Objects and classes, like stars in the sky,\n" +
                    "Illuminate paths, where programmers fly.\n\n" +
                    "So let us embrace, this digital art,\n" +
                    "Where creativity thrives, and innovation starts.\n" +
                    "For in the realm of Java, we find our place,\n" +
                    "In a world of endless possibility and grace." ; // this is why you don't get ChatGPT to create poems for you
            fileWriter.write(sPoem);
            fileWriter.append("\n (a poem by ChatGPT)");
            
            
            fileWriter.close();
        } catch (IOException oof) {
            oof.printStackTrace();
        }
        }
        else {
        	fPoem.delete(); 
        	System.out.println("File already exists. After this, refresh the main file.");
        }
        
        
        // FileReader: reads the contents of a file as a stream of characters. read() returns an int value. Once it reaches -1, there are no more chars to be read.
        
        try {
            FileReader fileReader = new FileReader("testing1.txt");
            
            int data = fileReader.read();
            while (data != -1) {
                if ((char)data == '\\' && (char)fileReader.read() == 'n') {
                    System.out.println(); // Print newline if '\' followed by 'n'. 
                } else {
                    System.out.print((char)data); // Print character
                }
                data = fileReader.read();
            }
            
            fileReader.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}