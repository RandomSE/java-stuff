
public class Main {

	public static void main(String[] args) {
		// do not need to use overrides
		Dog chihuahua = new Dog();
		chihuahua.hunt();
		chihuahua.die();

	}

}
