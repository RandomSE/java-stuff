
public class Smog implements Predatog{ // some mythical thing, not many predators end in og
	
	
	public void hunt() {
		System.out.println("The smog succesfully hunts.");
		eat();
	}
	
	public void eat() {
		System.out.println("The smog consumes all.");
		
	}

}
