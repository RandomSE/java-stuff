
public interface Predatog {

	void hunt();
	void eat();
}
