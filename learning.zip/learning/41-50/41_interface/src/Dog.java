
public class Dog implements Predatog,Preyog{
	
	public void hunt() {
		System.out.println("The dog succesfully hunts.");
		eat();
	}
	
	public void eat() {
		System.out.println("The dog consumes.");
		
	}
	
boolean dead = false;
	
	public void run() {
		System.out.println("The dogog runs away succesfully");
	}
	
	public void die() {
		dead = true;
		System.out.println("The dog is unable to run away :c .");
	}

}
