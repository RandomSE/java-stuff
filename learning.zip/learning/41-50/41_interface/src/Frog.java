
public class Frog implements Preyog {
	
boolean dead = false;
	
	public void run() {
		System.out.println("The frog runs away succesfully");
	}
	
	public void die() {
		dead = true;
		System.out.println("The frog is unable to run away.");
	}

}
