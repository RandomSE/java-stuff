
public interface Preyog {
	void run();
	void die();
		
	

}
