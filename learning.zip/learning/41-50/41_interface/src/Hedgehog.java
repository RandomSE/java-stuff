
public class Hedgehog implements Preyog {
	boolean dead = false;
	
	public void run() {
		System.out.println("The hedgehog runs away succesfully");
	}
	
	public void die() {
		dead = true;
		System.out.println("The hedgehog is unable to run away.");
	}

}
