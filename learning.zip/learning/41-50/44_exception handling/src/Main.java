import java.util.Scanner;
import java.util.InputMismatchException;
public class Main {

	public static void main(String[] args) {
		// Exceptions: basically errors. Stops projects from working, but this can be circumvented with try... catch finally blocks.
		
		Scanner scanner = new Scanner(System.in);
		
		
		try {
			System.out.println("Put a whole number to divide.");
			int num = scanner.nextInt();
			scanner.nextLine();
			
			System.out.println("Put a second whole number for the first to be divided by.");
			int divisor = scanner.nextInt();
			scanner.nextLine();
			
			
			
			 double res;
	            if (num == 0 && divisor == 0) {
	                System.out.println("Both numerator and divisor are zero. Result is undefined.");
	            } else {
	                res = (double) num / divisor; 
	                String sRes = String.valueOf(res);
	                
	                if (Double.isInfinite(res)) {
	                    System.out.println("Result: Infinity"); // ah Java...
	                    System.out.println("Should not be possible but that's Java for you");
	                } else if (Double.isNaN(res)) {
	                    System.out.println("Result: Not a Number (NaN)");
	                } else {
	                    System.out.println("Result: " + sRes);
	                }
	            }
			
			
			
			
			
		} catch(InputMismatchException l1) {
			System.out.println("That is not an integer. ");
			
		}
		// do not need ArithmeticException as it does not stop program.t
		catch(Exception e) {
			System.out.println("Another error. " + e.getMessage());
			e.printStackTrace();
			
		}
		finally {
			scanner.close();
		}
		
		

	}

}
