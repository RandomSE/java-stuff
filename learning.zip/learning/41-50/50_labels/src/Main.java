import java.awt.Color;
import java.awt.Font;
import java.awt.BorderLayout;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.border.Border;


public class Main {

	public static void main(String[] args) {
		// J label:  GUI display area for text and/or an image.
		
		Border border = BorderFactory.createLineBorder(Color.BLUE,3); // to use colour seems to not work with other border types.
		ImageIcon image = new ImageIcon("HamCat.jpg");
		
		JLabel label = new JLabel(); //create a label
		label.setIcon(image);
		label.setText("The ham cat is glorious."); 
		label.setHorizontalTextPosition(JLabel.LEFT);
		label.setVerticalTextPosition(JLabel.BOTTOM);
		label.setBackground(new Color(0x006400));
		label.setForeground(Color.GREEN);
		label.setFont(new Font("Comic Sans",Font.BOLD,25));
		label.setIconTextGap(12); // negative makes overlap
		label.setOpaque(true);
		label.setBorder(border);
		// can also change horizontal and vertical alignment
		//label.setBounds(0,0, 1000, 1000); // does not change anything here unless using .setLayout(null);
		
		
		JFrame frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(1080,720);
		frame.setLayout(new BorderLayout()); 
		//frame.setLayout(null);
		
		frame.setVisible(true);	 
		frame.add(label, BorderLayout.CENTER);
		//frame.pack(); // ignores the setSize parameters; makes the frame as big as is needed to fit all components inside.

	}

}
