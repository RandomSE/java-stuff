
import java.io.File;
import java.io.IOException;
import java.util.Scanner;
import javax.sound.sampled.*;

public class Main {

	public static void main(String[] args) throws UnsupportedAudioFileException, IOException, LineUnavailableException{
		
		Scanner scanner = new Scanner(System.in);
		
		File file = new File("No Indication - TrackTribe.wav");
		//if (file.exists()){
			//System.out.println("Yes");
		//}
		AudioInputStream audioStream = AudioSystem.getAudioInputStream(file);
		Clip clip = AudioSystem.getClip();
		clip.open(audioStream);
		String response = "";
		
		while(!response.equals("Q")) {
			System.out.println("P = play, S = Stop, R = Reset, Q = Quit");
			System.out.print("Enter your choice: ");
			
			response = scanner.next();
			response = response.toUpperCase();
			
			switch(response) {
				case ("P"): clip.start();
				break;
				case ("S"): clip.stop();
				break;
				case ("R"): clip.setMicrosecondPosition(0);
				break;
				case ("Q"): clip.close();
				break;
				default: System.out.println("You did not pick any of the four options.");
			}
		 }
		System.out.println("Moving to the next, and final song.");	
		
		File file2 = new File("Woodshedder - Quincas Moreira.wav");
		AudioInputStream audioStream2 = AudioSystem.getAudioInputStream(file2);
		Clip clip2 = AudioSystem.getClip();
		clip2.open(audioStream2);
		String ask = "";
		

		while(!ask.equals("Q")) {
			System.out.println("P = play, S = Stop, R = Reset, Q = Quit");
			System.out.print("Enter your choice: ");
			
			ask = scanner.next();
			ask = ask.toUpperCase();
			
			switch(ask) {
				case ("P"): clip2.start();
				break;
				case ("S"): clip2.stop();
				break;
				case ("R"): clip2.setMicrosecondPosition(0);
				break;
				case ("Q"): clip2.close();
				break;
				default: System.out.println("You did not pick any of the four options.");
			}
		}
		
		
		
		System.out.println("The music is gone");
		scanner.close();
	}
}
		
		
		
	