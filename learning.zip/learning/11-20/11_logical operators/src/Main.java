import java.util.Scanner;
public class Main {

	public static void main(String[] args) {
		
		// logical operators: used to connect 2+ expressions. 
		// && (and) : both = true
		// || (or) : if either = true
		// ! (not) : if condition is not true
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("Input area temperature in celsius.");
		double temp = scanner.nextDouble();
		
		if(temp >=0 && temp <=18) {
			System.out.println("The weather is great today!");
			
		}
		else if(temp > 18) {
			if (temp > 30) {
			System.out.println("Drink lots of water, and avoid the s u n.");
				
			}
			else {
			System.out.println("It is uncomfortably warm today.");	
			}
			
		}
		else if(temp <0) {
			// its south africa, so this is unnecessary but eh
			if (temp <= -273.15) {
				System.out.println("How have you reached \"Absolute zero\"?");
			}
			else {
			System.out.println("It is a bit nippy out, may want to put on a jacket.");
			}
		}
		
		
		scanner.nextLine();
		System.out.println("input anything I guess");
		String odd = scanner.nextLine();
		if (!odd.trim().isEmpty()) { // odd != null does not work for this case.
			
			if (odd.equals("anything I guess")) {
				System.out.println("Hmm.");
				
			}
			
		else {
			System.out.println(odd);
		}
			
		}
		else {
			System.out.println("You did not input anything");
		}
		
		
		scanner.close();
		// could do || but unneeded
		
		

	}

}
