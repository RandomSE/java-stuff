import java.util.Scanner;
import java.util.Random;
public class Main {

	
	private static Scanner scanner = new Scanner(System.in);
	public static void main(String[] args) {
		// decided to instead
		
		// LOOPS: while loop -> While a given condition is true. 
		// nested loops -> commonly used in tandom with for loops, for filling 2d arrays and such
		// for loop -> iterates a given amount of times. useful for making tables and such


		
		
		/*
		String name = "";
					
		while (name.isBlank()) {
			System.out.println("What is your name? :");

			name = scanner.nextLine();
		}
		System.out.println("Hello : " + name);
		
		
		*/
		
		
		// semi random 2d array  
		Random random = new Random();
		int height = random.nextInt(6) + 5;
		int width = random.nextInt(6) + 5;
		System.out.println("height: " +height);
		System.out.println("Width: " + width);
		int [][] semiRandom = new int[height][width];
		
		// nested, for loop:
		
		for (int i = 0 ; i <height; i++) { 
			for (int o = 0; o < width; o++) {
				semiRandom[i][o] = random.nextInt(100) + 1; 
				
			
			}
			
		}
	
		
         System.out.println("\nSemi random 2d array");
		
		
		for (int i = 0 ; i <height; i++) { 
			for (int o = 0; o < width; o++) {
				System.out.print(semiRandom[i][o] + "\t") ; // helps keep the numbers seperated 
				
				
			}
			System.out.println();
		}
		
		
		
		// basic search 
		boolean check = false;
		
		System.out.println("\nWhat number would you like to search for in the arrays? (between 1 and 100)");
		int search = scanner.nextInt();
		String sMessage = search + " found at: \n";
		if (search > 0 && search <= 100) {
			
			for (int i = 0 ; i <height; i++) { 
				for (int o = 0; o < width; o++) {
					; 
					int current = semiRandom[i][o];
					if (current == search) {
						check = true;
						int i1 = i+1;
						int o1 = o+1; // computer sees differently to people -_-
						sMessage = sMessage +"height: " + i1 + " width: " +o1 +"\n";
						// find + replace is very useful, changed length to heigth for logic
					}
					
					
					
				}
			}
			
			
			
			
		}
		else {
			System.out.println("Invalid number.");
		}
		scanner.close();
		
		if (check){
			System.out.println(sMessage);
			
		}
		else {
			System.out.println(search + " Was not found in the arrays.");
		}
		
		// could also do basic replacing using methods.

	}

}
