
public class Main {

	public static void main(String args[]) {
		// strings: reference data type that can store characters. 
		
		  
		String ahh = "  uHHh     w   H  a  t";
		boolean result = ahh.equals(ahh.toLowerCase());
		// can also do var.length(), .charAt(index), .toLowerCase(), .toUpperCase(), .strip, .trim,  .indexOf("char"), .isEmpty() and many more.
		ahh = ahh.replaceAll("\\s", ""); // .strip and .trim only remove spaces at the edges.
		System.out.println(ahh + " " +  result);

	}
}
