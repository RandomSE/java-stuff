import java.util.ArrayList;
public class Main {

	public static void main(String[] args) {
		
		
		/*
		// ArrayList: resizable array. elements can be added and removed. Only store reference data types (like Strings)
		
		ArrayList<String> food = new ArrayList<String>();
		food.add("Lasagne");
		food.add("Pasta");
		food.add("Salad");
		
		food.set(2, "Hamburger");
		// can also do .remove(int), .clear();
		
		for (int i = 0 ; i <food.size(); i++) { // .size is basically .length for arrays
			System.out.println(food.get(i));
		}
		
		*/
		
		
		//2d ArrayList: list of lists
		
		ArrayList<ArrayList<String>> shoppingList = new ArrayList();
		
		ArrayList<String> bakeryList = new ArrayList();
		bakeryList.add("Donuts");
		bakeryList.add("Cakes");
		bakeryList.add("Macarons");
		
		ArrayList<String> produceList = new ArrayList();
		produceList.add("Mangoes");
		produceList.add("Tomatoes");
		produceList.add("Carrots");
		
		ArrayList<String> butcherList = new ArrayList();
		butcherList.add("Leg of lamb");
		butcherList.add("Ribeye steak");
		butcherList.add("Ground mince");
		
		
		
		shoppingList.add(bakeryList);
		shoppingList.add(produceList);
		shoppingList.add(butcherList) ;
		
		System.out.println("At the bakery: "+ shoppingList.get(0));
		System.out.println("At the produce isle: "+ shoppingList.get(1));
		System.out.println("At the butcher: "+ shoppingList.get(2)); // can also do .get().get() for an element in a specific list.
		
		
		

	}

}
