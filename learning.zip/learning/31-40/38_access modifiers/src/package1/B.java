package package1;
import package2.*;

public class B {
	
	private static String privateMessage = "It is unseen"; // only visible to the class it contains

}
