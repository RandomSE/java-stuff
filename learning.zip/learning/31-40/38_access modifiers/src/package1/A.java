package package1;
import package2.*;

public class A {
	protected static String protectedMessage = "it is protected.";

	public static void main(String[] args) {
		// System.out.println(C.defaultMessage);
		System.out.println(C.publicMessage);
		// System.out.println(B.privateMessage);

	}

}
