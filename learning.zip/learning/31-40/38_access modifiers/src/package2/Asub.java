package package2;
import package1.*;

public class Asub extends A{
	//public static void main(String[] args) {
	//System.out.println(A.protectedMessage); // Asub is a sub class of A.
	//}
	

}
