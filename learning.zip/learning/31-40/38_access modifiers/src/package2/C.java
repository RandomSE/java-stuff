package package2;
import package1.*;

public class C { // if you remove public, would only be visible to Asub as it is in the same package.

	
	static String defaultMessage = "Default.";
    public static String publicMessage = "all can access/"; // accessible to any class in the project folder
    protected static String protectedMessage = "it is protected."; // accessible to class in another project as long as it is a sub class which contains the protected member.
    
}  
