this is in 26-30 OOP
except for access modifiers