
public class Person {
  
	
	String name;
	
	static int owned_universes = 0;
	
	Person(String name){
		this.name = name;
		owned_universes ++;
	}
	
	static void show(){
		System.out.println("You own " + owned_universes + " universes");
		
	}
}
