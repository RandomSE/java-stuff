
public class Main {

	public static void main(String[] args) {
		// static method: single copy of a variable/method created and shared. class "owns" the static method/variable.

		
		Person person1 = new Person("Eva");
		Person person2 = new Person("Pete");
		Person person3 = new Person("Bob");
		Person.show(); 
	}

}
