
public class Main {

	public static void main(String[] args) {
		// array of objects
		
		
		
		//Stuff[] cupboard = new Stuff[3]; // 3 arrays
		
		Stuff basket = new Stuff("basket");
		Stuff chair = new Stuff("chair");
		Stuff violin = new Stuff("violin");
		
		Stuff []cupboard = {basket,chair,violin}; // cannot just type strings into there
		
		//cupboard[0] = basket;
		//cupboard[1] = chair;
		//cupboard[2] = violin;
		
		System.out.println(cupboard[0].name);
		System.out.println(cupboard[1].name);
		System.out.println(cupboard[2].name);


	}

}
