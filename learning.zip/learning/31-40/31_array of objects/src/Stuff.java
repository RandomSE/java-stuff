
public class Stuff {
   
	String name;
	
	
	Stuff(String name){
		this.name = name;
	}
}
