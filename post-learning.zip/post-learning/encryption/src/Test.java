import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.security.SecureRandom;

public class Test extends JFrame {

    private JTextArea messageTextArea;
    private JTextArea encryptedTextArea;
    private JTextArea encryptedKeyTextArea;
    private JTextArea decryptedTextArea;

    public Test() {
        super("OTP Encryption Program");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 600); // Set size for main window
        setLayout(new BorderLayout());

        // Create components for encryption panel
        messageTextArea = new JTextArea(10, 30);
        encryptedTextArea = new JTextArea(10, 30);
        encryptedTextArea.setEditable(false);

        JPanel encryptionPanel = new JPanel(new BorderLayout());
        encryptionPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        encryptionPanel.add(new JLabel("Enter Message:"), BorderLayout.NORTH);
        encryptionPanel.add(new JScrollPane(messageTextArea), BorderLayout.CENTER);

        JPanel encryptButtonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JButton encryptButton = new JButton("Encrypt");
        encryptButton.addActionListener(new EncryptButtonListener());
        encryptButtonPanel.add(encryptButton);
        encryptionPanel.add(encryptButtonPanel, BorderLayout.SOUTH);

        // Create components for decryption panel
        encryptedKeyTextArea = new JTextArea(10, 30);

        decryptedTextArea = new JTextArea(10, 30);
        decryptedTextArea.setEditable(false);

        JPanel decryptionPanel = new JPanel(new BorderLayout());
        decryptionPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        decryptionPanel.add(new JLabel("Enter Encrypted Text:"), BorderLayout.NORTH);
        decryptionPanel.add(new JScrollPane(encryptedKeyTextArea), BorderLayout.CENTER);

        JPanel decryptButtonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JButton decryptButton = new JButton("Decrypt");
        decryptButton.addActionListener(new DecryptButtonListener());
        decryptButtonPanel.add(decryptButton);
        decryptionPanel.add(decryptButtonPanel, BorderLayout.SOUTH);

        // Create main panel with split panes
        JSplitPane mainSplitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, encryptionPanel, decryptionPanel);
        mainSplitPane.setResizeWeight(0.5); // Initial split location (50%)
        add(mainSplitPane, BorderLayout.CENTER);

        // Create panel for displaying encryption and decryption results
        JPanel resultPanel = new JPanel(new GridLayout(1, 2, 10, 0));
        resultPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        encryptedTextArea.setBorder(BorderFactory.createTitledBorder("Encrypted Text"));
        decryptedTextArea.setBorder(BorderFactory.createTitledBorder("Decrypted Text"));

        resultPanel.add(new JScrollPane(encryptedTextArea));
        resultPanel.add(new JScrollPane(decryptedTextArea));

        add(resultPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    private class EncryptButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String message = messageTextArea.getText();

            if (!message.isEmpty()) {
                String otpKey = generateRandomKey(message.length());
                encryptedKeyTextArea.setText(otpKey);

                String encryptedText = encryptOTP(message, otpKey);
                encryptedTextArea.setText(encryptedText);
                decryptedTextArea.setText(""); // Clear decryption result
            } else {
                JOptionPane.showMessageDialog(Test.this,
                        "Please enter a message.",
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private class DecryptButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String encryptedText = encryptedTextArea.getText();
            String otpKey = encryptedKeyTextArea.getText();

            if (!encryptedText.isEmpty() && !otpKey.isEmpty()) {
                String decryptedMessage = decryptOTP(encryptedText, otpKey);
                decryptedTextArea.setText(decryptedMessage);
            } else {
                JOptionPane.showMessageDialog(Test.this,
                        "Please enter encrypted text and OTP key.",
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private String generateRandomKey(int length) {
        SecureRandom random = new SecureRandom();
        StringBuilder key = new StringBuilder();

        for (int i = 0; i < length; i++) {
            key.append((char) (random.nextInt(256))); // Generate a random character (0-255)
        }

        return key.toString();
    }

    private String encryptOTP(String message, String otpKey) {
        StringBuilder encryptedText = new StringBuilder();

        for (int i = 0; i < message.length(); i++) {
            char plainChar = message.charAt(i);
            char keyChar = otpKey.charAt(i);

            // Perform OTP encryption: C = M XOR K
            char encryptedChar = (char) (plainChar ^ keyChar);

            encryptedText.append(encryptedChar);
        }

        return encryptedText.toString();
    }

    private String decryptOTP(String encryptedText, String otpKey) {
        StringBuilder decryptedMessage = new StringBuilder();

        for (int i = 0; i < encryptedText.length(); i++) {
            char encryptedChar = encryptedText.charAt(i);
            char keyChar = otpKey.charAt(i);

            // Perform OTP decryption: M = C XOR K
            char decryptedChar = (char) (encryptedChar ^ keyChar);

            decryptedMessage.append(decryptedChar);
        }

        return decryptedMessage.toString();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(Test::new);
    }
}
