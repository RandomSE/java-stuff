import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class OTPEncryptionGUI extends JFrame {
	// not actually OTP encryption, a simple XOR encryption.

    private JTextArea messageTextArea;
    private JTextArea encryptedTextArea;
    private JTextArea decryptedTextArea;
    private JComboBox<String> otpKeyComboBox;

    public OTPEncryptionGUI() {
        super("OTP Encryption Program");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 600); // Set size for main window
        setLayout(new BorderLayout());

        // Create components for encryption panel
        messageTextArea = new JTextArea(10, 30);
        encryptedTextArea = new JTextArea(10, 30);
        encryptedTextArea.setEditable(false);

        String[] otpKeys = {"Key 1", "Key 2", "Key 3"};
        otpKeyComboBox = new JComboBox<>(otpKeys);

        JButton encryptButton = new JButton("Encrypt");
        encryptButton.addActionListener(new EncryptButtonListener());

        JPanel encryptionPanel = new JPanel(new BorderLayout());
        encryptionPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        encryptionPanel.add(new JLabel("Enter Message:"), BorderLayout.NORTH);
        encryptionPanel.add(new JScrollPane(messageTextArea), BorderLayout.CENTER);
        encryptionPanel.add(otpKeyComboBox, BorderLayout.SOUTH);
        encryptionPanel.add(encryptButton, BorderLayout.SOUTH);

        // Create components for decryption panel
        JTextArea encryptedInputTextArea = new JTextArea(10, 30);
        decryptedTextArea = new JTextArea(10, 30);
        decryptedTextArea.setEditable(false);

        JComboBox<String> decryptionKeyComboBox = new JComboBox<>(otpKeys);

        JButton decryptButton = new JButton("Decrypt");
        decryptButton.addActionListener(new DecryptButtonListener(encryptedInputTextArea, decryptionKeyComboBox));

        JPanel decryptionPanel = new JPanel(new BorderLayout());
        decryptionPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        decryptionPanel.add(new JLabel("Enter Encrypted Text:"), BorderLayout.NORTH);
        decryptionPanel.add(new JScrollPane(encryptedInputTextArea), BorderLayout.CENTER);
        decryptionPanel.add(decryptionKeyComboBox, BorderLayout.SOUTH);
        decryptionPanel.add(decryptButton, BorderLayout.SOUTH);

        // Add components to the main frame
        JPanel mainPanel = new JPanel(new GridLayout(1, 2, 10, 0));
        mainPanel.add(encryptionPanel);
        mainPanel.add(decryptionPanel);

        add(mainPanel, BorderLayout.CENTER);

        JPanel resultPanel = new JPanel(new GridLayout(1, 2, 10, 0));
        resultPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        encryptedTextArea.setBorder(BorderFactory.createTitledBorder("Encrypted Text"));
        decryptedTextArea.setBorder(BorderFactory.createTitledBorder("Decrypted Text"));

        resultPanel.add(new JScrollPane(encryptedTextArea));
        resultPanel.add(new JScrollPane(decryptedTextArea));

        add(resultPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    private class EncryptButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String message = messageTextArea.getText();
            String otpKey = (String) otpKeyComboBox.getSelectedItem();

            if (!message.isEmpty() && !otpKey.isEmpty()) {
                String encryptedText = encryptOTP(message, otpKey);
                encryptedTextArea.setText(encryptedText);
            } else {
                JOptionPane.showMessageDialog(OTPEncryptionGUI.this,
                        "Please enter a message and select an OTP key.",
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private class DecryptButtonListener implements ActionListener {
        private JTextArea encryptedInputTextArea;
        private JComboBox<String> decryptionKeyComboBox;

        public DecryptButtonListener(JTextArea encryptedInputTextArea, JComboBox<String> decryptionKeyComboBox) {
            this.encryptedInputTextArea = encryptedInputTextArea;
            this.decryptionKeyComboBox = decryptionKeyComboBox;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            String encryptedText = encryptedInputTextArea.getText();
            String otpKey = (String) decryptionKeyComboBox.getSelectedItem();

            if (!encryptedText.isEmpty() && !otpKey.isEmpty()) {
                String decryptedMessage = decryptOTP(encryptedText, otpKey);
                decryptedTextArea.setText(decryptedMessage);
            } else {
                JOptionPane.showMessageDialog(OTPEncryptionGUI.this,
                        "Please enter encrypted text and select an OTP key.",
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private String encryptOTP(String message, String otpKey) {
        StringBuilder encryptedText = new StringBuilder();

        for (int i = 0; i < message.length(); i++) {
            char plainChar = message.charAt(i);
            char keyChar = otpKey.charAt(i % otpKey.length());

            // Perform OTP encryption: C = M XOR K
            char encryptedChar = (char) (plainChar ^ keyChar);

            encryptedText.append(encryptedChar);
        }

        return encryptedText.toString();
    }

    private String decryptOTP(String encryptedText, String otpKey) {
        StringBuilder decryptedMessage = new StringBuilder();

        for (int i = 0; i < encryptedText.length(); i++) {
            char encryptedChar = encryptedText.charAt(i);
            char keyChar = otpKey.charAt(i % otpKey.length());

            // Perform OTP decryption: M = C XOR K
            char decryptedChar = (char) (encryptedChar ^ keyChar);

            decryptedMessage.append(decryptedChar);
        }

        return decryptedMessage.toString();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(OTPEncryptionGUI::new);
    }
}
