import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Main {

    private JLabel clockLabel;
    private JLabel dateLabel;
    private JLabel dayOfWeekLabel;
    private JLabel stopwatchLabel;
    private Timer stopwatchTimer;
    private long startTime;
    private boolean stopwatchRunning;

    public Main() {
        JFrame frame = new JFrame("Clock and Stopwatch");
        frame.setSize(720, 480);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new GridLayout(4, 1));

        // Create clock label
        clockLabel = new JLabel("", JLabel.CENTER);
        clockLabel.setFont(new Font("Arial", Font.BOLD, 24));
        frame.add(clockLabel);

        // Create date label
        dateLabel = new JLabel("", JLabel.CENTER);
        dateLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        frame.add(dateLabel);

        // Create day of week label
        dayOfWeekLabel = new JLabel("", JLabel.CENTER);
        dayOfWeekLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        frame.add(dayOfWeekLabel);

        // Create stopwatch label
        stopwatchLabel = new JLabel("00:00:00", JLabel.CENTER);
        stopwatchLabel.setFont(new Font("Arial", Font.BOLD, 24));
        frame.add(stopwatchLabel);

        // Create panel for stopwatch controls
        JPanel buttonPanel = new JPanel(new FlowLayout());
        JButton startButton = new JButton("Start Stopwatch");
        JButton stopButton = new JButton("Stop Stopwatch");

        buttonPanel.add(startButton);
        buttonPanel.add(stopButton);
        frame.add(buttonPanel);

        // ActionListener for start button
        startButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                startStopwatch();
            }
        });

        // ActionListener for stop button
        stopButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                stopStopwatch();
            }
        });

        // Set up and display the frame
        frame.setVisible(true);

        // Start the timer to update clock and date/time labels
        Timer updateTimer = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateClock();
            }
        });
        updateTimer.start();
    }

    private void updateClock() {
        // Update clock label with current time
        SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");
        SimpleDateFormat dateFormat = new SimpleDateFormat("MMM dd, yyyy");
        SimpleDateFormat dayOfWeekFormat = new SimpleDateFormat("EEEE");

        Date now = new Date();
        String timeStr = timeFormat.format(now);
        String dateStr = dateFormat.format(now);
        String dayOfWeekStr = dayOfWeekFormat.format(now);

        clockLabel.setText(timeStr);
        dateLabel.setText(dateStr);
        dayOfWeekLabel.setText(dayOfWeekStr);
    }

    private void startStopwatch() {
        if (!stopwatchRunning) {
            startTime = System.currentTimeMillis();
            stopwatchTimer = new Timer(100, new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    updateStopwatch();
                }
            });
            stopwatchTimer.start();
            stopwatchRunning = true;
        }
    }

    private void stopStopwatch() {
        if (stopwatchRunning) {
            stopwatchTimer.stop();
            stopwatchRunning = false;
        }
    }

    private void updateStopwatch() {
        long elapsedTimeMillis = System.currentTimeMillis() - startTime;
        int hours = (int) (elapsedTimeMillis / 3600000);
        int minutes = (int) ((elapsedTimeMillis / 60000) % 60);
        int seconds = (int) ((elapsedTimeMillis / 1000) % 60);
        String stopwatchStr = String.format("%02d:%02d:%02d", hours, minutes, seconds);
        stopwatchLabel.setText(stopwatchStr);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Main();
            }
        });
    }
}
