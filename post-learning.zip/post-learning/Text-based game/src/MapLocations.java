import java.util.HashMap;
import java.util.Map;

public class MapLocations {
    public String CurrentLocation;
    public  boolean blocked = true; // initially you cannot enter hermit's cave.
    public  boolean unlocked = false; // Shipyard and it's connected locations will be quest locations.
    private static final Map<String, Map<Character, String>> connections = new HashMap<>();
    
    public MapLocations(){
    	initialize_connections();
    }
    
    public void set_blocked() {
    	blocked = false;
    	initialize_connections();
    }
    
    public void set_unlocked() {
    	unlocked = true;
    	initialize_connections();
    }
    
    
    public void initialize_connections() {
        // connections for each location
        Map<Character, String> startConnections = new HashMap<>();
        startConnections.put('N', "Village of the Wheat");
        startConnections.put('E', "Village of the Mill");
        startConnections.put('S', "Village of the small boulders");
        startConnections.put('W', "Village of the hungry");
        connections.put("Start", startConnections);
        
        Map<Character, String> villageOfTheWheatConnections = new HashMap<>();
        villageOfTheWheatConnections.put('N', "Magic shop");
        villageOfTheWheatConnections.put('S', "Start"); 
        if (!blocked) {
        	villageOfTheWheatConnections.put('W', "Hermit's cave");       	
        }
        connections.put("Village of the Wheat", villageOfTheWheatConnections);
        
        Map<Character, String> hermitCaveConnections = new HashMap<>(); // connects to both the West and North village, so will place here.
        hermitCaveConnections.put('E', "Village of the Wheat");
        hermitCaveConnections.put('S', "Village of the hungry");
        connections.put("Hermit's cave", hermitCaveConnections);
        
        
        Map<Character, String> magicShopConnections = new HashMap<>();
        magicShopConnections.put('S', "Village of the Wheat");
        magicShopConnections.put('E', "Graveyard of the cursed");
        connections.put("Magic shop", magicShopConnections);
        
        Map<Character, String> graveyardOfTheCursedConnections = new HashMap<>();
        graveyardOfTheCursedConnections.put('W', "Magic shop");
        connections.put("Graveyard of the cursed", graveyardOfTheCursedConnections);
        
        // northern locations.
        
        
        Map<Character, String> villageOfTheMillConnections = new HashMap<>();  
        villageOfTheMillConnections.put('W', "Start");   
        villageOfTheMillConnections.put('E', "Burning abyss"); 
        connections.put("Village of the Mill", villageOfTheMillConnections);
        
        Map<Character, String> burningAbyssConnections = new HashMap<>();  
        burningAbyssConnections.put('W', "Village of the Mill");
        connections.put("Burning abyss", burningAbyssConnections);
        
        
        // eastern locations.
        
        
        Map<Character, String> villageOfTheSmallBoulders = new HashMap<>();
        villageOfTheSmallBoulders.put('N', "Start");
        if(unlocked) {
        villageOfTheSmallBoulders.put('S', "Shipyard");	
        }
        connections.put("Village of the small boulders", villageOfTheSmallBoulders);
        
        Map<Character, String> shipyardConnections = new HashMap<>();
        shipyardConnections.put('N', "Village of the small boulders");
        shipyardConnections.put('E', "Dark caverns");
        connections.put("Shipyard", shipyardConnections);

        Map<Character, String> darkCavernsConnections = new HashMap<>();
        darkCavernsConnections.put('N', "Banished mage");
        darkCavernsConnections.put('W', "Shipyard");
        darkCavernsConnections.put('S', "Radiant grove");
        connections.put("Dark caverns", darkCavernsConnections);

        Map<Character, String> banishedMageConnections = new HashMap<>();
        banishedMageConnections.put('S', "Dark caverns");
        connections.put("Banished mage", banishedMageConnections);

        Map<Character, String> radiantGroveConnections = new HashMap<>();
        radiantGroveConnections.put('N', "Dark caverns");
        connections.put("Radiant grove", radiantGroveConnections);

        
        // southern locations.
        
        
        Map<Character, String> villageOfTheHungry = new HashMap<>();
        if(!blocked) {
        	villageOfTheHungry.put('N', "Hermit's cave");        	
        }
        villageOfTheHungry.put('W', "Village of the rich");
        villageOfTheHungry.put('E', "Start");  
        connections.put("Village of the hungry", villageOfTheHungry);
        
        Map<Character, String> villageOfTheRich = new HashMap<>();
        villageOfTheRich.put('N', "Gold plant");
        villageOfTheRich.put('E', "Village of the hungry");
        villageOfTheRich.put('S', "Coin Mint");
        villageOfTheRich.put('W', "Crossroads");
        connections.put("Village of the rich", villageOfTheRich);
        
        Map<Character, String> goldPlant = new HashMap<>();
        goldPlant.put('S', "Village of the rich");
        connections.put("Gold plant", goldPlant);
        
        Map<Character, String> coinMint = new HashMap<>();
        coinMint.put('N', "Village of the rich");
        connections.put("Coin Mint", coinMint);
        
        
        Map<Character, String> crossroads = new HashMap<>();
        crossroads.put('N', "Dragon's lair");
        crossroads.put('E', "Village of the rich");
        crossroads.put('S', "Magical lake");
        crossroads.put('W', "Edge of reality");
        connections.put("Crossroads", crossroads);
        
        Map<Character, String> dragonLair = new HashMap<>();
        dragonLair.put('S', "Crossroads");
        connections.put("Dragon's lair", dragonLair);
       
        Map<Character, String> magicalLake = new HashMap<>();
        magicalLake.put('N', "Crossroads");
        connections.put("Magical lake", magicalLake);
        
        Map<Character, String> edgeOfReality = new HashMap<>();
        edgeOfReality.put('E', "Crossroads");
        connections.put("Edge of reality", edgeOfReality);
        
        // western locations.      
    }
    
    
    public String get_location() {
    	System.out.println(CurrentLocation);
		return CurrentLocation;    	
    }
    
    public void set_location(String location) {
    	CurrentLocation = location; // for items that take you to places with no connections.q
    }
    
    	
    	public void move(char direction) {
            Map<Character, String> currentConnections = connections.get(CurrentLocation);
            if (currentConnections != null && currentConnections.containsKey(direction)) {
                String newLocation = currentConnections.get(direction);
                System.out.println("You move to: " + newLocation);
                CurrentLocation = newLocation; // Update current location
            } else {
                System.out.println("You cannot move in that direction from " + CurrentLocation); 		
    	}
    	 // move in about 10 lines instead of about 400. neat.
    	
    	
 
    }
   

      
    }
