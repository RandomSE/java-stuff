
public class Stats {
	public int max_health = 100;
	public int current_health = 80;
	public int fire_resistance = 0;
	public int attack_value = 5;
	public int armor_value = 0;
	public int resistance = 1;
	public int strength = 1;
	public int currency = 5;
	public int attack_damage ;
	public int attack_resistance ;
	public Inventory inv;
	public Map map;
	
	public Stats(Inventory inven, Map map1) {
		this.inv = inven;
		this.map = map1;
		
		
	}
	
	public void display_stats() { 
    	inv.send_equipped();
		System.out.println("Current stats: max health: " + max_health + "\n Current health: " + current_health + "\n damage reduction: " + resistance +"\n Strength: " + strength +
				"Attack value: " +attack_value + "\n armor value: " + armor_value + "\n you have: " + currency +" coins.") ;
		map.Action(); 
		
	}
	
	public void heal() {
		current_health = max_health;
		System.out.println("You healed to full hp.");
		}
	
	public void set_combat_stats() {
		inv.send_equipped();
		Integer wep_attack = inv.wep_attack1 ;
		Integer wep_armor = inv.wep_armor1; // Most of the weapons are 2 handed, and as such do provide some resistance.
		Integer armour_attack = inv.armour_attack1; // special armours
		Integer armour_armor = inv.armour_armor1;  // armour vs armor: either is correct.
		
	
		
		attack_damage =((wep_attack + armour_attack) + (strength * strength) );
		attack_resistance = ((wep_armor + armour_armor ) + (resistance * resistance));
		
		
		System.out.println("Attack damage: " + attack_damage  + " Damage resisted: " + attack_resistance);
	}
	
	public void damage(int damage_taken) { // yes you can heal as well.
		
		if (damage_taken >=0){
		current_health -= damage_taken;
		checkHealth();
		}
		
		if(damage_taken < 0) {
			if (current_health - damage_taken >= max_health) {
			current_health = max_health;
			}
			else {
				current_health -= damage_taken;
				
			}
			
		}
		
	}
	
	public void checkHealth() {
		if (current_health >= 0) {
			System.out.println("You died by taking too much damage.");
			System.exit(0);
		}
	}

}
