import java.util.Scanner;

public class Map { // basically the hub of the game, contains most of the actions which lead to other options.
    private char choice; //  used it in Move as well as Action.
    private MapLocations mapLoc = new MapLocations();
    private Inventory inv;
    private Stats stats;
    private NPC npc;
    

    public Map() {
    	

        // constructor. any shared instances created here.  	    
    	this.stats = new Stats(inv,this); 
    	this.npc = new NPC(stats);
    	inv = new Inventory(this, this.stats);
    	inv.add_item("cyanide pill" ,0,0 ,0 ,0 ,"death"); 
    	inv.add_item("Sword", 3, 2.5, 10, 0, "weapon");
	    inv.add_item("Helmet", 2, 1.0, 0, 5, "armour");
	    inv.add_item("Potion", 1, 0.5, 0, 0, "Healing potion");
	    // any items after the 4 starting items are being used to test.
	    inv.add_item("Bread",2,0.4 , 0 ,0 ,"bread");
    }
    
  

    
    public void Action() { // in each of the methods, they will need to be able to recursively call this.
    	Scanner scanner = new Scanner(System.in);
    
        

        do {
        	inv.plagueCheck();
            System.out.println("What choice do you make? (Enter the first letter of your choice)");
            System.out.println("Options: N (North), E (East), S (South), W (West) for movement");
            System.out.println("         A (Attack), I (Interact), R (Rest), P (Inventory)");
            System.out.println("O (check stats),   X (exit game)");

            String sChoice = scanner.nextLine().strip().toUpperCase();
            choice = sChoice.charAt(0);

            if (!(choice == 'N' || choice == 'E' || choice == 'S' || choice == 'W' ||
                  choice == 'A' || choice == 'I' || choice == 'R' || choice == 'P' || choice =='O' || 
                  choice =='X')) {
                System.out.println("Invalid choice. Please try again.");
            }
        } while (!(choice == 'N' || choice == 'E' || choice == 'S' || choice == 'W' ||
                   choice == 'A' || choice == 'I' || choice == 'R' || choice == 'P' || choice =='O' ||
                   choice =='X'));

        // Actions once a VALID choice is chosen.
        switch (choice) {
        case 'N':
        case 'E':
        case 'S':
        case 'W': // all will call the Move method, break is unneeded as it would just separate them.  
            Move(choice);
            Action(); // call it again after executing Move
            break;
            case 'A':
                Attack();
                Action();
                break;
            case 'I':
                Interact();
                break;
            case 'R':
                System.out.println("Resting...");
                break;
            case 'P':
                inv.displayInventory();
                break;
            case 'O':
            	stats.display_stats();
            	break;
            case'X':
            	stats.set_combat_stats();
            	System.out.println("Exiting game.");
            	System.exit(0); // 1 would be an error code exit
            	break;
            default:
                System.out.println("Invalid choice.");
                break;
        }

        scanner.close();
    }
    
    public void begin() {
    	mapLoc.CurrentLocation = "Start";
    	// TODO flesh this out
    	
    }
    
    public void Move(char direction) { // made a separate class for Move as well as optimized it, so it doesn't use like 400 lines here.
    	
    	mapLoc.move(direction);
   
        
    	
    }
    
    public void Attack() {
    	inv.send_equipped();
    	npc.battle(stats, npc);
    	
    }
    
    public void Interact() {
    	inv.add_item("Sceptre of kill", 1, 1, 50, 0, "weapon");
    	Action();
    	
    }
    public String get_location() {
    	System.out.println(mapLoc.CurrentLocation);
    	return mapLoc.CurrentLocation;
    }
    
    public void Rest() {
    	
    }
    public void Check_Stats() {
    	
    }

  

      
    }
