
public class NPC {
	protected Stats stats;
	protected int npc_health;
	protected int npc_maxHealth;
	protected int npc_damage;
	protected int npc_resistance;
	protected int number_of_npc = 1;
	protected String drop;
	//Peasant peasant = new Peasant();
 // TODO on monday. this is main class, add all the subclasses.
	
	
	
	
	public NPC(Stats statInstance) {
		this.stats = statInstance;
		this.npc_health = 100;
        this.npc_maxHealth = 100;
        this.npc_damage = 0;
        this.npc_resistance = 0;
        this.number_of_npc = 1;
	
	
		
		
		
	}
	
	


	public void battle(Stats stats1, NPC npc) {
		// TODO: add a combat system for them cheeky bois 
		
		if(npc.number_of_npc > 0) {
		while(npc.npc_health > 0 && stats1.current_health > 0){
			if(stats1.attack_damage < npc_resistance || npc_damage < stats1.attack_resistance ) {
				System.out.println("Neither of you can damage eachother. You draw.");
				break;
				
			}
			stats1.current_health -= (npc.npc_damage -stats1.attack_resistance ) ;
			npc.npc_health -=(stats1.attack_damage -npc.npc_resistance);
			stats.checkHealth();
			if(npc.npc_health <=0) {
				npc.number_of_npc -=1;
				System.out.println("You won the battle! Health remaining: " + stats1.current_health);
				npc_health = npc_maxHealth;
			}
			
		}
		}

		
	}
	public void attack(NPC npc2) {
		npc2.battle(stats, npc2);
		
	}
}

 class Peasant extends NPC {
    public Peasant() {
    	super(null);
    	  this.npc_health = 50;
          this.npc_maxHealth = 50;
          this.npc_damage = 5;
          this.npc_resistance = 2;
          this.number_of_npc = 12;
    }
}


