import java.util.ArrayList;
import java.util.Scanner;

public class Inventory {
    private Map map;
    private MapLocations mapl;
    private Stats stats1;
    private int space_remaining = 25;
    private ArrayList<Item> items;
    private int mass_capacity = 25;
    private int carried_mass = 0;
    private Item weaponEquipped; // these are used in Stats
    private Item armourEquipped;
    public int plague = 0;
    private String currLocation; // many items effect specific locations.
    int wep_attack1;
	int wep_armor1;
	int armour_attack1;
	int armour_armor1;
    Scanner scanner = new Scanner(System.in); // here so I can stop the resource leaks, as it's not good.

    public Inventory(Map map, Stats stats) {
        this.map = map;
        this.mapl = new MapLocations();
        items = new ArrayList<>();
        this.stats1 = stats;
        // Instantiate Map for later use
    }

    private static class Item {
        private String name;
        private int spaceNeeded;
        private double massRequired;
        private int attackValue;
        private int armourValue;
        private String uses;
        

        public Item(String name, int spaceNeeded, double massRequired, int attackValue, int armourValue, String uses) {
            this.name = name;
            this.spaceNeeded = spaceNeeded;
            this.massRequired = massRequired;
            this.attackValue = attackValue;
            this.armourValue = armourValue;
            this.uses = uses;
        }

        @Override
        public String toString() {
            return "Item [" + name + ", takes up " + spaceNeeded + " slots, weighs " + massRequired
                    + " units, attackValue=" + attackValue + ", armourValue=" + armourValue + ", uses: " + uses + "]";
        }
    }

    public void add_item(String itemName, int spaceNeeded, double massRequired, int attackValue, int armourValue, String uses) {
        // Check if the item already exists in the inventory (case-insensitive)
        if (items.stream().anyMatch(item -> item.name.equalsIgnoreCase(itemName))) {
            System.out.println("Error: Item '" + itemName + "' already exists in the inventory.");
            return;
        }

        // Check if there's enough space and capacity to add the item
        if (spaceNeeded > space_remaining) {
            System.out.println("Error: Not enough space to add item '" + itemName + "'.");
            return;
        }

        if (carried_mass + massRequired > mass_capacity) {
            System.out.println("Error: Item '" + itemName + "' is too heavy to carry.");
            return;
        }

        // Create a new Item object
        Item newItem = new Item(itemName, spaceNeeded, massRequired, attackValue, armourValue, uses);

        // Add the new Item to the items list
        items.add(newItem);

        // Update inventory space and mass
        space_remaining -= spaceNeeded;
        carried_mass += massRequired;

        System.out.println("Item '" + itemName + "' added to inventory.");
    }

    public void displayInventory() {
        

        while (true) {
            // Display equipped items
            System.out.println("Equipped Items:");
            if (weaponEquipped != null) {
                System.out.println("- Weapon: " + weaponEquipped.name + " (Attack: " + weaponEquipped.attackValue + ")");
            }
            if (armourEquipped != null) {
                System.out.println("- Armour: " + armourEquipped.name + " (Armour: " + armourEquipped.armourValue + ")");
            }

            // Display inventory items
            System.out.println("Inventory:");
            for (int i = 0; i < items.size(); i++) {
                System.out.println((i + 1) + ". " + items.get(i));
            }

            System.out.println("Choose an option:");
            System.out.println("1. Equip/Unequip an item");
            System.out.println("2. Remove an equipped item");
            System.out.println("3. Drop an item");
            System.out.println("4. Use an item");
            System.out.println("5. Exit inventory");
            String input = scanner.next();
            char choice = input.charAt(0); // changed choice to a char (and changed the switch) because otherwise, input mismatch when played placed an input that wasn't an integer.
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case '1':
                    equipItem();
                    break;
                case '2':
                    removeEquipped();
                    break;
                case '3':
                	dropItem();
                	break;
                case '4':
                	useItem();
                    break; 
                case '5':
                    goBack(map); // Exit inventory
                    scanner.close(); // less leak
                    return; // Exit inventory loop
                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        }
    }

    private void useItem() {
    	boolean itemUsed = true;
    	currLocation = map.get_location();
    	System.out.println("Enter the number of the item you want to use (0 to cancel):");
        int index = scanner.nextInt();
        scanner.nextLine(); 

        if (index < 1 || index > items.size()) {
            System.out.println("Invalid item number.");
            return;
        }

        Item selectedItem = items.get(index - 1); // oh boy time to triple the lines of code here // TODO tomorrow
        if (selectedItem.name == "Palace Key") {
        	if (currLocation == "Edge of reality") {
        		mapl.set_location("Palace");
        		System.out.println("You teleport to the Palace.");
        		dropItem("Palace Key");
        		add_item("Return Key",0 ,0.1 ,0 ,0 ,"Exit Palace");
        		
        		
        	}
        	else {
        		System.out.println("You can only use Palace Key at Edge of reality.");
        	}
        	
        }
        
        else if (selectedItem.name == "Return Key") {      	
        		mapl.set_location("Edge of reality");
        		System.out.println("You teleport back to Edge of reality.");
        		dropItem("Return Key");
        	
        }
        else  if (selectedItem.name == "Plagued sword") {
        	plague ++;
        	String vCheck = currLocation.substring(0, Math.min(currLocation.length(), 7));
        	if (vCheck.equals("Village")) {
        		System.out.println("VILLAGE LOCATED");
        		// TODO add village killing mechanic here after adding the NPCS.
        		
        	
         }
        }
        else if (selectedItem.name == "Magic oven") { 
        	
        	String itemNameToSearch = "Flour";
            Item foundItem = searchItemByName(itemNameToSearch);

            if (foundItem != null) {
                System.out.println("You made bread!");
                dropItem(foundItem.name);
                add_item("Bread",2,0.4 , 0 ,0 ,"bread");
            } else {
                System.out.println("You don't have any flour, so you cannot make bread with the Magic oven.");
            }
        }
        
        else if (selectedItem.name == "Seed of hatred") { 
        	if (currLocation == "Palace") {
        		dropItem("Seed of hatred");
        		add_item("Possessed armour",4 ,2 ,200 ,-100 ,"armour");
        		
        	}
        	else if (currLocation == "Graveyard of the cursed") {
        		dropItem("Seed of hatred");
        		add_item("Plagued sword",1 ,4.0 ,200 ,-40 ,"weapon");
        		
        	}
        	else { System.out.println("You cannot grow the Seed of hatred here.") ;
        	}
        }
        else if (selectedItem.name == "Holy Water") { 
        	Item foundItem1 = searchItemByName("Cursed armour");
        	if (foundItem1 != null) {
                System.out.println("You removed the curse on the armour. It now shines");
                dropItem(foundItem1.name);
                dropItem("Holy Water");
                add_item("Shining armour", 3, 2.8, 25, 15, "armour");
            } else {
                System.out.println("You don't have the Cursed armour.");
                itemUsed = false;
            }
        	
        }
        
        else if (selectedItem.name == "Potion") {      	
        	dropItem("Potion");
        	stats1.heal();
        	add_item("Empty bottle", 1, 0.1, 0, 0, "empty bottle");
        }
        
        else if (selectedItem.name == "Empty bottle") {
        	if(currLocation == "Magical lake") {
        		dropItem("Empty bottle");
        		add_item("Potion", 1, 0.5, 0, 0, "Healing potion");
        		System.out.println("You regained your Potion.");
        	}
        	else {
        		System.out.println("You can only refill the Empty bottle at Magical lake.");
        		itemUsed = false;
        	}
        	
        }
        
        else if (selectedItem.name == "Ball") {
        	if(currLocation =="Hermit's cave") {
        System.out.println("You dare to return after you killed my entire village!? Die.");
        System.exit(0); // the hermit is immensely powerful.
        }
        	else {
        		System.out.println("Realizing what you have done, you get rid of the evidence.");
        		dropItem("Ball");
        	}
        }
        
        else if (selectedItem.name == "Flour") {
        	if(currLocation =="Magical lake") {
        		dropItem("Flour");
        		add_item("Magical Bread", 2 , 0 , 0 ,0 ,"offering");
        		
        	}
        	else if (currLocation == "Village of the hungry") {
        		dropItem("Flour"); // the villagers have the yeast, water, cooking pot etc.
        		System.out.println("You give the villagers bread. They give you a magic scroll as a reward.");
        		add_item("Magic scroll",1,2 ,0 ,0 ,"pass");
        		
        	}
        	else {
        		System.out.println("You cannot use the flour here.");
        		itemUsed = false;
        	}
        	
        }
        
        else if (selectedItem.name == "Cooking Pot") {
        	Item foundItemF = searchItemByName("Flour");
        	if (foundItemF != null) {
        		Item foundItemW = searchItemByName("Wood");
        		 if (foundItemW != null) {
        			 dropItem("Flour");
        			 dropItem("Wood");
        			 add_item("Bread",2,0.4 , 0 ,0 ,"bread"); // a flat bread.
        			 
        		 }
        		 else {
        			 System.out.println("You have the flour needed, but you don't have wood. You can find some at the shipyard.");
        			 itemUsed = false;
        		 }
        		
        		
            } else {
                System.out.println("You don't have the flour needed.");
                itemUsed = false;
            }
        	
        }
        
        else if (selectedItem.name == "Small rock") {
        	
        	Item foundItemw = searchItemByName("Wheat");
        	if (foundItemw != null) {
        		if (currLocation == "Village of the Mill") {
        			dropItem("Wheat");
        			add_item("Flour",1 ,0.1 ,0 ,0 ,"flour");
        			
        			
        		}
        		else {
        			System.out.println("You can only make flour at the Village of the Mill.");
        			itemUsed = false;
        			
        		}
        	}
        	else {
        		System.out.println("You don't have the wheat needed.");
        		itemUsed = false;
        	}
        	
        }
        
        else if (selectedItem.name == "Magic scroll") {
        	mapl.set_blocked();
        	System.out.println("You can now enter Hermit's cave");
        	dropItem("Magic scroll");
        }
        
        else if (selectedItem.name == "cyanide pill") {
        	if(currLocation == "Burning abyss") {
        		System.out.println("The intense heat has transformed your pill into a fire resistance potion.");
        		dropItem("cyanide pill");
        		add_item("Fire Potion", 1, 0.5, 0, 0, "Fire Resistance");
        	}
        	else {
        	System.out.println("You took a cyanide pill. you died.");
        	System.exit(0);
        	}
        	
        }
        
        else if (selectedItem.name == "Bread") {
        	dropItem("Bread");
        	stats1.resistance += 1;
        	stats1.strength += 1;
        	stats1.max_health +=10;
        	stats1.damage(-10);
        	System.out.println("You feel yourself growing stronger.");
        	
        }
        
        else if (selectedItem.name == "Magical Bread") {
        	if (currLocation == "Banished mage") {
        		dropItem("Magical Bread");
        		System.out.println("The Banished mage appreciates your offering. He gives you a severed head in thanks.");
        		add_item("Human head",1,3 ,0 ,0 ,"head");
        		
        	}
        	else {
        		System.out.println("You can only use Magical Bread at the Banished mage.");
        		itemUsed = false;
        	}
        }
        
        else if (selectedItem.name == "Wheat") {
        	if(currLocation == "Burning abyss") {
        	dropItem("Wheat")	;
        	add_item("ash",1,0.2 ,0 ,0 ,"ash");
        	}
        	else
        		System.out.println("You cannot use Wheat anywhere but the Burning abyss.");
        	itemUsed = false;
        }
        
        else if (selectedItem.name == "Love letter") {
        	if (currLocation =="Banished mage") {
        	dropItem("Love letter");
        	System.out.println("You received a Golden Flower. bring it to Dragon.");
        	add_item("Golden Flower", 1, 0.2, 0, 0, "Decoration"); 
        	}
        	else {
        		System.out.println("Why are you trying to read out dragon's love letter to the whole world.");
        		itemUsed = false;
        		
        	}
        	
        }
        
        
        else if (selectedItem.name == "Fire Potion") {
        	stats1.fire_resistance = 100;
        	dropItem("Fire Potion");
        }
        
        else if (selectedItem.name == "Potion of enhancement") {
        	stats1.strength +=9;
        	stats1.resistance +=9;
        	dropItem("Potion of enhancement");
        }
        
        else if (selectedItem.name == "Gold Coin Pile") {
        	stats1.currency +=500;
        	dropItem("Gold Coin Pile");
        }
        
        else if (selectedItem.name == "Golden Flower") {
        	if(currLocation =="Dragon's lair") {
        		dropItem("Golden Flower");
        		
        	}
        	else if(currLocation =="Village of the rich") {
        		stats1.damage(40);
        		dropItem("Golden Flower");
        		System.out.println("The rich people's bodyguards attack you and take the flower.");
        		
        	}
        	else {
        		System.out.println("Neat flower, but it can only be used in Dragon's lair.");
        		itemUsed = false;
        	}
        	
        }
        
        else if (selectedItem.name == "Human heart") {
        	if(currLocation =="Banished mage") {
        	dropItem("Human heart");
        	System.out.println("You killed dragon, and for what? all you gained was death.");
        	System.exit(0);
        	}
        	else {
        		System.out.println("Why... why are you attempting to use a Human heart");
        		itemUsed = false;
        	}
        	
        }
        
        else if (selectedItem.name == "Human head") {
             if(currLocation =="Dragon's lair") {
            	dropItem("Human head");
             	System.out.println("You killed them and for what? all you gained was death.");
             	System.exit(0);
            	 
        		
        	}
        	else {
        		System.out.println("Why... why are you attempting to use a Human head");
        		itemUsed = false;
        	}
        	
        }
        
        
        else if (selectedItem.name == "Sword") {
        	if(currLocation == "Radiant grove") {
        		dropItem("Sword");
        		add_item("Balanced blade",3 ,2.5 ,20 ,20 ,"weapon");
        		
        	}
        	else {
        		System.out.println("You can only use the Sword in combat and at the Radiant grove.");
        		itemUsed = false;
        	}
        	
        }
        
        
        else if (selectedItem.name == "Helmet") {
            if(currLocation == "Radiant grove") {
            	dropItem("Helmet");
            	add_item("Cleansed helmet",1 ,0.9 ,0 , 15 ,"armour"); 
        		
        	}
        	else {
        		System.out.println("You can only use the Helmet as equipment and at the Radiant grove.");
        		itemUsed = false;
        	}
        	
        }
        else if (selectedItem.name == "Magic stone") {
        	dropItem("Magic stone");
        	System.out.println("You have unlocked the shipyard.");
        	mapl.set_unlocked();
        	
        }
        
        
        
        
       
        
        
        
        // end of item uses
        else {
        	itemUsed = false;
        }
       
        if (itemUsed) {
        System.out.println(selectedItem.name + " was used.");
        }
        
        else {
        	System.out.println("No item was used- you cannot use " + selectedItem.name + " in that location, that way.");
        }
		
		
	}

	public void equipItem() {
        System.out.println("Enter the number of the item you want to equip/unequip (0 to cancel):");
        int index = scanner.nextInt();
        scanner.nextLine(); 

        if (index < 1 || index > items.size()) {
            System.out.println("Invalid item number.");
            return;
        }

        Item selectedItem = items.get(index - 1);

        if (selectedItem.uses.equalsIgnoreCase("weapon")) {
            if (weaponEquipped == selectedItem) {
                weaponEquipped = null; // Unequip weapon
                System.out.println("Weapon unequipped.");
            } else {
                weaponEquipped = selectedItem; // Equip weapon
                System.out.println("Weapon equipped: " + selectedItem.name);
            }
        } else if (selectedItem.uses.equalsIgnoreCase("armour")) {
            if (armourEquipped == selectedItem) {
                armourEquipped = null; // Unequip armour
                System.out.println("Armour unequipped.");
            } else {
                armourEquipped = selectedItem; // Equip armour
                System.out.println("Armour equipped: " + selectedItem.name);
            }
        }
    }

    public void removeEquipped() {
        System.out.println("Enter the type of item you want to remove ('weapon' or 'armour'):");
        String itemType = scanner.nextLine().trim().toLowerCase();

        if (itemType.equals("weapon")) {
            if (weaponEquipped != null) {
                space_remaining += weaponEquipped.spaceNeeded; // Add space back to inventory
                weaponEquipped = null; // Remove weapon
                System.out.println("Weapon removed.");
            } else {
                System.out.println("No weapon equipped.");
            }
        } else if (itemType.equals("armour")) {
            if (armourEquipped != null) {
                space_remaining += armourEquipped.spaceNeeded; // Add space back to inventory
                armourEquipped = null; // Remove armour
                System.out.println("Armour removed.");
            } else {
                System.out.println("No armour equipped.");
            }
        } else {
            System.out.println("Invalid item type. Please enter 'weapon' or 'armour'.");
        }
    }
    
    public void dropItem() {

        System.out.println("Enter the number of the item you want to drop (0 to cancel):");
        int index = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        if (index < 1 || index > items.size()) {
            System.out.println("Invalid item number.");
            return;
        }

        Item itemToDrop = items.get(index - 1);

        // Check if the item to drop is equipped (weapon or armour)
        if (itemToDrop == weaponEquipped) {
            weaponEquipped = null; // Unequip weapon
            System.out.println("Weapon '" + itemToDrop.name + "' unequipped.");
            carried_mass -= itemToDrop.massRequired; // Reduce carried mass only
        }

        if (itemToDrop == armourEquipped) {
            armourEquipped = null; // Unequip armour
            System.out.println("Armour '" + itemToDrop.name + "' unequipped.");
            carried_mass -= itemToDrop.massRequired; // Reduce carried mass only
        }

        // Remove the item from the inventory
        items.remove(itemToDrop);

        // Display appropriate message
        System.out.println("Item '" + itemToDrop.name + "' dropped from inventory.");
    }
    
    public void dropItem(String itemName) {
        // Find the item in the inventory by name
        Item itemToDrop = null;
        for (Item item : items) {
            if (item.name.equalsIgnoreCase(itemName)) {
                itemToDrop = item;
                break;
            }
        }

        if (itemToDrop == null) {
            System.out.println("Item '" + itemName + "' not found in inventory.");
            return;
        }

        // Check if the item to drop is equipped (weapon or armour)
        if (itemToDrop == weaponEquipped) {
            weaponEquipped = null; // Unequip weapon
            System.out.println("Weapon '" + itemToDrop.name + "' unequipped.");
            carried_mass -= itemToDrop.massRequired; // Reduce carried mass only
        }

        if (itemToDrop == armourEquipped) {
            armourEquipped = null; // Unequip armour
            System.out.println("Armour '" + itemToDrop.name + "' unequipped.");
            carried_mass -= itemToDrop.massRequired; // Reduce carried mass only
        }

        // Remove the item from the inventory
        items.remove(itemToDrop);

        // Update space remaining and carried mass
        space_remaining += itemToDrop.spaceNeeded;
        carried_mass -= itemToDrop.massRequired;

        // Display appropriate message
        System.out.println("Item '" + itemToDrop.name + "' dropped from inventory.");
    }
    
    

    public void goBack(Map returnedMap) {
        returnedMap.Action();
    }
    
    public void plagueCheck() {
    	if (plague >= 3) {
    		System.out.println("You died due to the plague.");
    		System.exit(0);
    		
    	}
    }
    
    public Item searchItemByName(String itemName) {
        for (Item item : items) {
            if (item.name.equalsIgnoreCase(itemName)) {
                return item; // Found the item with matching name
            }
        }
        return null; // Item not found
    }
    
    public void send_equipped() {
    	
    	if (weaponEquipped == null) {
    		wep_attack1 = 0;
    		wep_armor1 = 0;   		
    	}
    	else {
    		wep_attack1 = weaponEquipped.attackValue;
    		wep_armor1 = weaponEquipped.armourValue;
    	}
    	
    	if(armourEquipped == null) {
    		armour_attack1 = 0;
    		armour_armor1 = 0;
    	}
    	else {
    		armour_attack1 = armourEquipped.attackValue;
    		armour_armor1 = armourEquipped.armourValue;
    	}
    	
    }
    
}
