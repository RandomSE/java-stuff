
public class Main {

	public static void main(String[] args) {
		
		

		 Map map = new Map();
		 map.begin();		
		 map.Action();		
		
		// TODO below .
	
		// incomplete.

	}

}
