import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Calculator implements ActionListener {

	// more complex than python calculator. The ... buttons: first one removes 1 char, second 1 removes all text, third multiplies by -1.
    JFrame frame;
    JTextField textfield;
    JButton[] numberButtons = new JButton[10];
    JButton[] functionButtons = new JButton[9];
    Font myFont = new Font("Comic Sans MS", Font.BOLD, 30);
    double num1 = 0, num2 = 0, result = 0;
    char operator;

    Calculator() {
        frame = new JFrame("Calculator");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 550);
        frame.setLayout(null); // Avoid using null layout; prefer BorderLayout or GridLayout

        textfield = new JTextField();
        textfield.setBounds(50, 25, 300, 50);
        textfield.setFont(myFont);
        textfield.setEditable(false);
        frame.add(textfield); // Add textfield to the frame

        initializeButtons(); // Initialize numberButtons and functionButtons

        JPanel panel = new JPanel();
        panel.setBounds(50, 100, 300, 300);
        panel.setLayout(new GridLayout(4, 4, 10, 10));

        addButtonsToPanel(panel); // Add buttons to the panel

        frame.add(panel); // Add panel to the frame
        frame.setVisible(true);
    }

    private void initializeButtons() {
        for (int i = 0; i < 10; i++) {
            numberButtons[i] = new JButton(String.valueOf(i));
            numberButtons[i].addActionListener(this);
            numberButtons[i].setFont(myFont);
        }

        String[] functionLabels = {"+", "-", "*", "/", ".", "=", "Del", "Clr", "(-)"};
        for (int i = 0; i < functionLabels.length; i++) {
            functionButtons[i] = new JButton(functionLabels[i]);
            functionButtons[i].addActionListener(this);
            functionButtons[i].setFont(myFont);
        }
    }

    private void addButtonsToPanel(JPanel panel) {
        // Add number buttons to the panel
        for (JButton button : numberButtons)
            panel.add(button);

        // Add function buttons to the panel
        for (JButton button : functionButtons)
            panel.add(button);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String buttonText = ((JButton) e.getSource()).getText();

        if (buttonText.matches("[0-9]")) {
            textfield.setText(textfield.getText() + buttonText);
        } else if (buttonText.equals(".")) {
            if (!textfield.getText().contains("."))
                textfield.setText(textfield.getText() + ".");
        } else if (buttonText.matches("[+\\-*/]")) {
            num1 = Double.parseDouble(textfield.getText());
            operator = buttonText.charAt(0);
            textfield.setText("");
        } else if (buttonText.equals("=")) {
            num2 = Double.parseDouble(textfield.getText());
            switch (operator) {
                case '+':
                    result = num1 + num2;
                    break;
                case '-':
                    result = num1 - num2;
                    break;
                case '*':
                    result = num1 * num2;
                    break;
                case '/':
                    if (num2 != 0)
                        result = num1 / num2;
                    else
                        result = Double.POSITIVE_INFINITY; // Handle division by zero
                    break;
            }
            textfield.setText(String.valueOf(result));
            num1 = result;
        } else if (buttonText.equals("Clr")) {
            textfield.setText("");
        } else if (buttonText.equals("Del")) {
            String currentText = textfield.getText();
            if (!currentText.isEmpty())
                textfield.setText(currentText.substring(0, currentText.length() - 1));
        } else if (buttonText.equals("(-)")) {
            double currentValue = Double.parseDouble(textfield.getText());
            textfield.setText(String.valueOf(-currentValue));
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new Calculator();
        });
    }
}
