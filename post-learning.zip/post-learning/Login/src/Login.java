import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
public class Login implements ActionListener{
	
	JFrame frame = new JFrame();
	JButton loginButton = new JButton("Login");
	JButton resetButton = new JButton("Reset");
	JButton newUserButton = new JButton("New User");
	JTextField userIDField = new JTextField();
	JPasswordField userPasswordField = new JPasswordField();
	JLabel userIDLabel = new JLabel("userID:");
	JLabel userPasswordLabel = new JLabel("password:");
	JLabel messageLabel = new JLabel();
	HashMap<String,String> logininfo = new HashMap<String,String>();
	
	Login(HashMap<String,String> loginInfoOriginal){
		
		logininfo = loginInfoOriginal;
		
		// Adjusted for 1080x720 screen

		userIDLabel.setBounds(100, 150, 150, 50);
		userPasswordLabel.setBounds(100, 225, 150, 50);

		messageLabel.setBounds(300, 350, 400, 50);
		messageLabel.setFont(new Font(null, Font.ITALIC, 35));

		userIDField.setBounds(300, 150, 300, 50);
		userPasswordField.setBounds(300, 225, 300, 50);

		loginButton.setBounds(300, 300, 150, 50);
		loginButton.setFocusable(false);
		loginButton.addActionListener(this);

		resetButton.setBounds(450, 300, 150, 50);
		resetButton.setFocusable(false);
		resetButton.addActionListener(this);

		newUserButton.setBounds(550, 350, 225, 75);
		newUserButton.setFocusable(false);
		newUserButton.addActionListener(this);

		
		frame.add(userIDLabel);
		frame.add(userPasswordLabel);
		frame.add(messageLabel);
		frame.add(userIDField);
		frame.add(userPasswordField);
		frame.add(loginButton);
		frame.add(resetButton);
		frame.add(newUserButton);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(1080,720);
		frame.setLayout(null);
		frame.setVisible(true);
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource()==resetButton) {
			userIDField.setText("");
			userPasswordField.setText("");
		}
		
		if(e.getSource() == newUserButton) {
			
			
			 // Create a new frame with text fields and a button
            JFrame newFrame = new JFrame("New User Frame");
            newFrame.setSize(400, 200);
            newFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Dispose the frame on close

            // Panel for holding components
            JPanel panel = new JPanel(new GridLayout(3, 1));

            // Text fields
            JTextField usernameField = new JTextField(20);
            JTextField passwordField = new JTextField(20);

            // Button to create ValidInfo and call newUser
            JButton createUserButton = new JButton("Create User");
            createUserButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    // Create instance of ValidInfo and call newUser
                    String username = usernameField.getText();
                    String password = passwordField.getText();
                    
                    ValidInfo vi = new ValidInfo();
                    vi.newUser(username, password);
                    System.out.println("New user created. username: " + username + "  Password: "  + password);

                    // Close the new frame after creating user
                    newFrame.dispose();
                }
            });

            // Add components to the panel
            panel.add(new JLabel("Username:"));
            panel.add(usernameField);
            panel.add(new JLabel("Password:"));
            panel.add(passwordField);
            panel.add(createUserButton);

            // Add panel to the new frame and make it visible
            newFrame.add(panel);
            newFrame.setVisible(true);
		}
		
		if(e.getSource()==loginButton) {
			
			String userID = userIDField.getText();
			String password = String.valueOf(userPasswordField.getPassword());
			
			if(logininfo.containsKey(userID)) {
				if(logininfo.get(userID).equals(password)) {
					messageLabel.setForeground(Color.green);
					messageLabel.setText("Login successful");
					frame.dispose();
					WelcomePage welcomePage = new WelcomePage(userID);
				}
				else {
					messageLabel.setForeground(Color.red);
					messageLabel.setText("Wrong password");
				}

			}
			else {
				messageLabel.setForeground(Color.red);
				messageLabel.setText("username not found");
			}
		}
	}	
}