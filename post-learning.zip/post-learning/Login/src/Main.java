

public class Main {
	

	public static void main(String[] args) {
		
		
		ValidInfo VI = new ValidInfo();
		Login login = new Login(VI.getDetails());
		
		
		
		
			
		

	}

}
