import java.util.HashMap;

public class ValidInfo {
    // Static HashMap to store user details
    private static HashMap<String, String> details = new HashMap<>();

    static {
        // Pre-populate the HashMap with initial user details
        details.put("asideastrideverbally", "tyHaL5p9");
        details.put("tillthroughhmphoddly", "RNoOUCUY");
        details.put("anenstooffurthermore", "IqLFR8cI");
        details.put("criticiseblahsweetly", "uzIUm0Jc");
        details.put("linedincidentallypet", "0r28dz91");
    }

    public static HashMap<String, String> getDetails() {
        return details;
    }

    public static void newUser(String uName, String pWord) {
        details.put(uName, pWord); // Add a new user
    }
}