import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Main extends JFrame implements ActionListener {

    private JLabel[] progressLabels;
    private JButton[] answerButtons;
    private int currentQuestionIndex;
    private int correctAnswers;

    // Define the quiz questions and answers
    private String[][] questions = {
            {"What keyword is used to define a subclass in Java?", "a. subclass", "b. extends", "c. inherits", "d. implements", "b"},
            {"What is the size of an int variable in Java?", "a. 16 bits", "b. 32 bits", "c. 64 bits", "d. It depends on the system", "b"},
            {"Which of the following is not a primitive data type in Java?", "a. int", "b. float", "c. string", "d. boolean", "c"},
            {"Which loop is guaranteed to execute at least once in Java?", "a. for loop", "b. while loop", "c. do-while loop", "d. switch statement", "c"},
            {"What does JVM stand for?", "a. Java Variable Machine", "b. Java Virtual Machine", "c. Java Visual Module", "d. Java View Model", "b"},
            {"Which access modifier is the most restrictive in Java?", "a. private", "b. protected", "c. public", "d. default (no modifier)", "a"},
            {"What is the correct way to declare a constant in Java?", "a. final int MAX_VALUE = 100;", "b. const int MAX_VALUE = 100;", "c. static int MAX_VALUE = 100;", "d. int MAX_VALUE = 100;", "a"},
            {"Which class is the superclass of all other classes in Java?", "a. Object", "b. Class", "c. Super", "d. None of the above", "a"},
            {"What is the purpose of the 'break' statement in Java?", "a. Exit a loop or switch statement", "b. Continue to the next iteration of a loop", "c. Terminate the program", "d. Print a message to the console", "a"},
            {"Which data structure uses LIFO (Last-In, First-Out) order?", "a. Queue", "b. Stack", "c. ArrayList", "d. LinkedList", "b"}
    };

    public Main() {
        super("Java Quiz Game");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1080, 720);
        setLayout(new GridLayout(12, 1));

        Font questionFont = new Font("Arial", Font.PLAIN, 12);
        Font buttonFont = new Font("Arial", Font.PLAIN, 20);

        progressLabels = new JLabel[10];
        answerButtons = new JButton[4];

        for (int i = 0; i < 10; i++) {
            progressLabels[i] = new JLabel();
            progressLabels[i].setFont(questionFont);
            add(progressLabels[i]);
        }

        for (int i = 0; i < 4; i++) {
            answerButtons[i] = new JButton();
            answerButtons[i].setFont(buttonFont);
            answerButtons[i].setActionCommand(String.valueOf((char)('a' + i)));
            answerButtons[i].addActionListener(this);
            add(answerButtons[i]);
        }

        currentQuestionIndex = 0;
        correctAnswers = 0;
        displayQuestion();
    }

    private void displayQuestion() {
        if (currentQuestionIndex < questions.length) {
            // Display question and answer choices
            String[] question = questions[currentQuestionIndex];
            progressLabels[currentQuestionIndex].setText(question[0]);
            for (int i = 0; i < 4; i++) {
                answerButtons[i].setText(question[i + 1]);
            }
        } else {
            // Quiz ended, show result
            double percentage = (double) correctAnswers / questions.length * 100;
            JOptionPane.showMessageDialog(this, "Quiz completed!\nYou scored " + percentage + "%");
            System.exit(0); // Exit the program after displaying the result
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String selectedAnswer = e.getActionCommand();
        String correctAnswer = questions[currentQuestionIndex][5];

        if (selectedAnswer.equals(correctAnswer)) {
            progressLabels[currentQuestionIndex].setForeground(Color.GREEN);
            correctAnswers++;
        } else {
            progressLabels[currentQuestionIndex].setForeground(Color.RED);
        }

        currentQuestionIndex++;
        displayQuestion();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new Main().setVisible(true);
        });
    }
}
