import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

public class PongGame extends JFrame {

    private static final int GAME_WIDTH = 1000;
    private static final int GAME_HEIGHT = (int) (GAME_WIDTH * (0.5555));
    private static final Dimension SCREEN_SIZE = new Dimension(GAME_WIDTH, GAME_HEIGHT);

    private GamePanel panel;

    public PongGame() {
        setTitle("Enhanced Pong Game"); // Almost entirely from Bro Code on Youtube, with some minor changes.
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setSize(SCREEN_SIZE);
        setLocationRelativeTo(null);

        panel = new GamePanel();
        add(panel);

        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new PongGame());
    }
}