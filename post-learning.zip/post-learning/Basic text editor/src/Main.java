import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.datatransfer.*;
import java.io.*;

public class Main extends JFrame {

    private JTextArea inputTextArea;
    private JLabel outputLabel;

    public Main() {
        setTitle("Text Editor");
        setSize(1080, 720);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        inputTextArea = new JTextArea();
        inputTextArea.setLineWrap(true);
        inputTextArea.setWrapStyleWord(true);

        JScrollPane scrollPane = new JScrollPane(inputTextArea);
        scrollPane.setPreferredSize(new Dimension(400, 150));
        add(scrollPane, BorderLayout.NORTH);

        JPanel controlPanel = new JPanel();

        JButton colorButton = new JButton("Color");
        colorButton.addActionListener(e -> {
            Color color = JColorChooser.showDialog(Main.this, "Choose Color", Color.BLACK);
            inputTextArea.setForeground(color);
        });
        controlPanel.add(colorButton);

        String[] fontNames = GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames();
        JComboBox<String> fontComboBox = new JComboBox<>(fontNames);
        fontComboBox.addActionListener(e -> {
            String selectedFont = (String) fontComboBox.getSelectedItem();
            inputTextArea.setFont(new Font(selectedFont, Font.PLAIN, inputTextArea.getFont().getSize()));
        });
        controlPanel.add(fontComboBox);

        Integer[] fontSizes = {12, 14, 16, 18, 20, 24, 28, 32};
        JComboBox<Integer> fontSizeComboBox = new JComboBox<>(fontSizes);
        fontSizeComboBox.addActionListener(e -> {
            int selectedSize = (int) fontSizeComboBox.getSelectedItem();
            inputTextArea.setFont(inputTextArea.getFont().deriveFont((float) selectedSize));
        });
        controlPanel.add(fontSizeComboBox);

        add(controlPanel, BorderLayout.CENTER);

        outputLabel = new JLabel();
        outputLabel.setVerticalAlignment(JLabel.TOP);
        add(outputLabel, BorderLayout.SOUTH);

        JButton applyButton = new JButton("Apply");
        applyButton.addActionListener(e -> updateOutput());
        add(applyButton, BorderLayout.SOUTH);

        // Create menu bar
        JMenuBar menuBar = new JMenuBar();
        setJMenuBar(menuBar);

        // File menu
        JMenu fileMenu = new JMenu("File");
        menuBar.add(fileMenu);

        // Copy menu item
        JMenuItem copyMenuItem = new JMenuItem("Copy");
        copyMenuItem.addActionListener(e -> {
            String selectedText = inputTextArea.getSelectedText();
            if (selectedText != null && !selectedText.isEmpty()) {
                StringSelection selection = new StringSelection(selectedText);
                Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
                clipboard.setContents(selection, null);
            }
        });
        fileMenu.add(copyMenuItem);

        // Paste menu item
        JMenuItem pasteMenuItem = new JMenuItem("Paste");
        pasteMenuItem.addActionListener(e -> {
            Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
            Transferable contents = clipboard.getContents(null);
            if (contents != null && contents.isDataFlavorSupported(DataFlavor.stringFlavor)) {
                try {
                    String pastedText = (String) contents.getTransferData(DataFlavor.stringFlavor);
                    inputTextArea.append(pastedText);
                } catch (UnsupportedFlavorException | IOException ex) {
                    ex.printStackTrace();
                }
            }
        });
        fileMenu.add(pasteMenuItem);

        // Save menu item
        JMenuItem saveMenuItem = new JMenuItem("Save");
        saveMenuItem.addActionListener(e -> {
            JFileChooser fileChooser = new JFileChooser();
            if (fileChooser.showSaveDialog(Main.this) == JFileChooser.APPROVE_OPTION) {
                File file = fileChooser.getSelectedFile();
                try (PrintWriter writer = new PrintWriter(new FileWriter(file))) {
                    writer.write(inputTextArea.getText());
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        });
        fileMenu.add(saveMenuItem);

        // Load menu item
        JMenuItem loadMenuItem = new JMenuItem("Load");
        loadMenuItem.addActionListener(e -> {
            JFileChooser fileChooser = new JFileChooser();
            FileNameExtensionFilter filter = new FileNameExtensionFilter("Text Files", "txt");
            fileChooser.setFileFilter(filter);
            if (fileChooser.showOpenDialog(Main.this) == JFileChooser.APPROVE_OPTION) {
                File file = fileChooser.getSelectedFile();
                try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        sb.append(line).append("\n");
                    }
                    inputTextArea.setText(sb.toString());
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        });
        fileMenu.add(loadMenuItem);
        
     // Exit menu item
        JMenuItem exitMenuItem = new JMenuItem("Exit");
        exitMenuItem.addActionListener(e -> System.exit(0));
        fileMenu.add(exitMenuItem);
    }

    private void updateOutput() {
        String text = inputTextArea.getText();
        Font font = inputTextArea.getFont();
        Color color = inputTextArea.getForeground();

        String htmlText = String.format("<html><span style='font-family:%s; font-size:%dpt; color:rgb(%d,%d,%d);'>%s</span></html>",
                font.getFamily(), font.getSize(), color.getRed(), color.getGreen(), color.getBlue(), text);

        outputLabel.setText(htmlText);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Main editor = new Main();
            editor.setVisible(true);
        });
    }
}
