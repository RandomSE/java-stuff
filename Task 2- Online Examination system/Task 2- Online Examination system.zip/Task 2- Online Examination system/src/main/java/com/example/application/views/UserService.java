package com.example.application.views;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class UserService {

    private static final String STUDENT_FILE = "students.txt";
    private static final String TEACHER_FILE = "teachers.txt";
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    // Folder for individual student files
    private static final String STUDENT_FOLDER = "student_files";

    public UserService() {
        // Create directory for student files if it doesn't exist
        File studentFolder = new File(STUDENT_FOLDER);
        if (!studentFolder.exists()) {
            studentFolder.mkdirs();
        }
    }

    // Register a new user (S for Student, T for Teacher)
    public String registerUser(String name, String password, String role) {
        String userId = generateUserId(role);
        String file = role.equals("S") ? STUDENT_FILE : TEACHER_FILE;

        if (isDuplicateUser(name, file)) {
            return "duplicate";
        }

        // Get the current date
        String registrationDate = LocalDate.now().format(DATE_FORMATTER);

        // Save user to the main student or teacher file
        saveUserToFile(userId, name, password, registrationDate, file);

        // If the user is a student, create a folder for them
        if (role.equals("S")) {
            createStudentFolderAndFile(userId, name, registrationDate);
        }

        return userId;
    }

    private void createStudentFolderAndFile(String studentID, String fullName, String registrationDate) {
        // Create a folder with the student's full name inside student_files
        String folderPath = STUDENT_FOLDER + "/" + studentID;
        File studentFolder = new File(folderPath);
        
        if (!studentFolder.exists()) {
            studentFolder.mkdirs();  // Create the folder if it doesn't exist
        }

        // Create the student's file inside their folder
        String fileName = folderPath + "/" + studentID + ".txt";
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            writer.write("Student ID: " + studentID + "\n");
            writer.write("Full Name: " + fullName + "\n");
            writer.write("Date Registered: " + registrationDate + "\n");
            writer.write("Exams taken: \n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Login validation: Check if ID and password match
    public boolean validateLogin(String userId, String password, String role) {
        String file = role.equals("S") ? STUDENT_FILE : TEACHER_FILE;
        return checkCredentials(userId, password, file);
    }

    // Check for duplicate users
    private boolean isDuplicateUser(String name, String file) {
        try {
            List<String> lines = Files.readAllLines(Paths.get(file));
            for (String line : lines) {
                String[] userInfo = line.split(",");
                if (userInfo[1].equals(name)) {
                    return true;  // Duplicate found
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Save user data to the main file
    private void saveUserToFile(String userId, String name, String password, String registrationDate, String file) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file, true))) {
            // Save the user in format: userId, name, password, registrationDate
            writer.write(userId + "," + name + "," + password + "," + registrationDate);
            writer.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Check if the credentials match
    private boolean checkCredentials(String userId, String password, String file) {
        try {
            List<String> lines = Files.readAllLines(Paths.get(file));
            for (String line : lines) {
                String[] userInfo = line.split(",");
                if (userInfo[0].equals(userId) && userInfo[2].equals(password)) {
                    return true;  // ID and password match
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Generate a unique user ID (S-001 for Students, T-001 for Teachers)
    private String generateUserId(String role) {
        int count = getUserCount(role);
        return role + "-" + String.format("%03d", count + 1);
    }

    // Count the number of users (students or teachers) in their respective file
    private int getUserCount(String role) {
        String file = role.equals("S") ? STUDENT_FILE : TEACHER_FILE;
        try {
            Path path = Paths.get(file);
            if (Files.exists(path)) {
                return (int) Files.lines(path).count();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return 0;
    }

   
}
