package com.example.application.views;

import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.PasswordField;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.router.Route;

@Route("register")
public class RegisterView extends VerticalLayout {

    private UserService userService = new UserService();

    public RegisterView() {
        // Student Registration
        TextField studentName = new TextField("Student Full Name");
        PasswordField studentPassword = new PasswordField("Password");
        PasswordField studentConfirmPassword = new PasswordField("Confirm Password");

        Button registerStudentButton = new Button("Register Student", event -> {
            String name = studentName.getValue();
            if (validatePassword(studentPassword.getValue(), studentConfirmPassword.getValue())) {
                String studentID = userService.registerUser(name, studentPassword.getValue(), "S");
                handleRegistrationResult(studentID, "Student");
                studentName.clear();
                studentPassword.clear();
                studentConfirmPassword.clear();
              
            }
        });

        // Teacher Registration
        TextField teacherName = new TextField("Teacher Full Name");
        PasswordField teacherPassword = new PasswordField("Password");
        PasswordField teacherConfirmPassword = new PasswordField("Confirm Password");

        Button registerTeacherButton = new Button("Register Teacher", event -> {
            String name = teacherName.getValue();
            if (validatePassword(teacherPassword.getValue(), teacherConfirmPassword.getValue())) {
                String teacherID = userService.registerUser(name, teacherPassword.getValue(), "T");
                handleRegistrationResult(teacherID, "Teacher");
                teacherName.clear();
                teacherPassword.clear();
                teacherConfirmPassword.clear();
            }
        });

        // Back to Login Button
        Button backButton = new Button("Back to Login", event -> {
            UI.getCurrent().navigate("login");  // Navigate to the login view
        });

        add(
            new VerticalLayout(studentName, studentPassword, studentConfirmPassword, registerStudentButton),
            new VerticalLayout(teacherName, teacherPassword, teacherConfirmPassword, registerTeacherButton),
            backButton // Add the Back to Login button at the end
        );
    }

    private boolean validatePassword(String password, String confirmPassword) {
        if (password.equals(confirmPassword)) {
            return true;
        } else {
            Notification.show("Passwords do not match", 3000, Notification.Position.MIDDLE);
            return false;
        }
    }

    private void handleRegistrationResult(String userID, String role) {
        if ("duplicate".equals(userID)) {
            Notification.show(role + " with this name is already registered!", 3000, Notification.Position.MIDDLE);
        } else {
            showDialog(userID);
        }
    }

    private void showDialog(String userID) {
        Dialog dialog = new Dialog();
        dialog.add("Your ID is: " + userID + ". Please save it.");
        dialog.open();
    }
}
