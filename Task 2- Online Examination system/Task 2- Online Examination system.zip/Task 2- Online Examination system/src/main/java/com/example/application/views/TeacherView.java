package com.example.application.views;

import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.BeforeEnterEvent;
import com.vaadin.flow.router.BeforeEnterObserver;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.server.VaadinService;

@Route("teacher")
public class TeacherView extends VerticalLayout implements BeforeEnterObserver {

    public TeacherView() {
        Button logoutButton = new Button("Logout", event -> {
            VaadinService.getCurrentRequest().getWrappedSession().invalidate();  // Invalidate session
            getUI().ifPresent(ui -> ui.navigate("login"));  // Redirect to login page
        });

        Button createExamButton = new Button("Create Exam", event -> {
            getUI().ifPresent(ui -> ui.navigate("create-exam"));  // Navigate to CreateExamView
        });
        
        Button manageExamButton = new Button ("Manage Exams", event -> {
        	getUI().ifPresent(ui -> ui.navigate("manage-exams"));
        });

        add(logoutButton, createExamButton, manageExamButton);
    }

    @Override
    public void beforeEnter(BeforeEnterEvent event) {
        // Check if user is logged in as a teacher
        String role = (String) VaadinService.getCurrentRequest().getWrappedSession().getAttribute("role");
        if (role == null || !role.equals("T")) {
            // Redirect to login if not authorized
            Notification.show("Unauthorized Access", 3000, Notification.Position.MIDDLE);
            event.forwardTo("login");
        }
    }
}
