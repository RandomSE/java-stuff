package com.example.application.views;

import com.vaadin.flow.component.Text;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.radiobutton.RadioButtonGroup;
import com.vaadin.flow.component.textfield.TextArea;
import com.vaadin.flow.router.BeforeEnterEvent;
import com.vaadin.flow.router.BeforeEnterObserver;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.server.VaadinRequest;
import com.vaadin.flow.server.VaadinService;
import com.vaadin.flow.server.VaadinSession;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Route("take-exam")
public class TakeExamView extends VerticalLayout implements BeforeEnterObserver {
    private Map<String, String> studentInfo = new HashMap<>();
    private List<String> examsTaken = new ArrayList<>();
    private List<Map<String, Object>> questions = new ArrayList<>();
    private int currentQuestionIndex = 0;
    private String examTitle;
    private String gStudentID;
    private String[] studentAnswers;
    private Button nextButton;
    private Button prevButton;
    private Button submitButton;
    private RadioButtonGroup<String> radioGroup;
    private TextArea textArea;
    private long examDuration;  // Exam duration in seconds
    private Text timerText = new Text("");   // To show the time left
    private Text numQuestionText = new Text(""); // the base for how many questions are left.
    private boolean examSubmitted = false; // checks whether the exam has been submitted.
    private Thread timerThread; // a specific thread used for the timer.
    private int questionsRemaining = 0; // self explanatory.
    private int totalMarks = 0 ;
    private Map<String, Object> memoData = new HashMap<>(); // Stores memo data here
    private double studentMarks = 0; // Store student's total marks

    public TakeExamView() {
        // Button to go back to StudentView
        Button backButton = new Button("Back to Student View", event -> {
            getUI().ifPresent(ui -> ui.navigate("student"));
        });
        add(backButton);

        // Fetch and display available exams
        checkAvailableExams();
    }
    
    @Override
    public void beforeEnter(BeforeEnterEvent event) {
        String studentID = (String) VaadinService.getCurrentRequest().getWrappedSession().getAttribute("userID");

        if (studentID == null) {
            // Redirect to login if user is not logged in
            event.rerouteTo(LoginView.class);
        }
    }
    
    

    private void checkAvailableExams() {
        String studentID = (String) VaadinService.getCurrentRequest().getWrappedSession().getAttribute("userID");
        gStudentID = studentID;

        if (studentID != null) {
            // Read the student's file
            String studentFilePath = "student_files/" + studentID + "/" + studentID + ".txt";
            try {
                List<String> lines = Files.readAllLines(Paths.get(studentFilePath));

                // Extract registration date and exams taken
                for (String line : lines) {
                    if (line.startsWith("Date Registered:")) {
                        String[] parts = line.split(": ");
                        studentInfo.put("registeredDate", parts[1].trim());
                    }
                    if (line.startsWith("Exams taken:")) {
                        int index = lines.indexOf(line);
                        for (int i = index + 1; i < lines.size(); i++) {
                            if (!lines.get(i).isEmpty()) {
                                examsTaken.add(lines.get(i).trim());
                            }
                        }
                    }
                }

                // Get the student's registration date
                LocalDate studentRegisteredDate = LocalDate.parse(studentInfo.get("registeredDate"), DateTimeFormatter.ofPattern("yyyy-MM-dd"));

                // Read all exam files from the "exams" folder
                File examsFolder = new File("exams");
                File[] examFiles = examsFolder.listFiles();

                if (examFiles != null) {
                    for (File examFile : examFiles) {
                        List<String> examContent = Files.readAllLines(examFile.toPath());
                        examTitle = "";
                        LocalDate examCreationDate = null;

                        // Extract exam title and creation date
                        for (String line : examContent) {
                            if (line.startsWith("Exam Title:")) {
                                examTitle = line.split(": ")[1].trim();
                            }
                            if (line.startsWith("Exam Creation Date:")) {
                                examCreationDate = LocalDate.parse(line.split(": ")[1].trim(), DateTimeFormatter.ofPattern("yyyy-MM-dd"));
                            }
                        }

                        // Check if the student has already taken this exam or if it was created before registration
                        if (!examsTaken.contains(examTitle) && examCreationDate.isAfter(studentRegisteredDate)) {
                            // Use a final copy of examTitle for the lambda
                            final String finalExamTitle = examTitle;
                            
                            // Create a button for the exam and attach a click listener
                            Button examButton = new Button(finalExamTitle, event -> loadExam(finalExamTitle, studentFilePath));
                            add(examButton);
                        }
                    }
                }

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }



    private void loadExam(String examTitle1, String studentFilePath) {
        String examFilePath = "exams/" + examTitle1 + ".txt";
        examTitle = examTitle1;
        try {
            List<String> lines = Files.readAllLines(Paths.get(examFilePath));
            parseExam(lines);
            displayCurrentQuestion();
            startTimer(examDuration);
            
             
         // Add examTitle to the end of the student file
            try (FileWriter fw = new FileWriter(studentFilePath, true);
                 BufferedWriter bw = new BufferedWriter(fw)) {
                bw.newLine(); // Add a new line before writing
               bw.write(examTitle); 
            } catch (IOException e) {
                e.printStackTrace();
            }
            
            
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void parseExam(List<String> lines) {
        Map<String, Object> question = null;

        for (int i = 0; i < lines.size(); i++) {
            String line = lines.get(i).trim();  // Trim leading/trailing spaces


            // Parse Time Limit
            if (line.startsWith("Time Limit:")) {
                double timeLimitMinutes = Double.parseDouble(line.split(": ")[1].split(" ")[0]);
                examDuration = (long) timeLimitMinutes;               
            }
          
            // Initialize the question when we encounter a new "Question:" line
            if (line.startsWith("Question:")) {
                question = new HashMap<>();
                question.put("questionText", line.split(": ", 2)[1].trim());  // Store the question text
            }

            // Ensure question is not null before proceeding
            if (question != null) {
                if (line.startsWith("Answer Type:")) {
                    if (line.contains("True/False")) {
                        question.put("type", "true_false");
                    } else if (line.contains("Multiple Choice")) {
                    	question.put("type", "multiple_choice");
                    	String marksLine = lines.get(i + 1).trim();
                    	if (marksLine.startsWith("Marks:")) {
                            double marks = Double.parseDouble(marksLine.split(": ")[1]);
                            question.put("marks", marks); } // Store the marks
                        List<String> options = new ArrayList<>();
                        for (int j = i +3; j <= i+6; j++) {
                        	String optionLine = lines.get(j).trim(); 
                        		String optionValue = optionLine.split(": ")[1].trim();
                        		options.add(optionValue);
                        }
                        
                        if (!options.isEmpty()) {
                        	question.put("options", options);
                        	questions.add(question);// Important that this is here. It does not add the question from line 215 for multiple choice, for some reason.
                        	questionsRemaining +=1;
                        }
                        else {
                        	System.out.println("No options found for some reason.");
                        }
                        i +=4;
                        
                    } else if (line.contains("Short Text Answer")) {
                        question.put("type", "short_text");
                    }
                    
                    // Extract the marks from the next line after Answer Type
                    String marksLine = lines.get(i + 1).trim();
                    if (marksLine.startsWith("Marks:")) {
                        double marks = Double.parseDouble(marksLine.split(": ")[1]);
                        question.put("marks", marks);  // Store the marks
                    }
                }
                

                
                // When all the necessary data for a question has been gathered, add it to the list
                if (line.startsWith("Marks:") || i == lines.size() - 1) {
                    questions.add(question);
                    questionsRemaining +=1;
                    question = null;  // Reset for the next question
                }
            }
        

        studentAnswers = new String[questions.size()];
      }
    }


    private void displayCurrentQuestion() {
        removeAll();  // Clear current question
        
        add(timerText); // adds the timer back.
        numQuestionText.setText("Questions remaining: " + questionsRemaining);
        add(numQuestionText);
        questionsRemaining --;

        // Get the current question
        if (currentQuestionIndex >= 0 && currentQuestionIndex < questions.size()) {
            Map<String, Object> currentQuestion = questions.get(currentQuestionIndex);

            // Check if the current question has the necessary keys
            String questionText = (String) currentQuestion.get("questionText");
            String type = (String) currentQuestion.get("type");

            // Add the question text if it's available
            if (questionText != null) {
                add(new Text("\nQuestion: " + questionText));
            } else {
                add(new Text("Question: No question text available"));
            }

            // Handle question type
            if (type != null) {
                switch (type) {
                    case "true_false":
                        radioGroup = new RadioButtonGroup<>();
                        radioGroup.setItems("True", "False");
                        add(radioGroup);
                        break;

                    case "multiple_choice":
                    	radioGroup = new RadioButtonGroup<>();
                        List<String> options = (List<String>) currentQuestion.get("options");
                        if (options != null && !options.isEmpty()) {
                            radioGroup.setItems(options);
                        } else {
                            radioGroup.setItems("Option 1", "Option 2", "Option 3", "Option 4"); // Default options
                        }
                        add(radioGroup);
                        break;

                    case "short_text":
                        textArea = new TextArea();
                        add(textArea);
                        break;

                    default:
                        add(new TextArea("Unsupported question type"));
                        break;
                }
            } else {
                add(new TextArea("Unknown question type"));
            }

            // Add navigation buttons (Previous, Next, Submit)
            prevButton = new Button("Previous", event -> {
                saveAnswer();
                if (currentQuestionIndex > 0) {
                	questionsRemaining +=2; // displayCurrentQuestion automatically adds 1, but we are going to the previous question, so the total should be -1.
                    currentQuestionIndex--;
                    displayCurrentQuestion();
                }
            });
            add(prevButton);

            if (currentQuestionIndex == questions.size() - 1) {
                submitButton = new Button("Submit", event -> autoSubmit(gStudentID));
                add(submitButton);
            } else {
                nextButton = new Button("Next", event -> {
                    saveAnswer();
                    if (currentQuestionIndex < questions.size() - 1) {
                        currentQuestionIndex++;
                        displayCurrentQuestion();
                    }
                });
                add(nextButton);
            }

            // Enable/Disable Prev/Next buttons based on the index
            prevButton.setEnabled(currentQuestionIndex > 0);
            nextButton.setEnabled(currentQuestionIndex < questions.size() - 1);
        } else {
            // Handle case where no questions are available or index is out of bounds
            add(new TextArea("No questions available"));
        }
    }

    private void startTimer(double timeLimitInMinutes) {
        long endTime = System.currentTimeMillis() + (long)(timeLimitInMinutes * 60 * 1000);

        // Capture the UI instance to use inside the background thread
        UI ui = UI.getCurrent();

        timerThread = new Thread(() -> {
            while (System.currentTimeMillis() < endTime && !examSubmitted) {
                long remainingTime = endTime - System.currentTimeMillis();
                long minutes = (remainingTime / 1000) / 60;
                long seconds = (remainingTime / 1000) % 60;

                // Use the captured UI instance to safely update the UI
                ui.access(() -> {
                    timerText.setText("Time left: " + minutes + "m " + seconds + "s");
                });

                try {
                    Thread.sleep(1000);  // Sleep for 1 second
                } catch (InterruptedException e) {
                    // Timer was interrupted, exit the loop
                    break;
                }
            }

            if (!examSubmitted) {  // If time runs out and exam not submitted yet
                // Use the captured UI instance to safely call autoSubmit
            	System.out.println(gStudentID);
            	ui.access(() -> autoSubmit(gStudentID));  // Pass studentID when auto-submitting
            }
        });
        timerThread.start();
    }
    
    
	private void saveAnswer() {
        Map<String, Object> currentQuestion = questions.get(currentQuestionIndex);
        String type = (String) currentQuestion.get("type");
        if (type.equals("true_false") || type.equals("multiple_choice")) {
            studentAnswers[currentQuestionIndex] = radioGroup.getValue();
        } else if (type.equals("short_text")) {
            studentAnswers[currentQuestionIndex] = textArea.getValue();
        }
        else {
        	System.out.println("Invalid type.");
        }
    }
	
	// Parse the memo to extract correct answers and marks
	private void parseMemo(String examTitle) {
	    String memoFilePath = "exam_memos/" + examTitle + "_MEMO.txt";
	    try {
	        List<String> lines = Files.readAllLines(Paths.get(memoFilePath));
	        
	        String currentQuestion = "";
	        for (int i = 0; i < lines.size(); i++) {
	            String line = lines.get(i).trim();
	            
	            if (line.startsWith("Question:")) {
	                currentQuestion = line.split(": ", 2)[1].trim();
	                memoData.put(currentQuestion, new HashMap<String, Object>());
	            } 
	            else if (line.startsWith("Correct Answer:")) {
	                Map<String, Object> questionData = (Map<String, Object>) memoData.get(currentQuestion);
	                questionData.put("correctAnswer", line.split(": ", 2)[1].trim());
	            } 
	            else if (line.startsWith("Correct Answers:")) {
	                Map<String, Object> questionData = (Map<String, Object>) memoData.get(currentQuestion);
	                List<Map<String, Object>> correctAnswers = new ArrayList<>();  // Re-initialize for each question

	                // Extract multiple correct answers
	                for (int j = i + 1; j < lines.size() && lines.get(j).startsWith(" - "); j++) {
	                    String answerLine = lines.get(j).split(" - ")[1].trim();
	                    String answer = answerLine.split(" \\(Marks:")[0].trim();  // Get the answer
	                    double marks = Double.parseDouble(answerLine.split("Marks: ")[1].replace(")", "").trim());  // Get the marks

	                    Map<String, Object> answerWithMarks = new HashMap<>();
	                    answerWithMarks.put("answer", answer);
	                    answerWithMarks.put("marks", marks);
	                    correctAnswers.add(answerWithMarks);  // Add the answer and marks to the list

	                    i = j;  // Move the outer loop's index to the current line in the inner loop
	                }

	                questionData.put("correctAnswers", correctAnswers);  // Store in memoData for the current question
	            }
	        }
	    } catch (IOException e) {
	        e.printStackTrace();
	        Notification.show("Error reading memo file!", 3000, Notification.Position.MIDDLE);
	    }
	}
	
	private void gradeExam() {
	    studentMarks = 0.0;

	    for (int i = 0; i < questions.size(); i++) {
	        Map<String, Object> currentQuestion = questions.get(i);
	        String questionText = (String) currentQuestion.get("questionText");
	        String studentAnswer = studentAnswers[i];

	        Map<String, Object> memoQuestionData = (Map<String, Object>) memoData.get(questionText);

	        if (memoQuestionData != null) {
	            Double marks = (Double) currentQuestion.get("marks"); // Get marks from the exam question

	            if (marks != null) {
	                totalMarks += marks;

	                if (studentAnswer != null) {
	                    if (currentQuestion.get("type").equals("short_text")) {
	                        // Handle grading of short text answers directly
	                        List<Map<String, Object>> correctAnswers = (List<Map<String, Object>>) memoQuestionData.get("correctAnswers");

	                        if (correctAnswers != null) {
	                            boolean answerMatched = false;

	                            for (Map<String, Object> correctAnswerData : correctAnswers) {
	                                String correctAnswer = (String) correctAnswerData.get("answer");
	                                Double correctMarks = (Double) correctAnswerData.get("marks");

	                                if (correctAnswer.equalsIgnoreCase(studentAnswer)) {
	                                    studentMarks += correctMarks; // Add the corresponding marks
	                                    answerMatched = true;
	                                    break; // Once matched, stop checking further
	                                }
	                            }

	                            if (!answerMatched) {
	                                System.out.println("No matching correct answer found.");
	                                System.out.println("Student Answer: " + studentAnswer);
	                            }
	                        } else {
	                            System.out.println("No correct answers found for this question.");
	                        }
	                    } else if (currentQuestion.get("type").equals("multiple_choice") || currentQuestion.get("type").equals("true_false")) {
	                        // For True/False and Multiple Choice: if the student's answer matches the correct one, award full marks
	                        String correctAnswer = (String) memoQuestionData.get("correctAnswer");
	                        if (studentAnswer.equalsIgnoreCase(correctAnswer)) {
	                            studentMarks += marks;
	                        }
	                    }
	                }
	            } else {
	                System.out.println("Marks not found for question: " + questionText);
	            }
	        } else {
	            System.out.println("No memo data found for question: " + questionText);
	        }
	    }

	    // Calculate and display student's total marks
	    System.out.println("Student's total marks: " + studentMarks);
	    double percentage = (studentMarks / totalMarks) * 100;
	    System.out.println("Percent: " + percentage);
	    
	}



	private void autoSubmit(String studentID) {
	    saveAnswer();  // Save the last answer.

	    // Check if the timer thread is alive and stop it
	    if (timerThread != null && timerThread.isAlive()) {
	        examSubmitted = true;  // Set exam submitted flag
	        timerThread.interrupt();  // Interrupt the timer thread
	    }

	    // Schedule this block in the UI thread using access method
	    UI.getCurrent().access(() -> {
	        // Show a notification that the exam is submitted
	        Notification.show("Exam submitted!", 3000, Notification.Position.MIDDLE);

	        // Parse the memo and grade the exam
	        parseMemo(examTitle);
	        gradeExam();

	        // If studentID is available, save the marked exam
	        if (studentID != null) {
	            LocalDate dateTaken = LocalDate.now();  // Get the current date
	            String markedFileName = "student_files/" + studentID + "/" + examTitle + "_marked.txt";
	            writeMarkedExamToFile(markedFileName, dateTaken, studentID);  // Save the marked exam
	        }

	        // Navigate back to the student dashboard safely in the UI thread
	        removeAll();
	        getUI().ifPresent(ui -> ui.navigate("login"));
	    });
	}





    
	private void writeMarkedExamToFile(String filePath, LocalDate dateTaken, String studentID) {
	    try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
	        writer.write("Exam Title: " + examTitle + "\n");
	        writer.write("Date Taken: " + dateTaken + "\n");
	        writer.write("Student ID: " + studentID + "\n\n");

	        double studentMarks = 0.0;  // Initialize student marks
	        double totalMarks = 0.0;    // Initialize total possible marks
	        
	        // Loop through each question and write the details
	        for (int i = 0; i < questions.size(); i++) {
	            Map<String, Object> currentQuestion = questions.get(i);
	            String questionText = (String) currentQuestion.get("questionText");
	            String studentAnswer = studentAnswers[i];
	            Map<String, Object> memoQuestionData = (Map<String, Object>) memoData.get(questionText);

	            writer.write("Question: " + questionText + "\n");
	            writer.write("Student Answer: " + studentAnswer + "\n");

	            Double marks = (Double) currentQuestion.get("marks");  // Total possible marks for the question
	            totalMarks += marks;  // Increment total possible marks

	            if (memoQuestionData != null) {
	                if (currentQuestion.get("type").equals("short_text")) {
	                    // Handle short text answers
	                    List<Map<String, Object>> correctAnswers = (List<Map<String, Object>>) memoQuestionData.get("correctAnswers");
	                    writer.write("Correct Answers: ");
	                    Double awardedMarks = 0.0;  // Default to 0 marks

	                    for (Map<String, Object> correctAnswerData : correctAnswers) {
	                        writer.write((String) correctAnswerData.get("answer") + " (Marks: " + correctAnswerData.get("marks") + "), ");
	                        // Award marks if the student's answer matches the correct one
	                        if (studentAnswer.equals((String) correctAnswerData.get("answer"))) { // not equalsIgnoreCase  as for many tests, the punctuation gives marks, too. So, they have to punctuate it CORRECTLY.
	                            awardedMarks = (Double) correctAnswerData.get("marks");
	                        }
	                    }

	                    // Add awarded marks to studentMarks
	                    studentMarks += awardedMarks;

	                    // Write the awarded marks and total possible marks
	                    writer.write("\nMarks: " + awardedMarks + "/" + marks + "\n\n");

	                } else {
	                    // Handle True/False and Multiple Choice
	                    String correctAnswer = (String) memoQuestionData.get("correctAnswer");

	                    writer.write("Correct Answer: " + correctAnswer + "\n");

	                    // Compare student's answer to the correct answer and award marks
	                    Double awardedMarks = studentAnswer.equalsIgnoreCase(correctAnswer) ? marks : 0.0;
	                    studentMarks += awardedMarks;  // Add awarded marks to student total

	                    // Write the awarded marks and total possible marks
	                    writer.write("Marks: " + awardedMarks + "/" + marks + "\n\n");
	                }
	            } else {
	                writer.write("Marks: 0/" + marks + "\n\n");  // No memo data available
	            }
	        }

	        // Write total marks and percentage
	        writer.write("Total Marks: " + studentMarks + "/" + totalMarks + "\n");
	        double percentage = (studentMarks / totalMarks) * 100;
	        writer.write("Percentage: " + percentage + "%\n");

	    } catch (IOException e) {
	        e.printStackTrace();
	        Notification.show("Error writing marked exam file!", 3000, Notification.Position.MIDDLE);
	    }
	}

    

    
    
}
