package com.example.application.views;

import com.vaadin.flow.component.Text;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.TextArea;
import com.vaadin.flow.router.BeforeEnterEvent;
import com.vaadin.flow.router.BeforeEnterObserver;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.server.VaadinService;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Route("manage-exams")
public class ManageExamsView extends VerticalLayout implements BeforeEnterObserver {
	
	private String studentID;
	private int currentQuestionIndex = 0;
	private List<QuestionReview> questionsToCheck = new ArrayList<>();
	private double totalMarks =0;
	private double totalSMarks =0;
	private double totalStudentMarks =0;
	
	public ManageExamsView() {
        // Button to go back to Teacher View
        Button backButton = new Button("Back to Teacher View", event -> {
            getUI().ifPresent(ui -> ui.navigate("teacher"));
        });
        add(backButton);

        // Fetch and display disputed exams
        displayDisputedExams();
    }

    public void beforeEnter(BeforeEnterEvent event) {
        // Check if user is logged in as a teacher
        String role = (String) VaadinService.getCurrentRequest().getWrappedSession().getAttribute("role");
        if (role == null || !role.equals("T")) {
            // Redirect to login if not authorized
            Notification.show("Unauthorized Access", 3000, Notification.Position.MIDDLE);
            event.forwardTo("login");
        }
    }
    private void displayDisputedExams() {
        String disputedFolderPath = "disputed_exams";
        String teacherID = (String) VaadinService.getCurrentRequest().getWrappedSession().getAttribute("userID");  // Assuming teacherID is stored in session
        LocalDate teacherRegistrationDate = getTeacherRegistrationDate(teacherID);  // Get teacher's registration date
        
        // Handle case where teacherRegistrationDate is null
        if (teacherRegistrationDate == null) {
            Notification.show("Teacher not logged in. Redirecting to login.", 3000, Notification.Position.MIDDLE);
            getUI().ifPresent(ui -> ui.navigate("login"));  // Redirect to login if teacher registration date is null
            return;
        }

        File disputedFolder = new File(disputedFolderPath);
        if (!disputedFolder.exists() || !disputedFolder.isDirectory()) {
            add(new Text("No disputed exams found."));
            return;
        }

        // Fetch all files in the disputed_exams folder
        File[] files = disputedFolder.listFiles();
        if (files != null && files.length > 0) {
            for (File file : files) {
                String fileName = file.getName();

                // Read the exam's Date Taken from the file
                LocalDate examDateTaken = getExamDateTaken(file);
                
                // Compare dates: only show exams disputed after the teacher's registration date
                if (examDateTaken != null && examDateTaken.isAfter(teacherRegistrationDate)) {
                    Button examButton = new Button(fileName, event -> checkMarks(fileName));
                    add(examButton);
                }
            }
        } else {
            add(new Text("No disputed exams available."));
        }
    }
    
 // Method to get the teacher's registration date from teachers.txt
    private LocalDate getTeacherRegistrationDate(String teacherID) {
        String teacherFilePath = "teachers.txt";
        try {
            List<String> lines = Files.readAllLines(Paths.get(teacherFilePath));
            for (String line : lines) {
                String[] parts = line.split(",");
                if (parts[0].equals(teacherID)) {
                    return LocalDate.parse(parts[3].trim(), DateTimeFormatter.ofPattern("yyyy-MM-dd"));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
    
 // Method to get the exam's Date Taken from the disputed exam file
    private LocalDate getExamDateTaken(File examFile) {
        try {
            List<String> lines = Files.readAllLines(examFile.toPath());
            for (String line : lines) {
                if (line.startsWith("Date Taken:")) {
                    return LocalDate.parse(line.split(": ", 2)[1].trim(), DateTimeFormatter.ofPattern("yyyy-MM-dd"));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Placeholder for the method that will handle checking marks
    public void checkMarks(String fName) {
        File disputedExamFile = new File("disputed_exams/" + fName);
        currentQuestionIndex = 0;  // Reset index

        try {
            List<String> lines = Files.readAllLines(disputedExamFile.toPath());
            String currentQuestion = "";
            String studentAnswer = "";
            String correctAnswer = "";
            double studentMarks = 0.0;
            double originalMarks = 0.0;
            double possibleMarks = 0.0;

            for (int i = 0; i < lines.size(); i++) {
                String line = lines.get(i).trim();
                
                if (line.startsWith("Student ID:")) {
                    studentID = line.split(": ")[1].trim();  // Save student ID
                }

                if (line.startsWith("Question:")) {
                    currentQuestion = line.split(": ", 2)[1].trim();
                }

                if (line.startsWith("Student Answer:")) {
                    studentAnswer = line.split(": ", 2)[1].trim();
                }
                
                if (line.startsWith("Total Marks:")) {
                    String sMarks = line.split(": ")[1].trim();  
                    String[] marksParts = sMarks.split("/");  
                    totalStudentMarks = Double.parseDouble(marksParts[0]);  
                    totalMarks = Double.parseDouble(marksParts[1]);     
                }

                if (line.startsWith("Correct Answer:") || line.startsWith("Correct Answers:")) {
                    correctAnswer = line.split(": ", 2)[1].trim();  // Store full correct answer line
                }

                if (line.startsWith("Marks:")) {
                    String[] marksData = line.split(": ")[1].trim().split("/");
                    studentMarks = Double.parseDouble(marksData[0]);
                    originalMarks = studentMarks;
                    possibleMarks = Double.parseDouble(marksData[1]);

                    // If student's marks are less than the possible marks, create a QuestionReview object
                    if (studentMarks < possibleMarks) {
                        QuestionReview questionReview = new QuestionReview(currentQuestion, originalMarks, studentMarks, possibleMarks, studentAnswer, correctAnswer);
                        questionsToCheck.add(questionReview);  // Add the object to the list for review
                    }
                }
            }

            // Start reviewing the questions with marks discrepancy
            if (!questionsToCheck.isEmpty()) {
                reviewNextQuestion(fName);
            } else {
                Notification.show("No questions with marks discrepancies.", 3000, Notification.Position.MIDDLE);
                returnTestNoChanges(fName); // in case students dispute exams with full marks, for SOME reason.
            }
        } catch (IOException e) {
            e.printStackTrace();
            Notification.show("Error reading disputed exam file!", 3000, Notification.Position.MIDDLE);
        }
    }

    private void reviewNextQuestion(String fName) {
        if (currentQuestionIndex < questionsToCheck.size()) {
            removeAll();  // Clear previous content

            // Get the current QuestionReview object
            QuestionReview currentReview = questionsToCheck.get(currentQuestionIndex);

            // Display the detailed question, student's answer, correct answer, and marks
            Div questionDiv = new Div();
            questionDiv.setText("Question: " + currentReview.questionText);
            questionDiv.getStyle().set("margin-bottom", "15px");
            add(questionDiv);

            Div studentAnswerDiv = new Div();
            studentAnswerDiv.setText("Student Answer: " + currentReview.studentAnswer);
            studentAnswerDiv.getStyle().set("margin-bottom", "15px");
            add(studentAnswerDiv);

            Div correctAnswerDiv = new Div();
            correctAnswerDiv.setText("Correct Answer: " + currentReview.correctAnswer);
            correctAnswerDiv.getStyle().set("margin-bottom", "15px");
            add(correctAnswerDiv);

            Div marksDiv = new Div();
            marksDiv.setText("Marks: " + currentReview.studentMarks + "/" + currentReview.possibleMarks);
            marksDiv.getStyle().set("margin-bottom", "15px");
            add(marksDiv);

            // Text area to input new marks
            TextArea marksInput = new TextArea("Enter new marks:");
            add(marksInput);

            // Replace marks button
            Button replaceMarksButton = new Button("Replace the Marks", event -> {
                try {
                    double newMarks = Double.parseDouble(marksInput.getValue());

                    // Validate the new marks
                    if (newMarks < 0 || newMarks > currentReview.possibleMarks || newMarks % 0.5 != 0) {
                        Notification.show("Invalid marks. Ensure it's a multiple of 0.5, not negative, and less than or equal to possible marks.", 3000, Notification.Position.MIDDLE);
                    } else {
                    	currentReview.setNewMarks(newMarks);  // Save the new marks in the newMarks field
                        currentQuestionIndex++;
                        reviewNextQuestion(fName);  // Proceed to the next question
                        currentReview.marksChanged = true;  // Mark the question as changed                        
                    }
                } catch (NumberFormatException ex) {
                    Notification.show("Invalid input. Please enter a valid number.", 3000, Notification.Position.MIDDLE);
                }
            });

            // No change button
            Button noChangeButton = new Button("No marks need to be changed", event -> {
                currentQuestionIndex++;
                reviewNextQuestion(fName);  // Proceed to the next question
            });

            add(replaceMarksButton);
            add(noChangeButton);
        } else {
            finalizeMarks(fName);  // No more questions to review
        }
    }

    private void finalizeMarks(String fName) {
        // Calculate the difference and show new marks
        double marksDifference = 0.0;

        // Iterate over QuestionReview objects
        for (QuestionReview questionReview : questionsToCheck) {
            String questionText = questionReview.getQuestionText();
            double originalMarks = questionReview.getOriginalMarks();  // Use originalMarks now

            if (questionReview.isMarksChanged()) {
                double newMarks = questionReview.getNewMarks();
                marksDifference += (newMarks - originalMarks);  // Calculate the difference based on original marks
                System.out.println("Updated Marks for " + questionText + ": " + newMarks);
            }
        }

        // Update total marks and percentage
        double newTotalMarks = totalStudentMarks + marksDifference;
        double newPercentage = (newTotalMarks / totalMarks) * 100;
        totalSMarks = newTotalMarks;
        System.out.println("New Total Marks: " + newTotalMarks);
        System.out.println("New Percentage: " + newPercentage + "%");
        Notification.show("Marks adjusted.", 3000, Notification.Position.MIDDLE);
        returnTest(fName);
    }


    private void returnTest(String fName) {
        // Read the original file and update it with the new marks where applicable
        try {
            List<String> lines = Files.readAllLines(Paths.get("disputed_exams/" + fName));

            // Create a new temporary file to store the updated content
            File tempFile = new File("disputed_exams/" + fName + "_temp");
            BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile));

            String currentQuestion = null;
            for (int i = 0; i < lines.size(); i++) {
                String line = lines.get(i);

                // Check if it's a question line
                if (line.startsWith("Question:")) {
                    currentQuestion = line.split(": ", 2)[1].trim();
                }

                // Check if marks for the current question have been updated
                if (line.startsWith("Marks:") && currentQuestion != null) {
                    boolean marksUpdated = false;
                    for (QuestionReview review : questionsToCheck) {
                        if (review.getQuestionText().equals(currentQuestion) && review.isMarksChanged()) {
                            // Replace the line with the new marks
                            String updatedMarksLine = "Marks: " + review.getNewMarks() + "/" + review.possibleMarks;
                            writer.write(updatedMarksLine);
                            writer.newLine();
                            marksUpdated = true;
                            break;
                        }
                    }
                    // If marks weren't updated, keep the original line
                    if (!marksUpdated) {
                        writer.write(line);
                        writer.newLine();
                    }
                } else {
                    writer.write(line);
                    writer.newLine();
                }
            }

            // Update the last two lines with the new total marks and percentage
            if (lines.size() >= 2) {
                lines.remove(lines.size() - 1); // Remove last line (Checked by teacher or any other text)
                lines.remove(lines.size() - 1); // Remove second last line (Percentage)
                lines.remove(lines.size() - 1); // Remove third last line (Total Marks)
            }

            // Calculate the new total marks and percentage
            double fPercent = (totalSMarks / totalMarks) * 100;
            
            // Write updated total marks and percentage to the file
            writer.write("Updated Total Marks: " + totalSMarks + "/" + totalMarks + "\n");
            writer.write("Updated Percentage: " + fPercent + "%\n");
            writer.write("Checked by teacher\n");

            writer.close();

            // Delete the original file and rename the temp file to the original file
            File originalFile = new File("disputed_exams/" + fName);
            if (originalFile.delete()) {
                tempFile.renameTo(originalFile);
            }

            // Move the file to the student's folder
            File studentFolder = new File("student_files/" + studentID);
            if (!studentFolder.exists()) {
                studentFolder.mkdirs(); // Create directory if it doesn't exist
            }
            File updatedExamFile = new File(studentFolder, fName); // Path to the student's folder
            Files.move(Paths.get("disputed_exams/" + fName), updatedExamFile.toPath());

            // Delete the corresponding notice file
            String noticeFileName = fName.replace("_marked.txt", "_notice.txt");
            File noticeFile = new File("student_files/" + studentID + "/" + noticeFileName);
            if (noticeFile.exists()) {
                noticeFile.delete();
            }

            // Add the finish button
            Button finishButton = new Button("Finish", event -> {
                Notification.show("Test has been successfully updated and returned.", 3000, Notification.Position.MIDDLE);
                getUI().ifPresent(ui -> ui.getPage().reload()); // Navigate back to manage exams
            });

            // Add the finish button to the UI
            add(finishButton);

        } catch (IOException e) {
            e.printStackTrace();
            Notification.show("Error updating the exam file!", 3000, Notification.Position.MIDDLE);
        }
    }
    private void returnTestNoChanges(String fName) {
        try {
            // Path to the original file
            Path filePath = Paths.get("disputed_exams/" + fName);
            
            // Read all lines from the original file
            List<String> lines = Files.readAllLines(filePath);

            // Create a new temporary file to store the updated content
            File tempFile = new File("disputed_exams/" + fName + "_temp");
            BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile));

            // Write the original content back into the new file
            for (String line : lines) {
                writer.write(line);
                writer.newLine();
            }

            // Add the "Checked by teacher" line at the end
            writer.newLine();
            writer.write("Checked by teacher");

            writer.close();

            // Delete the original file and rename the temp file to the original file
            File originalFile = new File("disputed_exams/" + fName);
            if (originalFile.delete()) {
                tempFile.renameTo(originalFile);
            }

            // Move the file to the student's folder
            File studentFolder = new File("student_files/" + studentID);
            if (!studentFolder.exists()) {
                studentFolder.mkdirs(); // Create directory if it doesn't exist
            }
            File updatedExamFile = new File(studentFolder, fName); // Path to the student's folder
            Files.move(Paths.get("disputed_exams/" + fName), updatedExamFile.toPath());

            // Delete the corresponding notice file
            String noticeFileName = fName.replace("_marked.txt", "_notice.txt");
            File noticeFile = new File("student_files/" + studentID + "/" + noticeFileName);
            if (noticeFile.exists()) {
                noticeFile.delete();
            }

            // Add the finish button
            Button finishButton = new Button("Finish", event -> {
                Notification.show("Test has been successfully updated and returned. No marks were changed as they already HAD full marks.", 3000, Notification.Position.MIDDLE);
                getUI().ifPresent(ui -> ui.getPage().reload()); // Navigate back to manage exams
            });

            // Add the finish button to the UI
            add(finishButton);

        } catch (IOException e) {
            e.printStackTrace();
            Notification.show("Error updating the exam file!", 3000, Notification.Position.MIDDLE);
        }
    }



    
 // Create the QuestionReview class to store question information
    public class QuestionReview {
        private String questionText;
        private double originalMarks;  // Add this field to store the original marks
        private double studentMarks;
        private double possibleMarks;
        private String studentAnswer;
        private String correctAnswer;
        private boolean marksChanged = false;
        private double newMarks;  // Add this field to store updated marks

        // Constructor with original marks included
        public QuestionReview(String questionText, double originalMarks, double studentMarks, double possibleMarks, String studentAnswer, String correctAnswer) {
            this.questionText = questionText;
            this.originalMarks = originalMarks;
            this.studentMarks = studentMarks;
            this.possibleMarks = possibleMarks;
            this.studentAnswer = studentAnswer;
            this.correctAnswer = correctAnswer;
        }

        public String getQuestionText() {
			return questionText;
		}

		// Getters and setters for newMarks and other fields
        public double getOriginalMarks() {
            return originalMarks;
        }

        public double getNewMarks() {
            return newMarks;
        }

        public void setNewMarks(double newMarks) {
            this.newMarks = newMarks;
            this.marksChanged = true;
        }

        public boolean isMarksChanged() {
            return marksChanged;
        }
    } 

    

    

}
