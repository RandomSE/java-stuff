package com.example.application.views;

import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.PasswordField;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.server.VaadinService;

@Route("login")
public class LoginView extends VerticalLayout {

    private UserService userService = new UserService();

    public LoginView() {
        TextField userIdField = new TextField("User ID");
        PasswordField passwordField = new PasswordField("Password");

        Button loginButton = new Button("Login", event -> {
            String userId = userIdField.getValue();
            String password = passwordField.getValue();

            if (userService.validateLogin(userId, password, "S")) {
                saveUserInSession(userId, "S");
                UI.getCurrent().navigate("student");
            } else if (userService.validateLogin(userId, password, "T")) {
                saveUserInSession(userId, "T");
                UI.getCurrent().navigate("teacher");
            } else {
                Notification.show("Invalid ID or Password", 3000, Notification.Position.MIDDLE);
            }
        });
        
        Button registerButton = new Button("Register",event ->{
        	UI.getCurrent().navigate("register"); 
        	
        });

        add(userIdField, passwordField, loginButton, registerButton);
    }

    private void saveUserInSession(String userId, String role) {
        // Save the user ID and role in the session
        VaadinService.getCurrentRequest().getWrappedSession().setAttribute("userID", userId);
        VaadinService.getCurrentRequest().getWrappedSession().setAttribute("role", role);
    }
}
