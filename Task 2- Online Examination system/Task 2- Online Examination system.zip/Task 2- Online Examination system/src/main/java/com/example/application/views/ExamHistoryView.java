package com.example.application.views;

import com.vaadin.flow.component.Text;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.BeforeEnterEvent;
import com.vaadin.flow.router.BeforeEnterObserver;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.server.VaadinService;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;

@Route("history")
public class ExamHistoryView extends VerticalLayout implements BeforeEnterObserver {

    public ExamHistoryView() {
        // Button to return to Student View
        Button backButton = new Button("Back to Student View", event -> {
            getUI().ifPresent(ui -> ui.navigate("student"));
        });
        add(backButton);
    }

    @Override
    public void beforeEnter(BeforeEnterEvent event) {
        String studentID = (String) VaadinService.getCurrentRequest().getWrappedSession().getAttribute("userID");

        if (studentID == null) {
            // If the student is not logged in, redirect them to login view
            event.rerouteTo(LoginView.class);
        } else {
            displayMarkedExams(studentID);
        }
    }

    private void displayMarkedExams(String studentID) {
        String studentFolderPath = "student_files/" + studentID;

        File studentFolder = new File(studentFolderPath);
        if (!studentFolder.exists() || !studentFolder.isDirectory()) {
            add(new Text("No exam history found."));
            return;
        }

        File[] files = studentFolder.listFiles((dir, name) -> name.endsWith("_marked.txt"));
        if (files != null && files.length > 0) {
            for (File file : files) {
                String fileName = file.getName().replace("_marked.txt", "");
                Button examButton = new Button(fileName, event -> displayExamContent(fileName));
                add(examButton);
            }
        } else {
            add(new Text("No marked exams found."));
        }
        
        File[] filesN = studentFolder.listFiles((dir, name) -> name.endsWith("_notice.txt"));
        if (filesN != null && filesN.length > 0) {
            for (File file : filesN) {
                String fileName = file.getName().replace("_notice.txt", "");
                Button noticeButton = new Button(fileName+"_notice.txt", event -> displayNotice(fileName));
                add(noticeButton);
            }
        } else {
            add(new Text("No notices found."));
        }
    }


    private void displayExamContent(String fileName) {
        removeAll();  // Clear any previous content

        // Button to go back to History View
        Button backButton = new Button("Back to History View", event -> {
            getUI().ifPresent(ui -> ui.getPage().reload());
        });
        add(backButton);

        // Read the content of the file
        String studentID = (String) VaadinService.getCurrentRequest().getWrappedSession().getAttribute("userID");
        String filePath = "student_files/" + studentID + "/" + fileName + "_marked.txt";  // The full path to the file

        try {
            List<String> lines = Files.readAllLines(Paths.get(filePath));

            VerticalLayout contentLayout = new VerticalLayout();
            contentLayout.setSpacing(true);  // Add spacing between components

            boolean checkedByTeacher = false;

            // Add each line as a separate Div component for better separation
            for (String line : lines) {
                Div lineDiv = new Div();
                lineDiv.setText(line);
                lineDiv.getStyle().set("margin-bottom", "15px");  // Add space between each line
                contentLayout.add(lineDiv);

                // Check if the line contains "Checked by teacher"
                if (line.equalsIgnoreCase("Checked by teacher")) {
                    checkedByTeacher = true;
                }
            }

            add(contentLayout);  // Add the content layout to the view

            // Only show the dispute button if the exam has not been checked by a teacher
            if (!checkedByTeacher) {
                Button disputeButton = new Button("Dispute marking", event -> {
                    disputeMarking(filePath, fileName);
                });
                add(disputeButton);
            } else {
                // Show a notification that the exam has already been confirmed by a teacher
                Notification.show("This exam has already been confirmed by a teacher and cannot be disputed.", 5000, Notification.Position.MIDDLE);
            }

        } catch (IOException e) {
            Notification.show("Error reading exam file!", 3000, Notification.Position.MIDDLE);
        }
    }
    
    private void displayNotice(String fileName) {
    	System.out.println("Semi-success. " +fileName);
    	String studentID = (String) VaadinService.getCurrentRequest().getWrappedSession().getAttribute("userID");
        String sFilePath = "student_files/" + studentID + "/" + fileName + "_notice.txt";  
        Path filePath = Paths.get(sFilePath);
        try {
        	System.out.println("Success.");
        	String sMessage = Files.readString(filePath);
        	 add(new Text(sMessage));
        	
        } catch (IOException e) {
        	Notification.show("Error reading notice file!", 3000, Notification.Position.MIDDLE);
        }
        
    	
    }
    private void disputeMarking(String fPath, String fName) {
    	
    	File disputedExamsFolder = new File("disputed_exams");
        if (!disputedExamsFolder.exists()) {
            disputedExamsFolder.mkdirs();  // Create the folder
        }       
    	// Define the target path inside the "disputed exams" folder
        File sourceFile = new File(fPath);
        String fileName = sourceFile.getName();
        File destinationFile = new File(disputedExamsFolder, fileName);
        try {
            // Copy the file to the destination
            Files.copy(sourceFile.toPath(), destinationFile.toPath(), StandardCopyOption.REPLACE_EXISTING);

            // Check if the file was successfully copied
            if (destinationFile.exists() && Files.size(destinationFile.toPath()) == Files.size(sourceFile.toPath())) {
                // Delete the original file
                if (sourceFile.delete()) {
                    System.out.println("Original file deleted successfully.");

                    // Create the notice file
                    File noticeFile = new File(sourceFile.getParent(), fName + "_notice.txt");
                    try (BufferedWriter writer = new BufferedWriter(new FileWriter(noticeFile))) {
                        writer.write(fName + " has been sent to the teachers to be rechecked for marking, it will be returned once it has been checked.");
                        Notification.show("You have disputed the exam's results.", 3000, Notification.Position.MIDDLE);
                        getUI().ifPresent(ui -> ui.getPage().reload());
                        System.out.println("Notice file created: " + noticeFile.getAbsolutePath());
                    } catch (IOException e) {
                        System.err.println("Error creating notice file: " + e.getMessage());
                    }
                } else {
                    System.err.println("Failed to delete the original file.");
                }
            } else {
                System.err.println("File was not copied successfully.");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

