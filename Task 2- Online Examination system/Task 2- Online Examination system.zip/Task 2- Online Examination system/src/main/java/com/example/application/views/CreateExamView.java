package com.example.application.views;

import com.vaadin.flow.component.Text;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.TextArea;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.component.textfield.NumberField;
import com.vaadin.flow.component.radiobutton.RadioButtonGroup;
import com.vaadin.flow.router.BeforeEnterEvent;
import com.vaadin.flow.router.BeforeEnterObserver;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.server.VaadinService;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;
import java.util.Map;

@Route("create-exam")
public class CreateExamView extends VerticalLayout implements BeforeEnterObserver {

    private TextField examTitle;
    private NumberField timeLimit;
    private NumberField totalMarks;
    private TextArea notes;
    private List<Question> questions;
    private double accumulatedMarks = 0.0;
    private NumberField questionMarks;
    private TextField questionText;
    private Button finalizeExamButton;
    private Button startQuestionButton;
    private RadioButtonGroup<String> answerTypeGroup;
    private Map<String, List<String>> correctAnswersMap = new HashMap<>();
    private int currentQuestionIndex = 0; 
    private Map<String, List<String>> questionOptionsMap = new HashMap<>();
    private List<String> teacherAnswers = new ArrayList<>();  // List to store the teacher's answers
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    private Map<String, List<Double>> answerMarksMap = new HashMap<>();  // Correct the type to store a list of marks per question



    public CreateExamView() {
        questions = new ArrayList<>();

        // Input fields for the exam details
        examTitle = new TextField("Exam Title");
        timeLimit = new NumberField("Time Limit (in minutes)");
        totalMarks = new NumberField("Total Marks");
        notes = new TextArea("Notes / Instructions");

        add(examTitle, timeLimit, totalMarks, notes);

        // Button to confirm exam details and start question-adding loop
        startQuestionButton = new Button("Start Adding Questions", event -> showQuestionSection());
        add(startQuestionButton);

        // Initial UI won't show the question creation part until this button is clicked
    }
    
 // Method to display the question creation interface after exam details are entered
    private void showQuestionSection() {
        startQuestionButton.setEnabled(false);

        questionText = new TextField("Question Text");

        // Dropdown for selecting the answer type
        answerTypeGroup = new RadioButtonGroup<>();
        answerTypeGroup.setLabel("Answer Type");
        answerTypeGroup.setItems("True/False", "Multiple Choice", "Short Text Answer");

        questionMarks = new NumberField("Marks Allocated");

        Button addQuestionButton = new Button("Add Question", event -> addQuestion());
        finalizeExamButton = new Button("Finalize Exam", event -> finalizeExam());
        finalizeExamButton.setEnabled(false); // Disable until total marks reached

        add(questionText, answerTypeGroup, questionMarks, addQuestionButton, finalizeExamButton);

        // Add listeners to dynamically show options for Multiple Choice
        answerTypeGroup.addValueChangeListener(event -> {
            removeAll(); // Clear current components
            add(questionText, answerTypeGroup, questionMarks, addQuestionButton, finalizeExamButton);

            if ("Multiple Choice".equals(event.getValue())) {
                TextField option1 = new TextField("Option 1");
                TextField option2 = new TextField("Option 2");
                TextField option3 = new TextField("Option 3");
                TextField option4 = new TextField("Option 4");

                add(option1, option2, option3, option4);

                addQuestionButton.addClickListener(click -> {
                    // Ensure options are not empty
                    if (option1.getValue().isEmpty() || option2.getValue().isEmpty() || option3.getValue().isEmpty() || option4.getValue().isEmpty()) {
                        Notification.show("Please fill all option fields", 3000, Notification.Position.MIDDLE);
                        return;
                    }

                    // Store the options based on the question text (or unique question ID)
                    List<String> options = List.of(
                        option1.getValue(),
                        option2.getValue(),
                        option3.getValue(),
                        option4.getValue()
                    );

                    questionOptionsMap.put(questionText.getValue(), options);  // Link options to question text
                });
            }
        });
    }

 // addQuestion method, to add questions.
    private void addQuestion() {
        String question = questionText.getValue();
        String type = answerTypeGroup.getValue();
        
        // Add null check for questionMarks
        Double marks = questionMarks.getValue();
        if (marks < 0 ||  marks % 0.5 != 0){ // no need for a null check here; Won't work as null isn't divisible by 0.5
            Notification.show("Please allocate an appropriate amount of marks for this question.", 3000, Notification.Position.MIDDLE);
            return;  // Stop execution if marks are not provided
        }

        List<String> options = new ArrayList<>();

        // If it's a multiple-choice question, retrieve options linked to the question text
        if ("Multiple Choice".equals(type)) {
        	options = questionOptionsMap.get(question);  // Retrieve by question text
            if (options == null || options.isEmpty()) {
                Notification.show("Please provide options for the multiple choice question. If you already have, click Add Question again.", 3000, Notification.Position.MIDDLE);
                return;  // Stop if options aren't properly set
            }
        }

        // Ensure the added marks do not exceed total marks
        if (accumulatedMarks + marks <= totalMarks.getValue()) {
            questions.add(new Question(question, type, marks, options));
            accumulatedMarks += marks;
            Notification.show("Question added. Total Marks: " + accumulatedMarks + "/" + totalMarks.getValue(), 3000, Notification.Position.MIDDLE);
        } else {
            Notification.show("Cannot exceed the total marks! You have " + (totalMarks.getValue() - accumulatedMarks) + " marks left.", 3000, Notification.Position.MIDDLE);
        }

        // Clear inputs for the next question
        questionText.clear();
        answerTypeGroup.clear();
        questionMarks.clear();

        // Check if total marks have been reached
        if (accumulatedMarks >= totalMarks.getValue()) {
            finalizeExamButton.setEnabled(true); // Enable exam finalization
        }
    }

    // Finalize the exam creation process
    private void finalizeExam() {
        Notification.show("Exam created successfully!", 3000, Notification.Position.MIDDLE);
        
        // Call the memo creation process after the exam is finalized
        createMemo();
    }
    
    private void createMemo() {
        // Clear the view and start memo creation for the first question
        removeAll();
        Notification.show("Creating memo. Please answer each question.", 3000, Notification.Position.MIDDLE);
        
        showQuestionMemo(questions.get(currentQuestionIndex));
    }
    
    private void showQuestionMemo(Question question) {
        removeAll(); // Clear existing components
        
        switch (question.getAnswerType()) {
            case "True/False":
                createTrueFalseMemo(question);
                break;
            case "Multiple Choice":
                createMultipleChoiceMemo(question);
                break;
            case "Short Text Answer":
                createShortTextMemo(question);
                break;
        }
        
        // Add navigation buttons
        Button prevButton = new Button("Previous", event -> showPreviousQuestion());
        Button nextButton = new Button("Next", event -> showNextQuestion());

        add(prevButton, nextButton);
        
        // Disable "Previous" button if on the first question
        prevButton.setEnabled(currentQuestionIndex > 0);
        
        // Update "Next" button text based on whether it's the last question
        if (currentQuestionIndex < questions.size() - 1) {
            nextButton.setText("Next");
        } else {
            nextButton.setText("Finalize Memo");
        }
    }
    
    private void showPreviousQuestion() {
        if (currentQuestionIndex > 0) {
            currentQuestionIndex--;
            showQuestionMemo(questions.get(currentQuestionIndex));
        }
    }
    
    private void showNextQuestion() {
        if (currentQuestionIndex < questions.size() - 1) {
            currentQuestionIndex++;
            showQuestionMemo(questions.get(currentQuestionIndex));
        } else {
            testTeacherOnExam();
        }
    }
    
 // After finalizing the memo, prompt the teacher to take the test
    private void testTeacherOnExam() {
        currentQuestionIndex = 0; // Reset index
        teacherAnswers.clear();   // Clear any previous answers
        removeAll();              // Clear the view

        Notification.show("Please take the test you created.", 3000, Notification.Position.MIDDLE);
        showTestQuestion(questions.get(currentQuestionIndex)); // Start with the first question
    }
    
 // Display each test question for the teacher to answer
    private void showTestQuestion(Question question) {
        removeAll();  // Clear current components

        add(new Text("Question: " + question.getText()));  // Display the question text
        add(new Text("Marks: " + question.getMarks()));    // Show the marks

        // Render input fields based on the question type
        if ("True/False".equals(question.getAnswerType())) {
            RadioButtonGroup<String> trueFalseGroup = new RadioButtonGroup<>();
            trueFalseGroup.setItems("True", "False");
            trueFalseGroup.setLabel("Select your answer");
            add(trueFalseGroup);

            Button nextButton = new Button("Next", event -> {
                teacherAnswers.add(trueFalseGroup.getValue());
                showNextTestQuestion();
            });
            add(nextButton);

        } else if ("Multiple Choice".equals(question.getAnswerType())) {
            RadioButtonGroup<String> multipleChoiceGroup = new RadioButtonGroup<>();
            multipleChoiceGroup.setItems(questionOptionsMap.get(question.getText())); // Load the multiple-choice options
            multipleChoiceGroup.setLabel("Select your answer");
            add(multipleChoiceGroup);

            Button nextButton = new Button("Next", event -> {
                teacherAnswers.add(multipleChoiceGroup.getValue());
                showNextTestQuestion();
            });
            add(nextButton);

        } else if ("Short Text Answer".equals(question.getAnswerType())) {
            TextArea shortAnswerField = new TextArea("Enter your answer");
            add(shortAnswerField);

            Button nextButton = new Button("Next", event -> {
                teacherAnswers.add(shortAnswerField.getValue());
                showNextTestQuestion();
            });
            add(nextButton);
        }
    }
    
 // Handle the navigation to the next test question or evaluate after the last question
    private void showNextTestQuestion() {
        currentQuestionIndex++;
        if (currentQuestionIndex < questions.size()) {
            showTestQuestion(questions.get(currentQuestionIndex));
        } else {
            evaluateTeacherTest();
        }
    }
    
 // Evaluate the teacher's answers after the test
    private void evaluateTeacherTest() {
        int totalMarks = questions.stream().mapToInt(q -> (int) q.getMarks()).sum();
        int marksEarned = 0;

        for (int i = 0; i < questions.size(); i++) {
            Question question = questions.get(i);
            String teacherAnswer = teacherAnswers.get(i);

            List<String> correctAnswers = correctAnswersMap.get(question.getText());
            if (correctAnswers != null && correctAnswers.contains(teacherAnswer)) {
                marksEarned += question.getMarks();  // Add marks if the answer is correct
            }
        }

        double scorePercentage = ((double) marksEarned / totalMarks) * 100;
        if (scorePercentage >= 90) {
            Notification.show("You passed the test! Score: " + scorePercentage + "%", 3000, Notification.Position.MIDDLE);
            showPostTestButton();
        } else {
            Notification.show("You scored " + scorePercentage + "%. Please remake the memo or the test.", 3000, Notification.Position.MIDDLE);
            showRemakeOptions();
        }
    }
    
 // Show options to remake the memo or remake the test
    private void showRemakeOptions() {
        removeAll(); // Clear current components
        
        // Button to remake the memo
        Button remakeMemoButton = new Button("Remake Memo", event -> {
            currentQuestionIndex = 0; // Reset to the first question
            correctAnswersMap.clear(); // Clear the previous memo answers
            createMemo(); // Restart memo creation
        });

        // Button to remake the test (simply refreshes the page)
        Button remakeTestButton = new Button("Remake Test", event -> {
            getUI().ifPresent(ui -> ui.getPage().reload()); // Refresh the page to restart the test
        });

        add(remakeMemoButton, remakeTestButton);
    }
    
 // Show the button to post the test if the teacher scores 90%+
    private void showPostTestButton() {
        Button postTestButton = new Button("Post Test", event -> {
            saveExamAndMemo();
            Notification.show("Test posted successfully!", 3000, Notification.Position.MIDDLE);
        });
        add(postTestButton);
    }
    
 // Modified createTrueFalseMemo to store correct answers
    private void createTrueFalseMemo(Question question) {
    	add(new Text("Question: " + question.getText()));  // Display question
        
        RadioButtonGroup<String> trueFalseGroup = new RadioButtonGroup<>();
        trueFalseGroup.setItems("True", "False");
        trueFalseGroup.setLabel("Select the correct answer");

        // Store correct answer after selection
        trueFalseGroup.addValueChangeListener(event -> {
            List<String> correctAnswers = new ArrayList<>();
            correctAnswers.add(event.getValue()); // Store "True" or "False"
            correctAnswersMap.put(question.getText(), correctAnswers);
        });

        add(trueFalseGroup); // Add only the radio buttons for True/False questions
    }
    
    private void createMultipleChoiceMemo(Question question) {
    	add(new Text("Question: " + question.getText()));  // Display question  // Display question

        // Create a layout to hold the options and radio buttons
        VerticalLayout multipleChoiceLayout = new VerticalLayout();

        // Retrieve options from the Question object (which now holds the options)
        List<String> options = question.getOptions();
        
        if (options != null && !options.isEmpty()) {
            RadioButtonGroup<String> correctChoice = new RadioButtonGroup<>();
            correctChoice.setLabel(" Select the correct answer");
            correctChoice.setItems(options);  // Set the options from the Question object

            // Store the selected correct answer
            correctChoice.addValueChangeListener(event -> {
                List<String> correctAnswers = new ArrayList<>();
                correctAnswers.add(event.getValue());  // Store the selected correct answer
                correctAnswersMap.put(question.getText(), correctAnswers);  // Map question text to the selected correct answer
            });

            multipleChoiceLayout.add(correctChoice);
        } else {
            add(new Text("No options available for this question."));
        }

        add(multipleChoiceLayout);
    }

    
 
    
 // Modify createShortTextMemo to store multiple correct answers
    private void createShortTextMemo(Question question) {
        add(new Text("Question: " + question.getText()));  // Display question

        // Display total possible marks for the question
        Text totalMarksText = new Text("Total possible marks for the question: " + question.getMarks());
        
        // Field for acceptable answers and marks allocation
        TextArea acceptableAnswer = new TextArea("Enter acceptable answer");
        NumberField answerMarks = new NumberField("Marks for this answer");
        
        // Marks validation rules
        answerMarks.setMin(0);  // Marks cannot be negative
        answerMarks.setStep(0.5);  // Marks must be in multiples of 0.5

        // Button to add more acceptable answers
        Button addAnswerButton = new Button("Add another answer", event -> {
            TextArea newAnswer = new TextArea("Enter another acceptable answer");
            NumberField newAnswerMarks = new NumberField("Marks for this answer");
            newAnswerMarks.setMin(0);
            newAnswerMarks.setStep(0.5);

            add(newAnswer, newAnswerMarks);

            // Validate and store new answers with their marks
            newAnswer.addValueChangeListener(e -> {
                List<String> correctAnswers = correctAnswersMap.getOrDefault(question.getText(), new ArrayList<>());
                correctAnswers.add(e.getValue());
                correctAnswersMap.put(question.getText(), correctAnswers);
            });

            newAnswerMarks.addValueChangeListener(e -> {
                if (isValidMark(newAnswerMarks.getValue(), question.getMarks())) {
                    List<Double> marksList = answerMarksMap.getOrDefault(question.getText(), new ArrayList<>());
                    marksList.add(newAnswerMarks.getValue());  // Store the marks for the corresponding answer
                    answerMarksMap.put(question.getText(), marksList);  // Save the updated marks list
                } else {
                    newAnswerMarks.clear();  // Clear invalid marks entry
                    Notification.show("Invalid mark. Must be non-negative, a multiple of 0.5, and ≤ " + question.getMarks());
                }
            });
        });

        // Validate and store the first acceptable answer and its marks
        acceptableAnswer.addValueChangeListener(e -> {
            List<String> correctAnswers = correctAnswersMap.getOrDefault(question.getText(), new ArrayList<>());
            correctAnswers.add(e.getValue());
            correctAnswersMap.put(question.getText(), correctAnswers);
        });

        answerMarks.addValueChangeListener(e -> {
            if (isValidMark(answerMarks.getValue(), question.getMarks())) {
                List<Double> marksList = answerMarksMap.getOrDefault(question.getText(), new ArrayList<>());
                marksList.add(answerMarks.getValue());  // Store the marks for the first answer
                answerMarksMap.put(question.getText(), marksList);  // Save the updated marks list
            } else {
                answerMarks.clear();  // Clear invalid marks entry
                Notification.show("Invalid mark. Must be non-negative, a multiple of 0.5, and ≤ " + question.getMarks());
            }
        });

        add(totalMarksText, acceptableAnswer, answerMarks, addAnswerButton);
    }

    private boolean isValidMark(Double mark, Double maxMarks) {
        // Check if the mark is non-negative, a multiple of 0.5, and within the total marks
        return mark != null && mark >= 0 && (mark * 2) % 1 == 0 && mark <= maxMarks;
    }


    // Save exam and memo after test
    private void saveExamAndMemo() {
        String examTitleValue = examTitle.getValue();

        // Ensure unique file name for exam
        String examFileName = checkForDuplicate(examTitleValue, "exams") ? examTitleValue + "_" + LocalDate.now() : examTitleValue;

        // Save exam details
        saveToFile("exams/" + examFileName + ".txt", formatExamDetails());
        
        // Save memo details
        saveToFile("exam_memos/" + examFileName + "_MEMO.txt", formatMemoDetails());

        Notification.show("Exam and memo saved successfully!", 3000, Notification.Position.MIDDLE);
        getUI().ifPresent(ui -> ui.navigate("teacher"));
    }

    private String formatExamDetails() {
        // Format the exam details to be saved
        StringBuilder examContent = new StringBuilder();
        examContent.append("Exam Title: ").append(examTitle.getValue()).append("\n");
        examContent.append("Time Limit: ").append(timeLimit.getValue()).append(" minutes\n");
        String creationDate = LocalDate.now().format(DATE_FORMATTER);
        examContent.append("Exam Creation Date: ").append(creationDate).append("\n");
        examContent.append("Total Marks: ").append(totalMarks.getValue()).append("\n");
        examContent.append("Notes/Instructions: ").append(notes.getValue()).append("\n\n");

        for (Question question : questions) {
            examContent.append("Question: ").append(question.getText()).append("\n");
            examContent.append("Answer Type: ").append(question.getAnswerType()).append("\n");
            examContent.append("Marks: ").append(question.getMarks()).append("\n");

            // If the question is multiple-choice, include possible answers
            if ("Multiple Choice".equals(question.getAnswerType())) {
                examContent.append("Possible Answers:\n");
                List<String> options = question.getOptions();
                if (options != null && !options.isEmpty()) {
                    for (int i = 0; i < options.size(); i++) {
                        examContent.append("  Option ").append(i + 1).append(": ").append(options.get(i)).append("\n");
                    }
                }
            }

            examContent.append("\n");  // Add extra line for spacing
        }

        return examContent.toString();
    }

    private String formatMemoDetails() {
        // Format the memo details to be saved
        StringBuilder memoContent = new StringBuilder();
        
        for (Question question : questions) {
            memoContent.append("Question: ").append(question.getText()).append("\n");
            
            if (question.getAnswerType().equals("Short Text Answer")) {
                // Handle multiple correct answers for short text questions
                List<String> correctAnswers = correctAnswersMap.get(question.getText());
                List<Double> answerMarks = answerMarksMap.get(question.getText());
                
                if (correctAnswers != null && !correctAnswers.isEmpty() && answerMarks != null) {
                    memoContent.append("Correct Answers: \n");
                    for (int i = 0; i < correctAnswers.size(); i++) {
                        String answer = correctAnswers.get(i);
                        double marks = i < answerMarks.size() ? answerMarks.get(i) : 0.0;  // Retrieve marks for each answer
                        memoContent.append(" - ").append(answer).append(" (Marks: ").append(marks).append(")\n");
                    }
                } else {
                    memoContent.append("No correct answers provided.\n");
                }
            } else {
                // For other question types, use the general correct answer logic
                memoContent.append("Correct Answer: ").append(getCorrectAnswerForQuestion(question)).append("\n");
            }
            
            memoContent.append("\n");
        }

        return memoContent.toString();
    }
    
    private void saveToFile(String fileName, String content) {
        try {
            Files.write(Paths.get(fileName), content.getBytes());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private boolean checkForDuplicate(String title, String folder) {
        // Check if the exam title already exists in the specified folder
        File examFolder = new File(folder);
        File[] listOfFiles = examFolder.listFiles();
        
        if (listOfFiles != null) {
            for (File file : listOfFiles) {
                if (file.getName().equalsIgnoreCase(title + ".txt")) {
                    return true;
                }
            }
        }
        return false;
    }

    private String getCorrectAnswerForQuestion(Question question) {
        List<String> correctAnswers = correctAnswersMap.get(question.getText());
        return correctAnswers != null ? String.join(", ", correctAnswers) : "No correct answer saved";
    }

    @Override
    public void beforeEnter(BeforeEnterEvent event) {
        // Check if user is logged in as a teacher
        String role = (String) VaadinService.getCurrentRequest().getWrappedSession().getAttribute("role");
        if (role == null || !role.equals("T")) {
            // Redirect to login if not authorized
            event.forwardTo("login");
        }
    }

    // Question class to store details of each question
    public static class Question {
        private String text;
        private String answerType;
        private double marks;
        private List<String> options;  // Store the options for multiple-choice questions

        public Question(String text, String answerType, double marks, List<String> options) {
            this.text = text;
            this.answerType = answerType;
            this.marks = marks;
            this.options = options;
        }

        public String getText() {
            return text;
        }

        public String getAnswerType() {
            return answerType;
        }

        public double getMarks() {
            return marks;
        }

        public List<String> getOptions() {
            return options;  // Getter for multiple-choice options
        }
    }
}

