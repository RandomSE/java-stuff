package com.example.application.views;

import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.router.BeforeEnterEvent;
import com.vaadin.flow.router.BeforeEnterObserver;
import com.vaadin.flow.router.Route;

@Route("")  // the starting location, when you open localhost:8080
public class MainView extends VerticalLayout implements BeforeEnterObserver {

    
    @Override
    public void beforeEnter(BeforeEnterEvent event) {
        event.rerouteTo("login");
    }
}
