package com.example.application.views;

import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.BeforeEnterEvent;
import com.vaadin.flow.router.BeforeEnterObserver;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.server.VaadinService;

@Route("student")
public class StudentView extends VerticalLayout implements BeforeEnterObserver {

    public StudentView() {
        // Logout button
        Button logoutButton = new Button("Logout", event -> {
            VaadinService.getCurrentRequest().getWrappedSession().invalidate();  // Invalidate session
            getUI().ifPresent(ui -> ui.navigate("login"));  // Redirect to login page
        });

        // Button to navigate to TakeExamView
        Button takeExamButton = new Button("Take Exam", event -> {
            getUI().ifPresent(ui -> ui.navigate("take-exam"));  // Navigate to TakeExamView
        });
        
        // Button to navigate to examHistoryView
        Button viewHistoryButton = new Button ("View Exam History", event -> {
        	getUI().ifPresent(ui -> ui.navigate("history"));
        });

        add(logoutButton, takeExamButton, viewHistoryButton);
    }

    @Override
    public void beforeEnter(BeforeEnterEvent event) {
        // Check if user is logged in as a student
        String role = (String) VaadinService.getCurrentRequest().getWrappedSession().getAttribute("role");
        if (role == null || !role.equals("S")) {
            // Redirect to login if not authorized
            Notification.show("Unauthorized Access", 3000, Notification.Position.MIDDLE);
            event.forwardTo("login");
        }
    }
}