package com.example.application.views;

import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.AfterNavigationEvent;
import com.vaadin.flow.router.AfterNavigationObserver;
import com.vaadin.flow.router.Route;

@Route("not-found")  // Define a route for the not-found page
public class NotFoundView extends VerticalLayout implements AfterNavigationObserver {

    public NotFoundView() {
        // Optional: Display a message or a redirect button
        Button redirectButton = new Button("Redirecting to login...");
        add(redirectButton);
    }

    @Override
    public void afterNavigation(AfterNavigationEvent event) {
        getUI().ifPresent(ui -> ui.navigate("login"));
    }
}